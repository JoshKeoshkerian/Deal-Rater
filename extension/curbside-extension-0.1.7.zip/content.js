"use strict";(()=>{var uo=new Date().getFullYear()+2;function k(e){return e.replace(/\s+/g," ").trim()}function C(e){if(e==null)return null;let t=k(e);return t===""?null:t}var co={$:"USD","\xA3":"GBP","\u20AC":"EUR"};function Q(e){if(!e)return null;let t=k(e);if(/^free$/i.test(t))return{cents:0,currency:"USD"};let n=t.match(/([$£€])?\s?(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d{2}))?/);if(!n)return null;let r=Number(n[2].replace(/,/g,""));if(!Number.isFinite(r))return null;let o=n[3]?Number(n[3]):0,a=n[1],s=a&&co[a]||"USD";return{cents:r*100+o,currency:s}}function Nt(e){let t=typeof e=="string"?Number(e):e;return typeof t!="number"||!Number.isFinite(t)||t<0?null:Math.round(t*100)}var qe=15e5;function Y(e){if(!e)return null;let t=k(e),n=t.match(/\b(\d{1,3}),?([xX]{2,4})\b(?:\s*(km\b|kilometers|kilometres))?/);if(n){let s=Number(n[1]);if(Number.isFinite(s)){let l=Math.round(s*10**n[2].length);if(l>=0&&l<=qe){let c=n[3]?"km":"mi";return{value:l,unit:c}}}}let r=t.match(/(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*(k\b)?\s*(miles|mile|mi\b|km\b|kilometers|kilometres)/i);if(!r)return null;let o=Number(r[1].replace(/,/g,""));if(!Number.isFinite(o)||(r[2]&&(o*=1e3),o=Math.round(o),o<0||o>qe))return null;let a=/km|kilometer|kilometre/i.test(r[3])?"km":"mi";return{value:o,unit:a}}function Ht(e){let t=typeof e=="string"?Number(e.replace(/,/g,"")):e;if(typeof t!="number"||!Number.isFinite(t))return null;let n=Math.round(t);return n<0||n>qe?null:n}var $t=["alfa romeo","aston martin","land rover","range rover","mercedes benz","mercedes-benz","rolls royce","rolls-royce"],Dt=["acura","audi","bmw","buick","cadillac","chevrolet","chevy","chrysler","dodge","ferrari","fiat","ford","genesis","gmc","honda","hummer","hyundai","infiniti","isuzu","jaguar","jeep","kia","lamborghini","lexus","lincoln","lucid","maserati","mazda","mclaren","mercedes","mercury","mini","mitsubishi","nissan","oldsmobile","peugeot","plymouth","polestar","pontiac","porsche","ram","renault","rivian","saab","saturn","scion","smart","subaru","suzuki","tesla","toyota","volkswagen","volvo","vw","amc","austin","bentley","bugatti","datsun","delorean","eagle","fisker","geo","international","lotus","maybach","mg","morgan","packard","rover","sterling","studebaker","sunbeam","triumph","willys","yugo"],po=2,mo={chevy:"Chevrolet",vw:"Volkswagen",mercedes:"Mercedes-Benz","mercedes benz":"Mercedes-Benz","mercedes-benz":"Mercedes-Benz","rolls royce":"Rolls-Royce","rolls-royce":"Rolls-Royce",bmw:"BMW",gmc:"GMC",ram:"RAM",kia:"Kia"},Ot="\xB7";function Ke(e){return e.split(" ").map(t=>t&&t[0].toUpperCase()+t.slice(1)).join(" ")}function It(e){return mo[e.toLowerCase()]??Ke(e)}function Pt(e){let t=e.toLowerCase();return t?$t.some(n=>t===n||t.startsWith(`${n} `))?!0:Dt.includes(t.split(" ")[0]??""):!1}function D(e){let t={year:null,make:null,model:null,trim:null,trimSource:null};if(!e)return t;let n=k(e),r=n.indexOf(Ot),o=r>=0?k(n.slice(r+Ot.length)):null,a=n.match(/\b(1[89]\d{2}|20\d{2})\b/),s=a&&Number(a[1])>=1900&&Number(a[1])<=uo?Number(a[1]):null,l=h=>k(h.replace(/[·|,]/g," ")),c;if(a){let h=l(n.slice(a.index+a[0].length)),y=l(n.slice(0,a.index));c=Pt(h)||!Pt(y)?h:y}else c=l(n);let u=c.toLowerCase(),d=null,p="";for(let h of $t)if(u.startsWith(`${h} `)||u===h){d=It(h),p=c.slice(h.length).trim();break}if(d===null){let h=c.split(" ")[0]??"";Dt.includes(h.toLowerCase())&&(d=It(h),p=c.slice(h.length).trim())}if(d===null)return{year:s,make:null,model:null,trim:null,trimSource:null};let f=p.split(" ").filter(Boolean),m=Math.min(po,f.length-1);for(let h=m;h>=1;h--)if(Ge(f.slice(0,h).join(""))===Ge(d)){f.splice(0,h);break}let v=f.length>0?Ke(f[0]):null,b=f.length>1?f.slice(1).join(" "):null;return{year:s,make:d,model:v,trim:b,trimSource:fo(b,o)}}function fo(e,t){return e===null?null:t!==null&&t.toLowerCase().endsWith(e.toLowerCase())?"fb_catalog":"title_text"}function Ge(e){return e.toLowerCase().replace(/[^a-z0-9]+/g,"")}function Ye(e){return e?Ge(e):""}var go={minute:6e4,hour:36e5,day:864e5,week:6048e5,month:2592e6,year:31536e6};function Bt(e,t=new Date){if(!e)return null;let n=k(e);if(/just listed|listed (just )?now|a few seconds ago/i.test(n))return{postedAt:new Date(t.getTime()),relativeText:n.slice(0,64)};let r=n.match(/(?:about\s+)?(an?|\d+)\s*(minute|hour|day|week|month|year)s?\s*ago/i);if(!r)return null;let o=r[1].toLowerCase(),a=o==="a"||o==="an"?1:Number(o);if(!Number.isFinite(a))return null;let s=go[r[2].toLowerCase()];return s===void 0?null:{postedAt:new Date(t.getTime()-a*s),relativeText:n.slice(0,64)}}function zt(e){let t=typeof e=="string"?Number(e):e;if(typeof t!="number"||!Number.isFinite(t)||t<=0)return null;let n=new Date(t*1e3);return Number.isNaN(n.getTime())?null:n}var ho=[["parts_only",/\b(for parts|parts only|parts car|not running|non[- ]?running)\b/i],["no_title",/\b(no title|lost title|bill of sale only|bos only)\b/i],["salvage",/\bsalvage\b/i],["rebuilt",/\b(rebuilt|reconstructed|prior salvage)\b/i],["branded",/\b(branded title|flood|lemon|hail damage title)\b/i],["clean",/\b(clean title|clear title|title in hand)\b/i]];function Je(...e){let t=e.filter(Boolean).join(` 
 `);if(!t)return null;for(let[n,r]of ho)if(r.test(t))return n;return null}var vo=["grand touring","grand sport","grand limited","trailhawk","overland","laredo","altitude","summit","touring","limited","platinum","titanium","denali","lariat","premium"],bo=new RegExp(`\\b(${vo.map(e=>e.replace(/ /g,"\\s+")).join("|")})\\b`,"i");function jt(e){if(!e)return null;let t=e.match(bo);return t?Ke(t[0].replace(/\s+/g," ").toLowerCase()):null}function Ut(e){if(!e)return null;let t=k(e).replace(/^.*?\bin\s+/i,"");return C(t)?.slice(0,255)??null}function Z(e){if(!e)return null;let t=e.match(/\/marketplace\/item\/(\d+)/);return t?t[1]:null}var Ft='a[href*="/marketplace/item/"]',xo=/seller.?s\s*description|about this vehicle|seller information/i;function J(e){let n=(e.querySelector("h1")??e.querySelector('[role="heading"][aria-level="1"]')??e.querySelector('[role="heading"]'))?.textContent;return n&&k(n)||null}function he(e){let t=e.querySelector('[role="main"]')??e.querySelector("main")??e.body,n=J(t);if(n){let o=Array.from(e.querySelectorAll('[role="dialog"]')).reverse().find(a=>{if(!xo.test(a.textContent??""))return!1;let s=J(a);if(!s)return!1;let l=n.toLowerCase(),c=s.toLowerCase();return!l.includes(c)&&!c.includes(l)});if(o)return o}return t}function We(e){return Array.from(e.querySelectorAll(Ft))}function Vt(e){let t=new Set;for(let n of We(e)){let r=n.getAttribute("href")?.match(/\/marketplace\/item\/(\d+)/);r&&t.add(r[1])}return Array.from(t)}function ie(e,t){let n=Array.from(e.querySelectorAll('h1, h2, h3, h4, [role="heading"]'));for(let r of n){let o=k(r.textContent??"");if(!t.test(o))continue;let a=r.parentElement;for(let s=0;s<12&&a;s+=1){let l=k(a.textContent??"");if(a.querySelector(Ft)||l.length>o.length+20)return a;a=a.parentElement}return r.parentElement}return null}function qt(e){return Array.from(e.querySelectorAll("[aria-label]")).map(t=>t.getAttribute("aria-label")??"").filter(t=>t!=="")}function Gt(e){let t=new Set;for(let n of Array.from(e.querySelectorAll("img"))){let r=n.getAttribute("src");r&&/scontent|fbcdn/i.test(r)&&t.add(r.split("?")[0])}return Array.from(t)}function Kt(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function Yt(e){let t=[],n=e.querySelectorAll('script[type="application/json"]');for(let r of Array.from(n)){let o=r.textContent;if(!(!o||o.length<2))try{t.push(JSON.parse(o))}catch{}}return t}function Jt(e,t){let n=e.map(o=>({node:o,depth:0})),r=0;for(;n.length>0;){let o=n.pop();if(o.depth>60)continue;if((r+=1)>4e5)return;let{node:a,depth:s}=o;if(Array.isArray(a)){for(let l of a)typeof l=="object"&&l!==null&&n.push({node:l,depth:s+1});continue}if(Kt(a)){if(t(a)===!0)return;for(let l of Object.values(a))typeof l=="object"&&l!==null&&n.push({node:l,depth:s+1})}}}function Xe(e,t,n=200){let r=[];return Jt(e,o=>{if(t(o)&&(r.push(o),r.length>=n))return!0}),r}function ve(e,t){return Xe(e,t,1)[0]??null}function be(e,t){let n;return Jt(e,r=>{for(let o of t){let a=r[o];if(a!=null)return n=a,!0}}),n}function B(e,t){if(e)for(let n of t){let r=e[n];if(r!=null)return r}}function O(e,t){let n=B(e,t);return Kt(n)?n:null}function _(e,t){let n=B(e,t);return typeof n=="string"&&n.trim()!==""?n:typeof n=="number"?String(n):null}function V(e,t){let n=B(e,t),r=typeof n=="string"?Number(n):n;return typeof r=="number"&&Number.isFinite(r)?r:null}function le(e,t){let n=B(e,t);return Array.isArray(n)?n:null}var ee=class{doc;url;now;listingId;cachedPayloads=null;cachedMain=null;cachedSignature=null;constructor(t,n,r=new Date){this.doc=t,this.url=n,this.now=r,this.listingId=Z(n)}get payloads(){return this.cachedPayloads===null&&(this.cachedPayloads=Yt(this.doc)),this.cachedPayloads}get main(){return this.cachedMain===null&&(this.cachedMain=he(this.doc)),this.cachedMain}get pageSignature(){if(this.cachedSignature!==null)return this.cachedSignature;let t=[`p:${Wt(this.doc.querySelectorAll('script[type="application/json"]').length)}`,`m:${this.doc.querySelector('[role="main"]')?1:0}`,`h:${this.doc.querySelectorAll('h1, [role="heading"]').length>0?1:0}`,`og:${this.doc.querySelectorAll('meta[property^="og:"]').length}`,`il:${Wt(this.doc.querySelectorAll('a[href*="/marketplace/item/"]').length)}`];return this.cachedSignature=yo(t.join("|")),this.cachedSignature}};function Wt(e){return e===0?0:e<=5?1:e<=20?2:e<=60?3:4}function yo(e){let t=2166136261;for(let n=0;n<e.length;n+=1)t^=e.charCodeAt(n),t=Math.imul(t,16777619)>>>0;return t.toString(16).padStart(8,"0")}var g={listingTitle:["marketplace_listing_title","custom_title"],listingId:["id","listing_id"],price:["listing_price","price","formatted_price"],priceAmount:["amount"],priceAmountOffset:["amount_with_offset"],priceCurrency:["currency","currency_code"],priceText:["formatted_amount","text"],odometer:["vehicle_odometer_data","odometer"],odometerValue:["value","odometer_value"],odometerUnit:["unit","odometer_unit"],subtitles:["custom_sub_titles_with_rendering_flags","custom_sub_titles"],subtitleText:["subtitle","text"],description:["redacted_description","listing_description","description"],descriptionText:["text"],photos:["listing_photos","all_listing_photos","listing_photo_ids"],location:["location","listing_location"],latitude:["latitude"],longitude:["longitude"],reverseGeocode:["reverse_geocode","reverse_geocode_detailed"],locationVanityOrId:["location_vanity_or_id"],searchRadius:["radius"],city:["city"],state:["state","state_page"],displayName:["display_name"],createdAt:["creation_time","created_time","listing_creation_time"],seller:["marketplace_listing_seller","seller","story_actor"],sellerId:["id"],sellerListingCount:["marketplace_listing_count","active_listings_count","listing_count"],vehicleTrim:["vehicle_trim_display_name","vehicle_trim","trim"],vehicleMake:["vehicle_make_display_name","vehicle_make","make"],vehicleModel:["vehicle_model_display_name","vehicle_model","model"],vehicleYear:["vehicle_year","year"],vehicleSellerType:["vehicle_seller_type","seller_type"],vehicleTransmission:["vehicle_transmission_type","vehicle_transmission"],vehicleCondition:["vehicle_title_status","title_status"],vehicleNumberOfOwners:["vehicle_number_of_owners"],vehicleVin:["vehicle_identification_number"]};function Xt(e,t){return t.some(n=>e[n]!==void 0&&e[n]!==null)}function Qt(e){let t=B(e,g.listingId);return typeof t=="string"&&/^\d+$/.test(t)?t:typeof t=="number"?String(t):null}function Qe(e){return Xt(e,g.listingTitle)}function Zt(e,t){return t?ve(e,n=>Qe(n)&&Qt(n)===t):ve(e,Qe)}function en(e){return ve(e,t=>Xt(t,g.photos))}function tn(e,t=200){let n=Xe(e,Qe,t*4),r=new Map;for(let o of n){let a=Qt(o);if(!a)continue;let s=r.get(a);if((!s||Object.keys(o).length>Object.keys(s).length)&&r.set(a,o),r.size>=t)break}return Array.from(r,([o,a])=>({id:o,node:a}))}var xe=/[$£€]\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?|\bfree\b/i,_o=/\b\d{1,3},?[xX]{2,4}\b/,ye=new RegExp(`\\b\\d{1,3}(?:,\\d{3})*(?:\\.\\d+)?\\s*k?\\s*(?:miles|mile|mi|km|kilometers|kilometres)\\b|${_o.source}(?:\\s*(?:miles|mile|mi|km|kilometers|kilometres)\\b)?`,"i"),nn=/\b(?:just listed|listed\s+(?:about\s+)?(?:an?|\d+)\s*(?:minute|hour|day|week|month|year)s?\s+ago|(?:an?|\d+)\s*(?:minute|hour|day|week|month|year)s?\s+ago)/i,rn=/\b(\d+)\s+of\s+(\d+)\b/,on=/\bprice\s*(?:drop|dropped|reduced|lowered)\b|\breduced\b/i;function z(e,t){let n=Array.from(e.querySelectorAll("*")),r=null,o=1/0;for(let a of n){let s=k(a.textContent??"");if(s===""||s.length>=o)continue;let l=s.match(t);l&&(r=k(l[0]),o=s.length)}return r}function an(e,t=40){let n=Array.from(e.querySelectorAll("div, span, p")),r=null;for(let o of n){if(o.querySelector("div, p, a, button"))continue;let a=k(o.textContent??"");a.length<t||(r===null||a.length>r.length)&&(r=a)}return r}function Ze(e){let t=le(e,g.subtitles);if(!t)return[];let n=[];for(let r of t)if(typeof r=="string")n.push(r);else if(typeof r=="object"&&r!==null){let o=_(r,g.subtitleText);o&&n.push(o)}return n}function _e(e,t,n,r=null,o=null,a=null){let s=null,l=null,c=e.resolve("mileage",[["json_payload",()=>{let u=O(t,g.odometer);if(!u)return null;let d=Ht(u.value??u.odometer_value);if(d===null)return null;let p=_(u,g.odometerUnit);return s=p&&/km|kilomet/i.test(p)?"km":"mi",d}],["json_payload",()=>{for(let u of Ze(t)){let d=Y(u);if(d)return s=d.unit,l=u,d.value}return null}],["text_pattern",()=>{if(!o)return null;let u=Y(o);return u?(s=u.unit,l=o,u.value):null}],["text_pattern",()=>{if(!n)return null;let u=z(n,ye);if(!u)return null;let d=Y(u);return d?(s=d.unit,l=u,d.value):null}],["text_pattern",()=>{if(!r)return null;let u=z(r,ye);if(!u)return null;let d=Y(u);return d?(s=d.unit,l=u,d.value):null}],["text_pattern",()=>{if(!a)return null;let u=z(a,ye);if(!u)return null;let d=Y(u);return d?(s=d.unit,l=u,d.value):null}]]);return{value:c,unit:c===null?null:s??"mi",text:l}}var ko=/\b(?:in\s+)?[A-Z][A-Za-z.'-]+(?:\s+[A-Z][A-Za-z.'-]+)*,\s*[A-Z]{2}\b/;function wo(e){let t=O(e,g.reverseGeocode);if(!t)return null;let n=_(t,g.displayName);if(n)return n;let r=_(t,g.city),o=t.state,a=typeof o=="string"?o:_(O(t,g.state),g.displayName);return r&&a?`${r}, ${a}`:r??null}function ke(e,t,n){let r=O(t,g.location),o=e.resolve("location_text",[["json_payload",()=>C(wo(r))],["json_payload",()=>C(_(r,g.displayName))],["text_pattern",()=>n?Ut(z(n,ko)):null]]),a=e.resolve("latitude",[["json_payload",()=>V(r,g.latitude)]]),s=a===null?null:V(r,g.longitude);return{text:o?o.slice(0,255):null,latitude:a,longitude:s}}function sn(e){let t=be(e,g.searchRadius),n=typeof t=="string"?Number(t):t;if(typeof n!="number"||!Number.isFinite(n)||n<=0)return null;let r=n>1e3?n/1e3:n;return r>5e3?null:Math.round(r)}function Eo(e){let t=O(e,g.price);if(!t)return null;let n=B(t,g.priceAmount);if(n!==void 0){let a=Nt(n);if(a!==null)return a}let r=V(t,g.priceAmountOffset);if(r!==null)return Math.round(r);let o=_(t,g.priceText);return o?Q(o)?.cents??null:null}function we(e,t,n){let r=null,o=e.resolve("price_cents",[["json_payload",()=>Eo(t)],["text_pattern",()=>n?(r=z(n,xe),r?Q(r)?.cents??null:null):null]]),a=e.resolve("currency",[["json_payload",()=>_(O(t,g.price),g.priceCurrency)],["text_pattern",()=>r?Q(r)?.currency??null:null]]);return{cents:o,currency:a,text:r}}function ln(e,t){let n=[["aria_dom",()=>t&&t.querySelector("s, del, [style*='line-through']")?!0:null],["text_pattern",()=>t&&on.test(t.textContent??"")?!0:null]];return e.resolve("price_changed",n)}var To="deal-rater/seller/v1/2f4c8a1d6b93e05f";async function un(e){let t=e.trim();if(t==="")throw new Error("hashSellerId: empty seller id");let n=new TextEncoder().encode(`${To}:${t}`),r=await crypto.subtle.digest("SHA-256",n);return Array.from(new Uint8Array(r)).map(o=>o.toString(16).padStart(2,"0")).join("")}function cn(e){let t=e.querySelector("h1")??e.querySelector('[role="heading"][aria-level="1"]')??e.querySelector('[role="heading"]');if(!t)return e;let n=t.parentElement,r=t.parentElement??e;for(let o=0;o<8&&n&&n!==e;o+=1){let a=k(n.textContent??"");if(/[$£€]\s?\d/.test(a))return n;r=n,n=n.parentElement}return r}function dn(e){return ie(e,/other listings|more from this seller|seller'?s other|more listings from/i)}function pn(e){return ie(e,/seller.?s\s*description/i)??ie(e,/^description$|^details$|about this vehicle/i)}function mn(e){return ie(e,/about this vehicle/i)}var Ao=/\/marketplace\/profile\/(\d+)|profile\.php\?id=(\d+)/;function fn(e,t){let n=O(e,g.seller),r=_(n,g.sellerId);if(r&&/^\d+$/.test(r))return r;if(!t)return null;for(let o of Array.from(t.querySelectorAll("a[href]"))){let a=o.getAttribute("href")?.match(Ao),s=a?.[1]??a?.[2];if(s)return s}return null}function gn(e,t,n){let r=O(e,g.seller),o=V(r,g.sellerListingCount);if(o!==null&&o>=0)return Math.round(o);if(!t)return null;let a=dn(t);return a?Vt(a).filter(l=>l!==n).length+1:null}var Mo=/(\d+(?:\.\d+)?)\s*out of\s*5\s*stars?/i,Ro=/^\(\s*(\d+)\s*\)$/,Lo=8;function Co(e){return e.querySelector('[role="img"][aria-label*="out of 5 star"]')}function Oo(e){let t=e.parentElement;for(let n=0;n<Lo&&t;n+=1){for(let r of Array.from(t.querySelectorAll("span"))){let a=k(r.textContent??"").match(Ro);if(a)return Number(a[1])}t=t.parentElement}return null}function Io(e){if(!e)return null;let t=Co(e);if(!t)return null;let r=(t.getAttribute("aria-label")??"").match(Mo),o=r?Number(r[1]):null;return o===null||!Number.isFinite(o)||o<0||o>5?null:{average:o,count:Oo(t)}}async function Ee(e,t,n,r){let o=e.resolve("seller_hash",[["json_payload",()=>fn(t,null)],["url_path",()=>fn(null,n)]]);if(o===null)return null;let a=e.resolve("seller_listing_count",[["json_payload",()=>gn(t,null,r)],["aria_dom",()=>gn(null,n,r)]]),s=e.resolve("seller_rating",[["aria_dom",()=>Io(n)]]);return{seller_hash:await un(o),hash_version:1,active_vehicle_listing_count:a,rating_average:s?.average??null,rating_count:s?.count??null}}function et(e,t){let r=(e.querySelector(`meta[property="${t}"]`)??e.querySelector(`meta[name="${t}"]`))?.getAttribute("content");return r&&r.trim()!==""?r.trim():null}function ue(e){return et(e,"og:title")}function hn(e){return et(e,"og:description")}function tt(e){return et(e,"og:url")}function nt(e){let t=e.querySelector('link[rel="canonical"]')?.getAttribute("href");return t&&t.trim()!==""?t.trim():null}function Te(e,t){let{node:n,doc:r,block:o,description:a}=t,s=_(n,g.listingTitle)??(r?ue(r):null)??(o?J(o):null),l=D(s),c=e.resolve("year",[["json_payload",()=>V(n,g.vehicleYear)],["title_text",()=>s?l.year:null],["meta_tag",()=>r?D(ue(r)).year:null],["aria_dom",()=>o?D(J(o)).year:null]]),u=e.resolve("make",[["json_payload",()=>C(_(n,g.vehicleMake))],["title_text",()=>s?l.make:null],["meta_tag",()=>r?D(ue(r)).make:null],["aria_dom",()=>o?D(J(o)).make:null]]),d=e.resolve("model",[["title_text",()=>s?l.model:null],["json_payload",()=>C(_(n,g.vehicleModel))],["meta_tag",()=>r?D(ue(r)).model:null],["aria_dom",()=>o?D(J(o)).model:null]]),p=null,f=e.resolve("trim_text",[["json_payload",()=>{let y=C(_(n,g.vehicleTrim));return y&&(p="fb_catalog"),y}],["title_text",()=>!s||l.trim===null?null:(p=l.trimSource,l.trim)],["text_pattern",()=>{let y=jt(a);return y&&(p="description"),y}]]),m=e.resolve("seller_type",[["json_payload",()=>C(_(n,g.vehicleSellerType))]]),v=e.resolve("transmission",[["json_payload",()=>C(_(n,g.vehicleTransmission))]]),b=e.resolve("title_status",[["json_payload",()=>{let y=_(n,g.vehicleCondition);return y?Je(y)??C(y):null}],["text_pattern",()=>Je(a,s)]]),h=e.resolve("owner_count",[["json_payload",()=>C(_(n,g.vehicleNumberOfOwners))]]);return{year:c,make:u,model:d,trim:f,trimSource:f===null?null:p,titleStatus:b,sellerType:m,transmission:v,ownerCount:h,title:s}}var vn={source_listing_id:"required",listing_url:"required",listing_payload:"required",price_cents:"expected",year:"expected",make:"expected",model:"expected",mileage:"expected",location_text:"expected",photo_count:"expected",posted_at:"expected",seller_hash:"expected",description:"optional",trim_text:"optional",trim_source:"optional",title_status:"optional",vin:"optional",price_changed:"optional",seller_listing_count:"optional",latitude:"optional",currency:"optional",seller_type:"expected",transmission:"optional",owner_count:"optional"},rt={source_listing_id:"required",listing_url:"required",price_cents:"expected",year:"expected",make:"expected",model:"expected",mileage:"optional",location_text:"optional",photo_count:"optional",posted_at:"optional",seller_hash:"optional",description:"optional",trim_text:"optional",trim_source:"optional",title_status:"optional",vin:"optional",seller_type:"optional",transmission:"optional",owner_count:"optional"},W=class{strategies={};issues=[];scope;expectations;pageSignature;constructor(t,n,r){this.scope=t,this.expectations=n,this.pageSignature=r}resolve(t,n){let r=[];for(let[o,a]of n){r.push(o);let s;try{s=a()}catch{continue}if(s!=null)return this.strategies[t]=o,s}return this.report(t,"missing",r),null}reportUnparsed(t,n=[]){this.report(t,"unparsed",n)}reportSuspect(t,n=[]){this.report(t,"suspect",n)}report(t,n,r){let o=this.expectations[t];o!==void 0&&this.issues.push({scope:this.scope,field_name:t,status:n,expectation:o,strategies_attempted:r,page_signature:this.pageSignature})}};function ce(e){let t=new Map;for(let n of e){let r=`${n.scope}|${n.field_name}|${n.status}`;t.has(r)||t.set(r,n)}return Array.from(t.values())}var Po=120;function bn(e){return{source:"facebook_marketplace",source_listing_id:e,listing_url:`https://www.facebook.com/marketplace/item/${e}/`,role:"comp",price_cents:null,currency:null,mileage:null,mileage_unit:null,year:null,make:null,model:null,trim_text:null,trim_source:null,seller_type:null,transmission:null,title_status:null,owner_count:null,description:null,photo_count:null,posted_at:null,posted_relative_text:null,price_changed:null,location_text:null,latitude:null,longitude:null,vin:null,seller:null,field_strategies:{},raw_extract:null}}async function No(e,t){let n=tn(e.payloads,t),r=[],o=[];for(let{id:a,node:s}of n){let l=new W("comp_card",rt,e.pageSignature);l.strategies.source_listing_id="json_payload",l.strategies.listing_url="url_path";let c=we(l,s,null),u=Te(l,{node:s,doc:null,block:null,description:null}),d=_e(l,s,null,null,u.title),p=ke(l,s,null),f=await Ee(l,s,null,a),m=bn(a);m.price_cents=c.cents,m.currency=c.currency,m.mileage=d.value,m.mileage_unit=d.unit,m.year=u.year,m.make=u.make,m.model=u.model,m.trim_text=u.trim,m.trim_source=u.trimSource,m.seller_type=u.sellerType,m.transmission=u.transmission,m.title_status=u.titleStatus,m.owner_count=u.ownerCount,m.location_text=p.text,m.latitude=p.latitude,m.longitude=p.longitude,m.seller=f,m.field_strategies=l.strategies,m.raw_extract={title:u.title,subtitles:Ze(s).slice(0,4)},r.push(m),o.push(...l.issues)}return{observations:r,issues:o}}function Ho(e,t){let n=[],r=[],o=new Set;for(let a of We(e.main)){if(n.length>=t)break;let s=Z(a.getAttribute("href"));if(!s||o.has(s))continue;o.add(s);let l=new W("comp_card",rt,e.pageSignature);l.strategies.source_listing_id="url_path",l.strategies.listing_url="url_path";let c=k(a.textContent??""),u=bn(s),d=c.match(xe)?.[0]??null,p=d?Q(d):null;p?(u.price_cents=p.cents,u.currency=p.currency,l.strategies.price_cents="text_pattern"):l.reportUnparsed("price_cents",["text_pattern"]);let f=Y(c);f&&(u.mileage=f.value,u.mileage_unit=f.unit,l.strategies.mileage="text_pattern");let m=d?c.replace(d," "):c,v=D(m);u.year=v.year,u.make=v.make,u.model=v.model,u.trim_text=v.trim,u.trim_source=v.trimSource,v.year!==null&&(l.strategies.year="text_pattern"),v.make!==null&&(l.strategies.make="text_pattern"),v.model!==null&&(l.strategies.model="text_pattern"),u.field_strategies=l.strategies,u.raw_extract={card_text:c.slice(0,300)},n.push(u),r.push(...l.issues)}return{observations:n,issues:r}}async function Se(e,t,n=new Date,r=Po){let o=new ee(e,t,n),a=await No(o,r);if(a.observations.length>0)return{observations:a.observations,issues:ce(a.issues)};let s=Ho(o,r);return{observations:s.observations,issues:ce(s.issues)}}var $o=200;function xn(e,t,n,r=null){return e.resolve("photo_count",[["aria_dom",()=>{if(!n)return null;for(let o of qt(n)){let a=o.match(rn);if(a){let s=Number(a[2]);if(Number.isFinite(s)&&s>0&&s<=$o)return s}}return null}],["json_payload",()=>{let o=le(r,g.photos)??le(t,g.photos),a=n?Gt(n).length:0;return o===null&&a===0?null:Math.max(o?.length??0,a)}]])}var yn="[PHONE]",Do="[EMAIL]",Bo=/\b[\w.+-]+@[\w-]+\.[\w.-]{2,}\b/gi,zo=/(?<![\w-])(?:\+?1[\s.\-]*)?(?:\(\s*\d{3}\s*\)|\d{3})[\s.\-]*\d{3}[\s.\-]*\d{4}(?![\w-])/g,_n="(?:zero|one|two|three|four|five|six|seven|eight|nine|oh)",jo=new RegExp(`\\b(?:${_n}[\\s.\\-]+){6,}${_n}\\b`,"gi");function kn(e){return e==null?null:e.replace(Bo,Do).replace(zo,yn).replace(jo,yn)}var Uo="[A-HJ-NPR-Z0-9]",Fo=new RegExp(`(?<![A-Z0-9])${Uo}{17}(?![A-Z0-9])`,"gi"),Vo={A:1,B:2,C:3,D:4,E:5,F:6,G:7,H:8,J:1,K:2,L:3,M:4,N:5,P:7,R:9,S:2,T:3,U:4,V:5,W:6,X:7,Y:8,Z:9},qo=[8,7,6,5,4,3,2,10,0,9,8,7,6,5,4,3,2],Go=8;function Ko(e){let t=e.toUpperCase();if(t.length!==17||/[IOQ]/.test(t)||!/^[A-HJ-NPR-Z0-9]{17}$/.test(t))return!1;let n=0;for(let a=0;a<17;a+=1){let s=t[a],l=s>="0"&&s<="9"?Number(s):Vo[s];if(l===void 0)return!1;n+=l*qo[a]}let r=n%11,o=r===10?"X":String(r);return t[Go]===o}function Ae(e){if(!e)return null;let t=e.toUpperCase().match(Fo);if(!t)return null;for(let n of t)if(Ko(n))return n;return null}var Yo=2e4;function wn(e,t,n,r){let o=e.resolve("description",[["json_payload",()=>{let s=O(t,g.description);return s?_(s,g.descriptionText):_(t,g.description)}],["aria_dom",()=>r?an(r):null],["meta_tag",()=>n?hn(n):null]]);if(o===null)return null;let a=kn(o.slice(0,Yo));return C(a)===null?"":a}function En(e,t,n,r){return e.resolve("vin",[["json_payload",()=>Ae(_(t,g.vehicleVin))],["text_pattern",()=>Ae(n)],["text_pattern",()=>Ae(r)]])}function Tn(e,t,n,r){let o=null;return{postedAt:e.resolve("posted_at",[["json_payload",()=>zt(B(t,g.createdAt))],["text_pattern",()=>{if(!n)return null;let s=z(n,nn);if(!s)return null;let l=Bt(s,r);return l?(o=l.relativeText,l.postedAt):null}]]),relativeText:o}}function Jo(e){return e?`https://www.facebook.com/marketplace/item/${e}/`:null}async function de(e,t,n=new Date){let r=new ee(e,t,n),o=new W("target",vn,r.pageSignature),a=o.resolve("listing_payload",[["json_payload",()=>Zt(r.payloads,r.listingId)]]),s=o.resolve("source_listing_id",[["url_path",()=>r.listingId],["meta_tag",()=>Z(nt(e)??tt(e))]]),l=o.resolve("listing_url",[["url_path",()=>Jo(s)],["meta_tag",()=>nt(e)??tt(e)]]),c=r.main,u=cn(c),d=pn(c),p=mn(c),f=we(o,a,u),m=ln(o,u),v=wn(o,a,e,d),b=Te(o,{node:a,doc:e,block:u,description:v}),h=_e(o,a,u,d,b.title,p),y=En(o,a,v,b.title),H=a?en(r.payloads):null,K=xn(o,a,u,H),F=ke(o,a,u),A=Tn(o,a,u,n),x=await Ee(o,a,c,s),w=be(r.payloads,g.locationVanityOrId),E=sn(r.payloads),M=typeof w=="string"&&/^[A-Za-z0-9.-]{3,64}$/.test(w)?w:null;return{observation:{source:"facebook_marketplace",source_listing_id:s??"",listing_url:l,role:"target",price_cents:f.cents,currency:f.currency,mileage:h.value,mileage_unit:h.unit,year:b.year,make:b.make,model:b.model,trim_text:b.trim,trim_source:b.trimSource,seller_type:b.sellerType,transmission:b.transmission,title_status:b.titleStatus,owner_count:b.ownerCount,description:v,photo_count:K,posted_at:A.postedAt?A.postedAt.toISOString():null,posted_relative_text:A.relativeText,price_changed:m,location_text:F.text,latitude:F.latitude,longitude:F.longitude,vin:y,seller:x,field_strategies:o.strategies,raw_extract:{title:b.title,price_text:f.text,mileage_text:h.text,posted_text:A.relativeText,page_signature:r.pageSignature}},issues:o.issues,pageSignature:r.pageSignature,usable:s!==null,locationId:M,searchRadiusKm:E,payloadMatched:a!==null}}var Wo=["deal-rater-production.up.railway.app"],ot={apiBaseUrl:"https://api.curbsidescore.com",theme:"auto",enabled:!0,devMode:!1,disclosureAcceptedAt:null,extraMetroIds:[]};function Xo(e){try{return Wo.includes(new URL(e).host)}catch{return!1}}async function te(){let e=await chrome.storage.sync.get(ot),t={...ot,...e};return Xo(t.apiBaseUrl)&&(t.apiBaseUrl=ot.apiBaseUrl,chrome.storage.sync.set({apiBaseUrl:t.apiBaseUrl}).catch(()=>{})),t}async function Sn(e){await chrome.storage.sync.set(e)}var Qo=["all wheel drive","front wheel drive","rear wheel drive","four wheel drive","sport utility","passenger van","regular cab","extended cab","double cab","supercrew","quad cab","crew cab","ext cab","hatchback","convertible","minivan","roadster","pickup","coupe","sedan","wagon","truck","suv","van","cab","4dr","2dr","awd","fwd","rwd","4wd","4x4","4d","2d","ft"],Zo=[/[^\x00-\x7f]+/g,/\bw\/.*$/g,/\b\d[\d,]*\s*k?\s*miles?\b/g],ea=/^\d+\.\d+[a-z]*$/,at=/[^a-z0-9.]+/g;function pe(e,t){if(!e)return new Set;let n=e.toLowerCase();for(let a of Zo)n=n.replace(a," ");n=n.replace(at," ");let r=` ${n.split(/\s+/).filter(Boolean).join(" ")} `;for(let a of Qo)for(;r.includes(` ${a} `);)r=r.replace(` ${a} `," ");let o=new Set((t??"").toLowerCase().split(at).filter(Boolean));return new Set(r.split(/\s+/).filter(a=>a.length>0&&!o.has(a)&&!/^\d+$/.test(a)&&!ea.test(a)))}function An(e,t){if(e.size===0||t.size===0||e.size!==t.size)return!1;for(let n of e)if(!t.has(n))return!1;return!0}function Mn(e,t){let n=pe(e,t);if(n.size===0)return null;let r=(e??"").toLowerCase().replace(at," ").split(/\s+/).filter(o=>n.has(o));return[...new Set(r)].join(" ")||null}var Ln="https://www.facebook.com/marketplace",ta=`${Ln}/search/`,st=/^(?:[0-9]{15}|[a-z][a-z0-9-]{2,40})$/i,Rn="546583916084032";function Cn(e,t){return st.test(t)?Me(e,t):null}function On(e,t){if(!st.test(t??""))return null;let n=Mn(e.trim_text,e.model);if(n===null)return null;let r=Me(e,t,n);return r===null?null:{...r,fallbackUrl:null}}function Me(e,t=null,n=null){let{year:r,make:o,model:a}=e;if(!a||!o)return null;let l=[r!==null?String(r):null,o,a,n].filter(Boolean).join(" "),c={year:r,make:o,model:a,trim:n},u=new URL(ta);u.searchParams.set("query",l),u.searchParams.set("category_id",Rn);let d=st.test(t??"")?t:null;if(d===null)return{url:u.toString(),fallbackUrl:null,query:{query:l,derived_from:c,location_id:null}};let p=new URL(`${Ln}/${d}/search/`);return p.searchParams.set("query",l),p.searchParams.set("category_id",Rn),{url:p.toString(),fallbackUrl:u.toString(),query:{query:l,derived_from:c,location_id:d}}}var Le=[{slug:"nyc",name:"New York",states:["NY","NJ","CT","PA"],lat:40.71,lon:-74.01,rust:"salt",tier:"high"},{slug:"boston",name:"Boston",states:["MA","NH","RI"],lat:42.36,lon:-71.06,rust:"salt",tier:"high"},{slug:"philadelphia",name:"Philadelphia",states:["PA","NJ","DE"],lat:39.95,lon:-75.17,rust:"salt",tier:"moderate"},{slug:"pittsburgh",name:"Pittsburgh",states:["PA","WV","OH"],lat:40.44,lon:-79.996,rust:"salt",tier:"low"},{slug:"hartford",name:"Hartford",states:["CT","MA"],lat:41.76,lon:-72.69,rust:"salt",tier:"moderate"},{slug:"buffalo",name:"Buffalo",states:["NY"],lat:42.89,lon:-78.88,rust:"salt",tier:"low"},{slug:"rochester",name:"Rochester",states:["NY"],lat:43.16,lon:-77.61,rust:"salt",tier:"low"},{slug:"providence",name:"Providence",states:["RI","MA"],lat:41.82,lon:-71.41,rust:"salt",tier:"moderate"},{slug:"chicago",name:"Chicago",states:["IL","IN","WI"],lat:41.88,lon:-87.63,rust:"salt",tier:"moderate"},{slug:"detroit",name:"Detroit",states:["MI","OH"],lat:42.33,lon:-83.05,rust:"salt",tier:"low"},{slug:"milwaukee",name:"Milwaukee",states:["WI"],lat:43.04,lon:-87.91,rust:"salt",tier:"low"},{slug:"minneapolis",name:"Minneapolis",states:["MN","WI"],lat:44.98,lon:-93.27,rust:"salt",tier:"moderate"},{slug:"cleveland",name:"Cleveland",states:["OH"],lat:41.5,lon:-81.69,rust:"salt",tier:"low"},{slug:"columbus",name:"Columbus",states:["OH"],lat:39.96,lon:-83,rust:"salt",tier:"low"},{slug:"cincinnati",name:"Cincinnati",states:["OH","KY","IN"],lat:39.1,lon:-84.51,rust:"mixed",tier:"low"},{slug:"indianapolis",name:"Indianapolis",states:["IN"],lat:39.77,lon:-86.16,rust:"mixed",tier:"low"},{slug:"grandrapids",name:"Grand Rapids",states:["MI"],lat:42.96,lon:-85.67,rust:"salt",tier:"low"},{slug:"washingtondc",name:"Washington DC",states:["DC","VA","MD"],lat:38.91,lon:-77.04,rust:"mixed",tier:"high"},{slug:"baltimore",name:"Baltimore",states:["MD"],lat:39.29,lon:-76.61,rust:"mixed",tier:"moderate"},{slug:"richmond",name:"Richmond",states:["VA"],lat:37.54,lon:-77.44,rust:"mixed",tier:"moderate"},{slug:"virginiabeach",name:"Virginia Beach",states:["VA","NC"],lat:36.85,lon:-75.98,rust:"mixed",tier:"moderate"},{slug:"stlouis",name:"St. Louis",states:["MO","IL"],lat:38.63,lon:-90.2,rust:"mixed",tier:"low"},{slug:"kansascity",name:"Kansas City",states:["MO","KS"],lat:39.1,lon:-94.58,rust:"mixed",tier:"low"},{slug:"springfieldmo",name:"Springfield MO",states:["MO"],lat:37.21,lon:-93.29,rust:"mixed",tier:"low"},{slug:"desmoines",name:"Des Moines",states:["IA"],lat:41.59,lon:-93.62,rust:"salt",tier:"low"},{slug:"omaha",name:"Omaha",states:["NE","IA"],lat:41.26,lon:-95.93,rust:"salt",tier:"low"},{slug:"wichita",name:"Wichita",states:["KS"],lat:37.69,lon:-97.34,rust:"mixed",tier:"low"},{slug:"louisville",name:"Louisville",states:["KY","IN"],lat:38.25,lon:-85.76,rust:"mixed",tier:"low"},{slug:"dallas",name:"Dallas",states:["TX"],lat:32.78,lon:-96.8,rust:"sun",tier:"moderate"},{slug:"houston",name:"Houston",states:["TX"],lat:29.76,lon:-95.37,rust:"sun",tier:"moderate"},{slug:"austin",name:"Austin",states:["TX"],lat:30.27,lon:-97.74,rust:"sun",tier:"moderate"},{slug:"sanantonio",name:"San Antonio",states:["TX"],lat:29.42,lon:-98.49,rust:"sun",tier:"low"},{slug:"oklahomacity",name:"Oklahoma City",states:["OK"],lat:35.47,lon:-97.52,rust:"mixed",tier:"low"},{slug:"tulsa",name:"Tulsa",states:["OK"],lat:36.15,lon:-95.99,rust:"mixed",tier:"low"},{slug:"littlerock",name:"Little Rock",states:["AR"],lat:34.75,lon:-92.29,rust:"sun",tier:"low"},{slug:"neworleans",name:"New Orleans",states:["LA"],lat:29.95,lon:-90.07,rust:"sun",tier:"low"},{slug:"memphis",name:"Memphis",states:["TN","MS","AR"],lat:35.15,lon:-90.05,rust:"sun",tier:"low"},{slug:"nashville",name:"Nashville",states:["TN"],lat:36.16,lon:-86.78,rust:"mixed",tier:"moderate"},{slug:"atlanta",name:"Atlanta",states:["GA"],lat:33.75,lon:-84.39,rust:"sun",tier:"moderate"},{slug:"charlotte",name:"Charlotte",states:["NC","SC"],lat:35.23,lon:-80.84,rust:"sun",tier:"moderate"},{slug:"raleigh",name:"Raleigh",states:["NC"],lat:35.78,lon:-78.64,rust:"sun",tier:"moderate"},{slug:"jacksonville",name:"Jacksonville",states:["FL","GA"],lat:30.33,lon:-81.66,rust:"sun",tier:"moderate"},{slug:"orlando",name:"Orlando",states:["FL"],lat:28.54,lon:-81.38,rust:"sun",tier:"moderate"},{slug:"tampa",name:"Tampa",states:["FL"],lat:27.95,lon:-82.46,rust:"sun",tier:"moderate"},{slug:"miami",name:"Miami",states:["FL"],lat:25.76,lon:-80.19,rust:"sun",tier:"high"},{slug:"birmingham",name:"Birmingham",states:["AL"],lat:33.52,lon:-86.8,rust:"sun",tier:"low"},{slug:"denver",name:"Denver",states:["CO"],lat:39.74,lon:-104.99,rust:"mixed",tier:"high"},{slug:"saltlakecity",name:"Salt Lake City",states:["UT"],lat:40.76,lon:-111.89,rust:"mixed",tier:"moderate"},{slug:"albuquerque",name:"Albuquerque",states:["NM"],lat:35.08,lon:-106.65,rust:"sun",tier:"low"},{slug:"boise",name:"Boise",states:["ID"],lat:43.62,lon:-116.2,rust:"mixed",tier:"moderate"},{slug:"phoenix",name:"Phoenix",states:["AZ"],lat:33.45,lon:-112.07,rust:"sun",tier:"moderate"},{slug:"tucson",name:"Tucson",states:["AZ"],lat:32.22,lon:-110.97,rust:"sun",tier:"low"},{slug:"lasvegas",name:"Las Vegas",states:["NV"],lat:36.17,lon:-115.14,rust:"sun",tier:"moderate"},{slug:"losangeles",name:"Los Angeles",states:["CA"],lat:34.05,lon:-118.24,rust:"sun",tier:"high"},{slug:"sandiego",name:"San Diego",states:["CA"],lat:32.72,lon:-117.16,rust:"sun",tier:"high"},{slug:"sanfrancisco",name:"San Francisco",states:["CA"],lat:37.77,lon:-122.42,rust:"sun",tier:"high"},{slug:"sacramento",name:"Sacramento",states:["CA"],lat:38.58,lon:-121.49,rust:"sun",tier:"moderate"},{slug:"fresno",name:"Fresno",states:["CA"],lat:36.74,lon:-119.79,rust:"sun",tier:"low"},{slug:"portland",name:"Portland",states:["OR","WA"],lat:45.51,lon:-122.68,rust:"mixed",tier:"high"},{slug:"seattle",name:"Seattle",states:["WA"],lat:47.61,lon:-122.33,rust:"mixed",tier:"high"},{slug:"spokane",name:"Spokane",states:["WA","ID"],lat:47.66,lon:-117.43,rust:"mixed",tier:"low"}],cl=new Map(Le.map(e=>[e.slug,e])),na=550,ra=["salt","mixed","sun"],oa=["low","moderate","high"];function In(e,t,n){return Math.abs(e.indexOf(t)-e.indexOf(n))}function Nn(e,t){let n=s=>s*Math.PI/180,r=n(t.lat-e.lat),o=n(t.lon-e.lon),a=Math.sin(r/2)**2+Math.cos(n(e.lat))*Math.cos(n(t.lat))*Math.sin(o/2)**2;return 3958.8*2*Math.asin(Math.sqrt(a))}function Hn(e,t=8){return Le.filter(n=>n.slug!==e.slug).filter(n=>In(ra,n.rust,e.rust)<=1).filter(n=>In(oa,n.tier,e.tier)<=1).map(n=>({metro:n,miles:Nn(e,n)})).filter(({miles:n})=>n<=na).sort((n,r)=>n.miles-r.miles).slice(0,t).map(({metro:n})=>n)}function $n(e,t){if(t.length===0)return!1;let n=new Set(e.states);return t.some(r=>{let o=r.split(",").pop()?.trim().toUpperCase();return o?n.has(o):!1})}var aa=120;function Dn(e,t){if(e===null||t===null)return null;let n={lat:e,lon:t},r=null,o=1/0;for(let a of Le){let s=Nn(n,a);s<o&&(o=s,r=a)}return o<=aa?r:null}var sa=2,ia=/ [a-z]{2}$/;function Bn(e){return e.toLowerCase().replace(/[^a-z0-9 ]/g,"").replace(/\s+/g," ").trim()}function Pn(e){if(!e||!e.includes(","))return[null,null];let t=e.lastIndexOf(","),n=Bn(e.slice(0,t)),r=e.slice(t+1).trim().toUpperCase();return[n||null,r||null]}var Re=new Map;for(let e of Le){let t=Bn(e.name),n=t.replace(ia,"");for(let r of n===t?[t]:[t,n]){let o=Re.get(r);o?o.push(e):Re.set(r,[e])}}function la(e,t){if(!e)return null;for(let n of Re.get(e)??[])if(t===null||n.states.includes(t))return n;return null}function zn(e,t=[]){let[n,r]=Pn(e),o=la(n,r);if(o)return o;if(r===null)return null;let a=new Map;for(let c of t){let[u]=Pn(c);if(u)for(let d of Re.get(u)??[]){if(!d.states.includes(r))continue;let p=a.get(d.slug);p?p.count+=1:a.set(d.slug,{metro:d,count:1});break}}let[s,l]=[...a.values()].sort((c,u)=>u.count-c.count);return!s||s.count<sa||l&&l.count===s.count?null:s.metro}var ua=30,it=6,ca=4,da=.5;function jn(e,t){return e<=0?!0:t/e>=da}function Un(e,t){return!(t.price_cents===null||t.price_cents<=0||!t.make||!t.model||!e.make||!e.model||t.make.toLowerCase()!==e.make.toLowerCase()||Ye(t.model)!==Ye(e.model)||e.year!==null&&t.year!==null&&Math.abs(t.year-e.year)>ca)}function Ce(e,t){return t.reduce((n,r)=>n+(Un(e,r)?1:0),0)}function pa(e,t){return An(pe(e.trim_text,e.model),pe(t.trim_text,t.model))}function Oe(e,t){return t.reduce((n,r)=>n+(Un(e,r)&&pa(e,r)?1:0),0)}function Fn(e,t){let n=new Set(t);return e.filter(r=>!n.has(r.slug))}function Vn(e,t,n,r=ua,o=it){return n<=0?!1:Ce(e,t)<r||pe(e.trim_text,e.model).size>0&&Oe(e,t)<o}var lt="badMetroSlugs";async function ut(){let t=(await chrome.storage.local.get({[lt]:[]}))[lt];return Array.isArray(t)?t:[]}async function qn(e){let t=await ut();t.includes(e)||await chrome.storage.local.set({[lt]:[...t,e]})}function j(e){return chrome.runtime.sendMessage(e)}var ma=2e4;function fa(e){let t=e.querySelectorAll('script[type="application/json"]').length>0,n=e.querySelectorAll('a[href*="/marketplace/item/"]').length>0;return!t&&!n}async function ct(e){let t=new AbortController,n=setTimeout(()=>t.abort(),ma);try{let r=await fetch(e,{credentials:"include",signal:t.signal,headers:{Accept:"text/html"}});if(!r.ok)return null;let o=await r.text();return new DOMParser().parseFromString(o,"text/html")}catch{return null}finally{clearTimeout(n)}}async function me(e,t=new Date){let n=await ct(e);if(n&&!fa(n)){let o=await Se(n,e,t);if(o.observations.length>0)return{...o,source:"same_origin_fetch"}}let r=await j({type:"HARVEST_COMPS_VIA_TAB",url:e});return r?.ok?{observations:r.observations,issues:r.issues,source:"background_tab"}:{observations:[],issues:[],source:"none"}}var q={dark:{sheet:"#10181f",raised:"#16212b",text:"#e8eef4",textMuted:"#a9bccb",textDim:"#8fa3b4",textFaint:"#76899b",border:"#24333f",borderFaint:"#1b2831",track:"#22313d",link:"#7fb8e8",beta:"#d9b26a",betaOn:"#10181f",scrim:"rgba(6, 12, 18, 0.55)",elev1:"0 1px 2px rgba(0,0,0,.32)",elev2:"0 6px 20px rgba(0,0,0,.38)",elev3:"-6px 0 32px rgba(0,0,0,.48)"},light:{sheet:"#ffffff",raised:"#f3f6f9",text:"#0f1a22",textMuted:"#41576a",textDim:"#566e80",textFaint:"#5f7383",border:"#d5dee5",borderFaint:"#e7edf1",track:"#e2e9ef",link:"#1e6aa8",beta:"#8a5f06",betaOn:"#ffffff",scrim:"rgba(16, 26, 34, 0.38)",elev1:"0 1px 2px rgba(16,26,34,.07)",elev2:"0 6px 20px rgba(16,26,34,.10)",elev3:"-6px 0 32px rgba(16,26,34,.16)"}},ga={favorable:{dark:{text:"#7fd1a8",fill:"#4f9e78",surface:"#12291f",border:"#245c40",onSurface:"#cfe7db"},light:{text:"#0e6a41",fill:"#2f9e6a",surface:"#eaf6f0",border:"#b4dcc8",onSurface:"#0c4c30"}},caution:{dark:{text:"#e2b877",fill:"#c99a4e",surface:"#2b2113",border:"#5f4620",onSurface:"#ecdcc0"},light:{text:"#8a5806",fill:"#cf9a3a",surface:"#fdf4e4",border:"#ecd2a4",onSurface:"#5c3c05"}},adverse:{dark:{text:"#f0a5a5",fill:"#c2685f",surface:"#3a1719",border:"#7a2f2f",onSurface:"#f2d5d5"},light:{text:"#b02a23",fill:"#d3544a",surface:"#fdeeed",border:"#f1c3bf",onSurface:"#6d1f1a"}},neutral:{dark:{text:q.dark.textDim,fill:"#5c9ecf",surface:q.dark.raised,border:q.dark.border,onSurface:q.dark.textMuted},light:{text:q.light.textDim,fill:"#3d84bd",surface:q.light.raised,border:q.light.border,onSurface:q.light.textMuted}}},N={favorable:"\u2713",caution:"\u26A0",adverse:"\u2715",neutral:"\xB7"},ha={poor:{text:{dark:"#e35c58",light:"#c22f28"},size:"var(--fs-d1)"},weak:{text:{dark:"#e0904a",light:"#a9600c"},size:"var(--fs-d2)"},fair:{text:{dark:"#dcc257",light:"#7d6a06"},size:"var(--fs-d3)"},good:{text:{dark:"#8ecb6b",light:"#3d7f2a"},size:"var(--fs-d4)"},excellent:{text:{dark:"#3fab5e",light:"#166b38"},size:"var(--fs-d5)"}},va=`
    --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
    --font-num: var(--font-sans);

    --fs-2xs: 10px;
    --fs-xs: 11px;
    --fs-sm: 12px;
    --fs-base: 13px;
    --fs-md: 15px;
    --fs-lg: 19px;
    --fs-xl: 24px;

    --fs-d1: 32px;
    --fs-d2: 34px;
    --fs-d3: 36px;
    --fs-d4: 39px;
    --fs-d5: 42px;

    --sp-1: 4px;
    --sp-2: 6px;
    --sp-3: 8px;
    --sp-4: 12px;
    --sp-5: 16px;
    --sp-6: 20px;
    --sp-7: 28px;

    --radius-sm: 4px;
    --radius-md: 8px;
    --radius-lg: 12px;
    --radius-pill: 999px;

    --dur-fast: 110ms;
    --dur-base: 200ms;
    --dur-slow: 320ms;
    --ease-out: cubic-bezier(.16, .84, .44, 1);
    --ease-spring: cubic-bezier(.34, 1.28, .64, 1);
`;function Ie(e){let t=q[e],n=[`--sheet: ${t.sheet};`,`--raised: ${t.raised};`,`--text: ${t.text};`,`--text-muted: ${t.textMuted};`,`--text-dim: ${t.textDim};`,`--text-faint: ${t.textFaint};`,`--border: ${t.border};`,`--border-faint: ${t.borderFaint};`,`--track: ${t.track};`,`--link: ${t.link};`,`--focus: ${t.link};`,`--beta: ${t.beta};`,`--beta-on: ${t.betaOn};`,`--scrim: ${t.scrim};`,`--elev-1: ${t.elev1};`,`--elev-2: ${t.elev2};`,`--elev-3: ${t.elev3};`,`color-scheme: ${e};`];for(let[r,o]of Object.entries(ga)){let a=o[e];n.push(`--tone-${r}-text: ${a.text};`,`--tone-${r}-fill: ${a.fill};`,`--tone-${r}-surface: ${a.surface};`,`--tone-${r}-border: ${a.border};`,`--tone-${r}-on-surface: ${a.onSurface};`)}for(let[r,o]of Object.entries(ha))n.push(`--grade-${r}-text: ${o.text[e]};`,`--grade-${r}-size: ${o.size};`);return n.map(r=>`    ${r}`).join(`
`)}function Pe(e=":host"){let t=n=>e.startsWith(":host")?`${e}([data-theme="${n}"])`:`${e}[data-theme="${n}"]`;return`
  ${e} {
${va}
${Ie("light")}
  }

  @media (prefers-color-scheme: dark) {
    ${e} {
${Ie("dark")}
    }
  }

  ${t("light")} {
${Ie("light")}
  }

  ${t("dark")} {
${Ie("dark")}
  }
`}function i(e,t,n){let r=document.createElement(e);return t&&(r.className=t),n!==void 0&&(r.textContent=n),r}function S(e){return e==null?"n/a":`$${Math.round(e/100).toLocaleString("en-US")}`}function Gn(){return typeof matchMedia=="function"&&matchMedia("(prefers-reduced-motion: reduce)").matches}function ne(e,t){let n=Math.max(0,Math.min(1,Number.isFinite(t)?t:0));return e.dataset.fill=`${n*100}%`,e}function Kn(e){let t=Array.from(e.querySelectorAll("[data-fill]")),n=()=>{for(let r of t)r.style.width=r.dataset.fill??"0%"};typeof requestAnimationFrame=="function"?requestAnimationFrame(()=>requestAnimationFrame(n)):n()}function U(e,t){let n=i("span","chip");return n.dataset.tone=e,n.append(i("span","chip-glyph",N[e]),i("span",void 0,t)),n}function Yn(e,t,n){let r=i("div","callout");r.dataset.tone=e;let o=i("h3");o.append(i("span","callout-glyph",N[e]),i("span",void 0,t)),r.append(o);for(let a of n)r.append(typeof a=="string"?i("p",void 0,a):a);return r}function L(e,t,n,r){let o=i("details","disclosure"),a=i("summary"),s=i("span","disclosure-title",e);a.append(s),r&&a.append(r),t!==""&&a.append(typeof t=="string"?i("span","disclosure-summary",t):t);let l=i("div","disclosure-body");return l.append(...n),o.append(a,l),o}function re(e,t){let n=i("div","note-pill"),r=i("div","note-pill-body");return r.append(i("span",void 0,e)),t&&r.append(i("span","note-pill-source",t)),n.append(i("span","note-pill-glyph","\u24D8"),r),n}function dt(){let e=i("span","ai-badge");return e.title="Written by Claude for this model and mileage.",e.append(i("span","ai-badge-glyph","\u2726"),i("span",void 0,"AI")),e}function Jn(e,t,n,r){if(t.length===0)return null;let o=i("section"),a=i("h2",void 0,e);if(n||r){let s=i("div","section-heading-row");s.append(a),n&&s.append(n),r&&s.append(r),o.append(s,...t)}else o.append(a,...t);return o}function G(e,t){if(e.length===0)return null;let n=i("ul",t);for(let r of e)n.append(i("li",void 0,r));return n}function pt(e){let t=i("dl","rows");for(let[n,r,o]of e){let a=i("dd",o?.big?"big":void 0);o?.tone?(a.dataset.tone=o.tone,a.append(i("span","row-glyph",N[o.tone]),i("span",void 0,r))):a.textContent=r,t.append(i("dt",void 0,n),a)}return t}function oe(e,t,n="neutral",r){let o=i("div","stat");o.dataset.tone=n;let a=i("div","stat-figure");return n!=="neutral"&&a.append(i("span","stat-glyph",N[n])),a.append(i("span","stat-value",t)),o.append(a,i("div","stat-label",e)),r&&o.append(i("p","stat-note",r)),o}function Wn(e,t,n,r="neutral"){let o=i("div","meter-row"),a=i("div","meter-head");a.append(i("span","meter-label",e),i("span","meter-value",t));let s=i("div","meter"),l=i("i");return l.dataset.tone=r,s.append(ne(l,n)),o.append(a,s),o}function Ne(e,t="Copy"){let n=i("button","copy");n.type="button";let r=i("span","copy-glyph","\u29C9"),o=i("span",void 0,t);n.append(r,o);let a,s=(l,c,u)=>{n.dataset.state=l,r.textContent=u,o.textContent=c,a&&clearTimeout(a),a=setTimeout(()=>{delete n.dataset.state,r.textContent="\u29C9",o.textContent=t},1600)};return n.addEventListener("click",l=>{l.preventDefault(),l.stopPropagation(),navigator.clipboard?.writeText(e).then(()=>s("done","Copied",N.favorable)).catch(()=>s("failed","Press \u2318C",N.caution))}),n}function mt(e,t="Open listing"){let n=i("a");return n.href=e,n.target="_blank",n.rel="noopener noreferrer",n.textContent=t,n.append(i("span","link-arrow","\u2192")),n}var Xn=`
  section { padding: var(--sp-5) var(--sp-6); border-bottom: 1px solid var(--border-faint); }
  h2 {
    margin: 0 0 var(--sp-4); font-size: var(--fs-xs); font-weight: 700;
    letter-spacing: .08em; text-transform: uppercase; color: var(--text-dim);
  }
  .section-heading-row {
    display: flex; align-items: center; gap: var(--sp-3); margin: 0 0 var(--sp-4);
  }
  .section-heading-row h2 { margin: 0; }

  /* rows -------------------------------------------------------------- */
  .rows {
    display: grid; grid-template-columns: auto 1fr;
    gap: var(--sp-2) var(--sp-5); font-size: var(--fs-base);
    align-items: baseline;
  }
  .rows dt { color: var(--text-dim); }
  .rows dd {
    margin: 0; font-family: var(--font-num);
    font-variant-numeric: tabular-nums; font-feature-settings: "tnum" 1;
  }
  .rows dd.big {
    font-size: var(--fs-md); font-weight: 650; letter-spacing: -.01em; color: var(--text);
  }
  .rows dd[data-tone] { display: flex; align-items: baseline; gap: var(--sp-2); }
  .rows dd[data-tone="favorable"] { color: var(--tone-favorable-text); }
  .rows dd[data-tone="caution"]   { color: var(--tone-caution-text); }
  .rows dd[data-tone="adverse"]   { color: var(--tone-adverse-text); }
  .row-glyph { font-size: var(--fs-xs); }

  ul {
    margin: var(--sp-3) 0 0; padding-left: var(--sp-5);
    font-size: var(--fs-sm); line-height: 1.55; color: var(--text-muted);
  }
  li { margin-bottom: var(--sp-1); }
  li::marker { color: var(--text-faint); }
  .muted {
    color: var(--text-dim); font-size: var(--fs-sm); line-height: 1.5; margin: var(--sp-3) 0 0;
  }

  /* callout ----------------------------------------------------------- */
  .callout {
    position: relative; overflow: hidden;
    border: 1px solid; border-radius: var(--radius-md);
    padding: var(--sp-4) var(--sp-4) var(--sp-4) var(--sp-5);
    margin: 0 0 var(--sp-4);
  }
  /* A left rail as well as a tint. On light the tint alone is a very pale
     wash, and a pale wash is not a warning. */
  .callout::before {
    content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 3px;
    background: currentColor; opacity: .85;
  }
  .callout h3 {
    margin: 0 0 var(--sp-2); font-size: var(--fs-base); font-weight: 650;
    display: flex; align-items: baseline; gap: var(--sp-2);
  }
  .callout p { margin: 0; font-size: var(--fs-sm); line-height: 1.5; }
  .callout p + p { margin-top: var(--sp-2); }
  .callout ul { color: inherit; }
  .callout-glyph { font-size: var(--fs-sm); }
  .callout[data-tone="adverse"] {
    background: var(--tone-adverse-surface); border-color: var(--tone-adverse-border);
    color: var(--tone-adverse-on-surface);
  }
  .callout[data-tone="adverse"] h3, .callout[data-tone="adverse"]::before {
    color: var(--tone-adverse-text);
  }
  .callout[data-tone="caution"] {
    background: var(--tone-caution-surface); border-color: var(--tone-caution-border);
    color: var(--tone-caution-on-surface);
  }
  .callout[data-tone="caution"] h3, .callout[data-tone="caution"]::before {
    color: var(--tone-caution-text);
  }
  .callout[data-tone="favorable"] {
    background: var(--tone-favorable-surface); border-color: var(--tone-favorable-border);
    color: var(--tone-favorable-on-surface);
  }
  .callout[data-tone="favorable"] h3, .callout[data-tone="favorable"]::before {
    color: var(--tone-favorable-text);
  }
  .callout[data-tone="neutral"] {
    background: var(--raised); border-color: var(--border); color: var(--text-muted);
  }
  .callout[data-tone="neutral"]::before { color: var(--border); }

  /* disclosure -------------------------------------------------------- */
  .disclosure { border-bottom: 1px solid var(--border-faint); }
  .disclosure > summary {
    display: flex; align-items: center; gap: var(--sp-3); flex-wrap: wrap;
    padding: var(--sp-4) var(--sp-6); cursor: pointer; list-style: none;
    transition: background var(--dur-fast) var(--ease-out);
  }
  .disclosure > summary::-webkit-details-marker { display: none; }
  /* A chevron rather than +/-: it rotates, so opening and closing is one
     continuous motion instead of a glyph swap. */
  .disclosure > summary::after {
    content: ""; margin-left: auto; flex: none;
    width: 6px; height: 6px; margin-right: 2px;
    border-right: 1.5px solid var(--text-faint);
    border-bottom: 1.5px solid var(--text-faint);
    transform: translateY(-2px) rotate(45deg);
    transition: transform var(--dur-base) var(--ease-out), border-color var(--dur-fast);
  }
  .disclosure[open] > summary::after { transform: translateY(1px) rotate(-135deg); }
  .disclosure > summary:hover { background: var(--raised); }
  .disclosure > summary:hover::after { border-color: var(--text-dim); }
  .disclosure-title {
    font-size: var(--fs-xs); font-weight: 700; letter-spacing: .08em;
    text-transform: uppercase; color: var(--text-dim); flex: none;
    transition: color var(--dur-fast) var(--ease-out);
  }
  .disclosure > summary:hover .disclosure-title { color: var(--text); }
  .disclosure-summary { font-size: var(--fs-sm); color: var(--text-muted); }
  .disclosure-body { padding: var(--sp-1) var(--sp-6) var(--sp-5); }

  /* Chrome 131+ animates a <details> through ::details-content; everything
     older ignores both rules and opens instantly, which is the same behaviour
     the panel has today. Progressive, so the manifest's minimum stays put. */
  @supports (interpolate-size: allow-keywords) {
    .disclosure, .component { interpolate-size: allow-keywords; }
    .disclosure::details-content, .component::details-content {
      block-size: 0; opacity: 0; overflow: clip;
      transition: block-size var(--dur-base) var(--ease-out),
                  content-visibility var(--dur-base) allow-discrete,
                  opacity var(--dur-fast) var(--ease-out);
    }
    .disclosure[open]::details-content, .component[open]::details-content {
      block-size: auto; opacity: 1;
    }
  }

  /* stat tile --------------------------------------------------------- */
  .stat {
    display: inline-flex; flex-direction: column; gap: 2px;
    padding: var(--sp-3) var(--sp-4); border-radius: var(--radius-md);
    border: 1px solid var(--border); background: var(--raised);
    min-width: 104px;
  }
  .stat-figure { display: flex; align-items: baseline; gap: var(--sp-2); }
  .stat-value {
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-lg); font-weight: 650; line-height: 1.1; letter-spacing: -.02em;
    color: var(--text);
  }
  .stat-glyph { font-size: var(--fs-sm); }
  .stat-label {
    font-size: var(--fs-xs); letter-spacing: .04em; text-transform: uppercase;
    color: var(--text-dim);
  }
  .stat-note {
    margin: var(--sp-2) 0 0; font-size: var(--fs-sm); line-height: 1.45; color: var(--text-muted);
  }
  .stat[data-tone="favorable"] {
    border-color: var(--tone-favorable-border); background: var(--tone-favorable-surface);
  }
  .stat[data-tone="favorable"] .stat-value,
  .stat[data-tone="favorable"] .stat-glyph { color: var(--tone-favorable-text); }
  .stat[data-tone="caution"] {
    border-color: var(--tone-caution-border); background: var(--tone-caution-surface);
  }
  .stat[data-tone="caution"] .stat-value,
  .stat[data-tone="caution"] .stat-glyph { color: var(--tone-caution-text); }
  .stat[data-tone="adverse"] {
    border-color: var(--tone-adverse-border); background: var(--tone-adverse-surface);
  }
  .stat[data-tone="adverse"] .stat-value,
  .stat[data-tone="adverse"] .stat-glyph { color: var(--tone-adverse-text); }

  /* meter ------------------------------------------------------------- */
  .meter-row { margin-top: var(--sp-3); }
  .meter-row:first-child { margin-top: 0; }
  .meter-head {
    display: flex; justify-content: space-between; align-items: baseline; gap: var(--sp-4);
    font-size: var(--fs-sm); color: var(--text-muted); margin-bottom: var(--sp-1);
  }
  .meter-label { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .meter-value {
    flex: none; font-family: var(--font-num); font-variant-numeric: tabular-nums;
    color: var(--text-dim);
  }
  .meter {
    height: 6px; border-radius: var(--radius-pill); background: var(--track); overflow: hidden;
  }
  .meter > i {
    display: block; height: 100%; width: 0; border-radius: inherit;
    background: var(--tone-neutral-fill);
    transition: width var(--dur-slow) var(--ease-out);
  }
  .meter > i[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .meter > i[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .meter > i[data-tone="adverse"]   { background: var(--tone-adverse-fill); }

  /* copy button ------------------------------------------------------- */
  .copy {
    display: inline-flex; align-items: center; gap: var(--sp-1);
    font: 600 var(--fs-xs)/1 var(--font-sans);
    padding: var(--sp-1) var(--sp-3); border-radius: var(--radius-pill);
    border: 1px solid var(--border); background: var(--raised); color: var(--text-dim);
    cursor: pointer;
    transition: color var(--dur-fast) var(--ease-out),
                border-color var(--dur-fast) var(--ease-out),
                transform var(--dur-fast) var(--ease-out);
  }
  .copy:hover { color: var(--text); border-color: var(--text-faint); }
  .copy:active { transform: scale(.96); }
  .copy-glyph { font-size: var(--fs-2xs); }
  .copy[data-state="done"] {
    color: var(--tone-favorable-text); border-color: var(--tone-favorable-border);
    background: var(--tone-favorable-surface);
  }
  .copy[data-state="failed"] {
    color: var(--tone-caution-text); border-color: var(--tone-caution-border);
    background: var(--tone-caution-surface);
  }

  /* note pill ----------------------------------------------------------- */
  .note-pill {
    display: flex; align-items: flex-start; gap: var(--sp-3);
    margin-top: var(--sp-4);
    padding: var(--sp-4) var(--sp-5);
    border-radius: var(--radius-lg);
    background: var(--tone-neutral-surface);
    border: 1px solid var(--tone-neutral-border);
    color: var(--tone-neutral-on-surface);
    font-size: var(--fs-xs);
    line-height: 1.55;
  }
  .note-pill-glyph {
    flex: none; font-size: var(--fs-sm); line-height: 1.55; color: var(--tone-neutral-text);
  }
  .note-pill-body { display: flex; flex-direction: column; gap: var(--sp-2); }
  .note-pill-source { color: var(--text-faint); font-size: var(--fs-2xs); }

  /* badges and links -------------------------------------------------- */
  .ai-badge {
    display: inline-flex; align-items: center; gap: var(--sp-1); flex: none;
    font-size: var(--fs-2xs); font-weight: 700; letter-spacing: .03em;
    padding: 2px 7px; border-radius: var(--radius-pill); color: #fff;
    background: linear-gradient(135deg, #7c5cff, #4f9eff 55%, #34d8c9);
    box-shadow: 0 0 0 1px rgba(255,255,255,.14) inset;
  }
  .ai-badge-glyph { font-size: 9.5px; }

  a {
    color: var(--link); text-decoration: none; word-break: break-word;
    font-size: var(--fs-sm); font-weight: 600;
    display: inline-flex; align-items: baseline; gap: var(--sp-1);
  }
  a:hover { text-decoration: underline; }
  .link-arrow {
    font-size: .9em; transition: transform var(--dur-fast) var(--ease-out);
  }
  a:hover .link-arrow { transform: translateX(2px); }
`;function er(e){let{confidence:t}=e.pricing;return t==="low"||t==="none"?"unreliable":"confident"}function tr(e){switch(e){case"high":return"favorable";case"medium":return"caution";default:return"adverse"}}var He=["trim_disagreement","wrong_market","no_estimate","comp_count","no_mileage_adjustment","trim_unknown","widened_year_window","outlier_sensitive","weak_mileage_fit","mileage_extrapolation","wide_interval","adverse_selection","dealer_filtering_unavailable","no_recency_weighting"];function ba(e,t){switch(e){case"trim_disagreement":return"most comparable listings look like a different trim";case"wrong_market":return"the comparable listings are not from this vehicle's area";case"no_estimate":return"there are too few comparable listings to price this at all";case"comp_count":return t.comps_included===1?"only 1 comparable listing was usable":`only ${t.comps_included} comparable listings were usable`;case"no_mileage_adjustment":return"no mileage adjustment was possible, so this is a plain median";case"trim_unknown":return"trim is unknown for most of the comparable listings";case"widened_year_window":return`the search had to widen to a ${t.year_window}-year window`;case"outlier_sensitive":return"one or two listings are holding up the whole estimate";case"weak_mileage_fit":return"mileage barely explains the spread in asking prices";case"mileage_extrapolation":return"this car's mileage sits outside the range the comps cover";case"wide_interval":return"the comparable asks are spread too widely to narrow";case"adverse_selection":return"the ask is far below the comps with nothing explaining why";case"dealer_filtering_unavailable":return"dealer listings could not be filtered out";case"no_recency_weighting":return"the comps carry no posted dates, so stale asks count fully";default:return e.replace(/_/g," ")}}function nr(e,t=2){return[...e.confidence_limiters].sort((r,o)=>{let a=He.indexOf(r),s=He.indexOf(o);return(a===-1?He.length:a)-(s===-1?He.length:s)}).slice(0,t).map(r=>ba(r,e))}function ft(e){return`$${Math.round(e/100).toLocaleString("en-US")}`}function rr(e){let{asking_interval_low_cents:t,asking_interval_high_cents:n}=e,r=e.ask_cents;return t===null||n===null||r===null?null:`${e.comps_included} comparable listings suggest ${ft(t)}\u2013${ft(n)}. This asks ${ft(r)}.`}var Qn=.08;function or(e){let t=e.asking_interval_low_cents,n=e.asking_interval_high_cents;if(t===null||n===null||n<t)return null;let r=e.ask_cents,o=e.strong_offer_cents,a=e.walk_away_above_cents,s=[t,n,r,o,a].filter(m=>m!==null&&Number.isFinite(m)),l=Math.min(...s),c=Math.max(...s),u=c-l||Math.max(c*.1,1),d=l-u*Qn,p=c+u*Qn,f=m=>m===null?null:(m-d)/(p-d);return{min:d,max:p,band:{start:f(t),end:f(n)},ask:f(r),strongOffer:f(o),walkAway:f(a),askTone:xa(r,t,n,a)}}function xa(e,t,n,r){return e===null?"neutral":r!==null&&e>r?"adverse":e>n?"caution":e<t?"favorable":"neutral"}function ar(e,t){if(e===null||t===null)return null;let n=Math.round((e-t)/100);if(n===0)return{text:"same price",tone:"neutral"};let r=`$${Math.abs(n).toLocaleString("en-US")}`;return n<0?{text:`${r} less`,tone:"favorable"}:{text:`${r} more`,tone:"caution"}}function sr(e){let[t]=e.split(" - "),n=t?.trim();return n&&n.length>0?n:e}function $e(e){return e==="strong"?"favorable":e==="moderate"?"caution":"neutral"}var ya=1,gt=14,ht=30,vt=75,_a=90;function ir(e){if(e===null||e<0)return null;let t=Math.max(_a,Math.ceil(e*1.15)),n=r=>Math.max(0,Math.min(1,r/t));return{days:e,position:n(e),marks:[{position:n(gt),label:`${gt}d`},{position:n(ht),label:`${ht}d`},{position:n(vt),label:`${vt}d`}],phase:ka(e)}}function ka(e){return e<ya?"just listed, so everyone who saw it is still looking":e<gt?"still fresh, and early interest has not passed":e<ht?"past the first rush of interest":e<vt?"sat longer than a car that is priced right usually does":"unsold for months at this price"}function lr(e){let{offer:t}=e,n=t.opening_cents,r=t.target_cents;if(n===null||r===null)return null;let o=$e(e.leverage),a=[];return n===r?a.push({label:t.stance==="pay_near_asking"?"Offer their ask":"Offer",cents:n,lead:!0,tone:o}):(a.push({label:"Open at",cents:n,lead:!0,tone:o}),a.push({label:t.stance==="pay_near_asking"?"Their ask":"Expect to pay",cents:r,lead:!1,tone:"neutral"})),t.walk_away_cents!==null&&a.push({label:"Walk away above",cents:t.walk_away_cents,lead:!1,tone:"caution"}),a}function ur(e){switch(e){case"negotiate":return{tone:"favorable",label:"room to negotiate"};case"pay_near_asking":return{tone:"caution",label:"little to argue down"};case"stretch":return{tone:"adverse",label:"asking well over the comps"};default:return null}}var Zn=["price_residual","vehicle_risk","seller_and_scam_risk","information_completeness"];function cr(e){let n=e.filter(o=>o.value!==null).reduce((o,a)=>o+a.weight,0);return e.map(o=>{let a=n>0?o.weight/n*100:0,s=o.value===null||n<=0?null:a*o.value/100;return{component:o,points:s,maxPoints:a}}).sort((o,a)=>{let s=l=>{let c=Zn.indexOf(l);return c===-1?Zn.length:c};return s(o.component.name)-s(a.component.name)})}function dr(e){return e===null?"neutral":e>=70?"favorable":e>=45?"caution":"adverse"}function bt(e){return e>=85?"excellent":e>=75?"good":e>=65?"fair":e>=55?"weak":"poor"}function xt(e){return e!==null&&!e.startsWith("deployment_")}function wa(e){try{return j(e)}catch(t){return Promise.reject(t instanceof Error?t:new Error(String(t)))}}function mr(e){let t=[i("p","known-summary",e.summary)],n=[["Known to go wrong",e.failure_modes],["Check on the viewing",e.inspect],["Living with it",e.ownership_notes]];for(let[o,a]of n){let s=G(a);s&&t.push(i("p","muted",o),s)}let r=G(e.ask);if(r){t.push(i("p","muted","Questions to ask the seller"));let o=i("div","questions-actions");o.append(Ne(e.ask.join(`
`),"Copy all")),t.push(o,r)}else t.push(i("p","muted","No vehicle-specific questions -- the standard checklist (title, service history, accident history) covers this one."));return t}function pr(e){let t=i("button","ai-insights-retry","Try again");return t.type="button",t.addEventListener("click",n=>{n.preventDefault(),e()}),t}function Ea(e){let t=L("AI Insights","",[i("p","muted","Open this to ask Claude what's documented to go wrong with this vehicle, what to check on the viewing, and what to ask the seller.")],dt()),n=t.querySelector(".disclosure-body"),r="idle",o=l=>n.replaceChildren(...l),a=()=>{r==="idle"&&(r="loading",o([i("p","muted","Generating\u2026")]),wa({type:"FETCH_KNOWN_ISSUES",captureId:e}).then(l=>{if(r="settled",!l.ok){o([i("p","muted",l.error),pr(s)]);return}let c=l.result;if(c.known_issues){o(mr(c.known_issues));return}if(c.known_issues_unavailable_reason&&xt(c.known_issues_unavailable_code)){o([i("p","muted",c.known_issues_unavailable_reason)]);return}o([i("p","muted","No known-issue data available for this vehicle.")])}).catch(()=>{r="settled",o([i("p","muted","Could not reach the server."),pr(s)])}))},s=()=>{r="idle",a()};return t.addEventListener("toggle",()=>{t.open&&a()}),t}function fr(e){return e.known_issues?L("AI Insights","",mr(e.known_issues),dt()):e.known_issues_unavailable_reason&&xt(e.known_issues_unavailable_code)?L("AI Insights","",[i("p","muted",e.known_issues_unavailable_reason)]):e.known_issues_pending?Ea(e.capture_id):null}var gr=`
  .known-summary {
    margin: 0 0 var(--sp-2); font-size: var(--fs-base); line-height: 1.55; color: var(--text-muted);
  }
  .questions-actions { display: flex; justify-content: flex-end; margin-bottom: var(--sp-1); }

  .ai-insights-retry {
    margin-top: var(--sp-3);
    display: inline-flex; align-items: center;
    font: 600 var(--fs-xs)/1 var(--font-sans);
    padding: var(--sp-2) var(--sp-4); border-radius: var(--radius-pill);
    border: 1px solid var(--border); background: var(--raised); color: var(--text-dim);
    cursor: pointer;
    transition: color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out);
  }
  .ai-insights-retry:hover { color: var(--text); border-color: var(--text-faint); }
`;function Be(e){try{return j(e)}catch(t){return Promise.reject(t instanceof Error?t:new Error(String(t)))}}var Ta="https://app.curbsidescore.com/saved",br="app.curbsidescore.com",De={unknown:"\u2606","signed-out":"\u2606","not-saved":"\u2606",saved:"\u2605",busy:"\u2606"},hr={unknown:"Save","signed-out":"Save","not-saved":"Save",saved:"Saved",busy:"Save"},vr={unknown:"Save this evaluation","signed-out":"Save this evaluation","not-saved":"Save this evaluation",saved:"Saved \u2014 click to remove",busy:"Working\u2026"},yt={unsaved:"Save this evaluation and read it back on any device at",saved:"Saved. It is waiting with your other saved listings at"};function Sa(e,t){e.replaceChildren(),e.dataset.open="true";let n=i("form","signin"),r=i("p","signin-title","Save this evaluation"),o=i("p","signin-blurb",`Saved evaluations are kept as a snapshot of what this tool said today, and you can read them back at ${br}. No password \u2014 we email you a code.`),a=i("input","signin-input");a.type="email",a.required=!0,a.placeholder="you@example.com",a.setAttribute("aria-label","Email address");let s=i("input","signin-input");s.type="text",s.placeholder="ABCD-2345",s.autocomplete="one-time-code",s.setAttribute("aria-label","Sign-in code"),s.hidden=!0;let l=i("button","signin-submit","Email me a code");l.type="submit";let c=i("p","signin-message");c.setAttribute("role","status"),c.setAttribute("aria-live","polite");let u=i("button","signin-cancel","Not now");u.type="button",u.addEventListener("click",()=>{e.replaceChildren(),delete e.dataset.open});let d="email",p=v=>{l.disabled=v,a.disabled=v,s.disabled=v},f=v=>{c.textContent=v,c.dataset.tone="error"};n.addEventListener("submit",v=>{v.preventDefault();let b=a.value.trim();if(!b)return;if(p(!0),c.dataset.tone="info",d==="email"){c.textContent="Sending\u2026",Be({type:"AUTH_REQUEST_CODE",email:b}).then(y=>{if(p(!1),!y.ok){f(y.error);return}d="code",s.hidden=!1,s.focus(),l.textContent="Sign in",c.dataset.tone="info",c.textContent=`Code sent to ${b}. It expires shortly.`}).catch(()=>{p(!1),f("Could not reach the server.")});return}let h=s.value.trim();if(!h){p(!1);return}c.textContent="Checking\u2026",Be({type:"AUTH_VERIFY_CODE",email:b,code:h}).then(y=>{if(p(!1),!y.ok){f(y.error),s.select();return}e.replaceChildren(),delete e.dataset.open,t()}).catch(()=>{p(!1),f("Could not reach the server.")})});let m=i("div","signin-actions");m.append(l,u),n.append(r,o,a,s,m,c),e.append(n),a.focus()}function Aa(){let e=i("div","saved-strip"),t=i("span","saved-strip-glyph",De["not-saved"]),n=i("p","saved-strip-text"),r=i("span",void 0,`${yt.unsaved} `),o=i("a","saved-strip-link");return o.href=Ta,o.target="_blank",o.rel="noopener noreferrer",o.textContent=br,o.append(i("span","link-arrow","\u2197")),n.append(r,o),e.append(t,n),{node:e,lead:r,glyph:t}}function xr(e){let t=i("button","bookmark");t.type="button";let n=i("span","bookmark-glyph",De["not-saved"]),r=i("span","bookmark-word",hr["not-saved"]);t.append(n,r);let o=Aa(),a=i("div","signin-panel"),s="unknown",l=()=>{let d=s==="saved";n.textContent=De[s],r.textContent=hr[s],t.dataset.state=s,t.title=vr[s],t.setAttribute("aria-label",vr[s]),t.setAttribute("aria-pressed",String(d)),t.disabled=s==="busy",o.node.dataset.state=d?"saved":"unsaved",o.glyph.textContent=De[d?"saved":"not-saved"],o.lead.textContent=`${d?yt.saved:yt.unsaved} `},c=d=>{if(!d.ok){s=s==="busy"?"not-saved":s,l(),t.title=d.error;return}s=d.signedIn?d.saved?"saved":"not-saved":"signed-out",l()},u=()=>{let d=s!=="saved";s="busy",l(),Be({type:d?"SAVE_EVALUATION":"UNSAVE_EVALUATION",captureId:e}).then(c).catch(()=>c({ok:!1,error:"Could not reach the server."}))};return t.addEventListener("click",()=>{if(s!=="busy"){if(s==="signed-out"||s==="unknown"){Sa(a,u);return}u()}}),l(),Be({type:"SAVED_STATE",captureId:e}).then(c).catch(()=>{}),{button:t,strip:o.node,panel:a}}var yr=`
  /* A pill, not a 28px icon well like .close and .theme-toggle. Those two act
     on the panel and are self-evident from their glyphs; this one acts on the
     evaluation and is the only header control with somewhere to send you, so it
     carries its word and a filled surface -- the header's one element that
     should read as offering something rather than dismissing it. */
  .bookmark {
    display: inline-flex; align-items: center; gap: var(--sp-2); flex: none;
    height: 28px; padding: 0 var(--sp-3); box-sizing: border-box;
    background: var(--raised); border: 1px solid var(--border);
    border-radius: var(--radius-pill);
    color: var(--text-dim); cursor: pointer;
    font: 650 var(--fs-xs)/1 var(--font-sans); letter-spacing: .03em;
    transition: color var(--dur-fast) var(--ease-out),
                background var(--dur-fast) var(--ease-out),
                border-color var(--dur-fast) var(--ease-out),
                transform var(--dur-fast) var(--ease-out);
  }
  .bookmark-glyph { font-size: var(--fs-md); line-height: 1; }
  .bookmark-word { white-space: nowrap; }
  .bookmark:hover:not(:disabled) { color: var(--text); border-color: var(--text-faint); }
  .bookmark:active:not(:disabled) { transform: scale(.96); }
  .bookmark[data-state="saved"] {
    color: var(--tone-favorable-text);
    background: var(--tone-favorable-surface);
    border-color: var(--tone-favorable-border);
  }
  .bookmark:disabled { opacity: .6; cursor: default; }

  /* The strip under the header. A left rail in the LINK colour rather than a
     tone: it is not a judgement about the vehicle (tokens.ts rule 2), it is a
     place to go, and that is the one thing the header could not say. */
  .saved-strip {
    display: flex; align-items: baseline; gap: var(--sp-3);
    padding: var(--sp-3) var(--sp-6);
    background: var(--raised);
    border-bottom: 1px solid var(--border);
    box-shadow: inset 3px 0 0 var(--link);
  }
  .saved-strip[data-state="saved"] {
    background: var(--tone-favorable-surface);
    border-bottom-color: var(--tone-favorable-border);
    box-shadow: inset 3px 0 0 var(--tone-favorable-fill);
  }
  .saved-strip-glyph { flex: none; font-size: var(--fs-sm); color: var(--text-dim); }
  .saved-strip[data-state="saved"] .saved-strip-glyph { color: var(--tone-favorable-text); }
  .saved-strip-text {
    margin: 0; font-size: var(--fs-xs); line-height: 1.55; color: var(--text-muted);
  }
  /* Inherits the strip's size rather than the panel's default link size, so the
     URL sits in the sentence instead of standing a step above it. */
  .saved-strip-link { font-size: inherit; }

  .signin-panel { display: none; }
  .signin-panel[data-open="true"] {
    display: block;
    padding: var(--sp-5) var(--sp-6);
    background: var(--raised);
    border-bottom: 1px solid var(--border);
  }

  .signin-title {
    margin: 0 0 var(--sp-2); font-size: var(--fs-sm); font-weight: 700; color: var(--text);
  }
  .signin-blurb {
    margin: 0 0 var(--sp-4); font-size: var(--fs-xs); line-height: 1.5; color: var(--text-faint);
  }
  .signin-input {
    display: block; width: 100%; box-sizing: border-box;
    margin: 0 0 var(--sp-3); padding: var(--sp-3);
    font: inherit; font-size: var(--fs-sm);
    color: var(--text); background: var(--sheet);
    border: 1px solid var(--border); border-radius: var(--radius-sm);
  }
  .signin-input:disabled { opacity: .6; }

  .signin-actions { display: flex; align-items: center; gap: var(--sp-3); }
  .signin-submit {
    padding: var(--sp-3) var(--sp-4);
    font: inherit; font-size: var(--fs-sm); font-weight: 600;
    color: var(--sheet); background: var(--text);
    border: none; border-radius: var(--radius-sm); cursor: pointer;
  }
  .signin-submit:disabled { opacity: .6; cursor: default; }
  .signin-cancel {
    padding: var(--sp-3) var(--sp-2);
    font: inherit; font-size: var(--fs-sm);
    color: var(--text-faint); background: none; border: none; cursor: pointer;
  }
  .signin-cancel:hover { color: var(--text); }

  .signin-message {
    margin: var(--sp-3) 0 0; font-size: var(--fs-xs); line-height: 1.45;
    color: var(--text-faint);
  }
  .signin-message[data-tone="error"] { color: var(--tone-adverse-text); }
  .signin-message:empty { display: none; }
`;var _r=.16;function _t(e,t,n){let r=i("div",e);return r.style.left=`${Math.max(0,Math.min(1,t))*100}%`,r.title=n,r}function Ma(e,t){let n=i("div","gauge");n.setAttribute("role","img"),n.setAttribute("aria-label",`Asking ${S(t.ask_cents)} against an expected range of ${S(t.asking_interval_low_cents)} to ${S(t.asking_interval_high_cents)}.`);let r=i("div","gauge-ask-row");if(e.ask!==null){let l=i("div","gauge-ask-label");l.dataset.tone=e.askTone,l.style.left=`${e.ask*100}%`,e.ask<_r?l.dataset.align="start":e.ask>1-_r&&(l.dataset.align="end"),l.append(i("span","gauge-ask-value",S(t.ask_cents)),i("span","gauge-ask-caption","asking")),r.append(l)}let o=i("div","gauge-track"),a=i("div","gauge-band");if(a.style.left=`${e.band.start*100}%`,a.title=`Expected asking ${S(t.asking_interval_low_cents)} \u2013 ${S(t.asking_interval_high_cents)}`,ne(a,e.band.end-e.band.start),o.append(a),e.strongOffer!==null&&o.append(_t("gauge-tick",e.strongOffer,`Strong offer ${S(t.strong_offer_cents)}`)),e.walkAway!==null&&o.append(_t("gauge-tick",e.walkAway,`Walk away above ${S(t.walk_away_above_cents)}`)),e.ask!==null){let l=_t("gauge-ask",e.ask,`Asking ${S(t.ask_cents)}`);l.dataset.tone=e.askTone,o.append(l)}if(n.append(r,o),t.strong_offer_cents!==null||t.walk_away_above_cents!==null){let l=i("div","gauge-caption");t.strong_offer_cents!==null&&l.append(i("span",void 0,`Strong offer ${S(t.strong_offer_cents)}`)),t.walk_away_above_cents!==null&&l.append(i("span","gauge-caption-end",`Walk away above ${S(t.walk_away_above_cents)}`)),n.append(l)}let s=i("div","gauge-legend");return s.append(i("span","gauge-swatch"),i("span",void 0,`Expected asking ${S(t.asking_interval_low_cents)} \u2013 ${S(t.asking_interval_high_cents)}`)),n.append(s),n}function Sr(e){let t=e.pricing,n=[],r=or(t);r&&n.push(Ma(r,t));let o=[["Current ask",S(t.ask_cents),{big:!0}]];return!r&&t.expected_asking_cents!==null&&o.push(["Expected asking",`${S(t.asking_interval_low_cents)} \u2013 ${S(t.asking_interval_high_cents)}`]),o.push(["Confidence",t.confidence,{tone:tr(t.confidence)}]),n.push(pt(o)),n}function Ar(e){let{present:t,missing:n}=e.completeness,r=[i("p","muted",n.length===0?"The seller disclosed everything this tool looks for.":`Not stated: ${n.join(", ")}.`)];return t.length&&r.push(i("p","muted",`Stated: ${t.join(", ")}.`)),r}var Ra={unexplained_deep_discount:"Priced far below comparable listings with no explanation in the description.",few_or_stock_photos:"Very few photos for a vehicle at this price.",minimal_description:"Description is minimal or looks templated.",vin_omitted_from_detailed_listing:"The listing is detailed in every other respect but omits the VIN.",payment_or_meeting_red_flags:"Payment or meeting terms that legitimate private sellers rarely ask for."};function kr(e){return Ra[e]??e.replace(/_/g," ")}var wr=4,La=3,Er={two:"Seller states this vehicle has had two owners.",three_plus:"Seller states this vehicle has had three or more owners."};function Tr(e,t){return re(e!==void 0&&t!==void 0?`${e} of the ${t} patterns this tool looks for could not be checked on this listing, so a low count is weaker evidence than it looks.`:"Two of the patterns this tool looks for can never be checked yet, so a clean result here is weaker evidence than it looks.","Price-drop history needs months of observations; seller account age is deliberately never collected.")}function Ca(e){let t=e.seller_risk;if(!t)return[oe("Patterns fired","None","favorable"),i("p","muted","None of the scam patterns this tool can check fired on this listing, and the seller has no rating low enough to note."),Tr()];let n=t.scam_signals_fired,r=t.scam_signals_evaluable,o=[];if(t.scam_warning)o.push(Yn("adverse","Several scam patterns fired together",[`${n.length} independent patterns fired on this listing. Any one of them is weak. This many at once is not, and it is why no deal score is shown.`,G(n.map(kr))??i("span")]));else{o.push(oe("Patterns fired",`${n.length} of ${r}`,n.length===0?"favorable":"caution"));let s=G(n.map(kr));s?o.push(s):o.push(i("p","muted","None of the patterns this tool can check fired here."))}let a=t.scam_signals_total-r;return a>0&&o.push(Tr(a,t.scam_signals_total)),o}function Oa(e){let t=e.seller_risk,n=[],r=t?.seller_rating_average,o=t?.seller_rating_count??0;r!=null&&o>=La?n.push(oe(`Seller rating \xB7 ${o} review${o===1?"":"s"}`,`${r.toFixed(1)}/5`,r<wr?"adverse":"favorable",r<wr?"Low enough to cap this dimension's score regardless of how the listing reads.":void 0)):n.push(i("p","muted",o>0?`Only ${o} Marketplace review${o===1?"":"s"} \u2014 too few to read anything into.`:"This seller has no Marketplace rating yet."));let a=e.vehicle_details.owner_count;return a&&Er[a]&&n.push(i("p","muted",Er[a])),n}function Ia(e){let t=e.vehicle_risk;if(t.recall_count===null)return[i("p","muted","No recall data available for this vehicle.")];let n=[oe(t.recall_count===1?"Open recall campaign":"Open recall campaigns",`${t.recall_count}`,t.recall_count>0?"caution":"favorable")];return t.recall_count>0&&t.recall_messages[1]&&n.push(i("p","muted",t.recall_messages[1])),n}function Pa(e){let t=e.vehicle_risk;if(t.complaint_count===null)return[i("p","muted","No complaint data available for this vehicle.")];let n=[oe("Owner complaints filed",t.complaint_count.toLocaleString("en-US"))],r=t.top_complaint_components;if(r.length){let o=Math.max(...r.map(([,s])=>s),1);n.push(i("p","muted","Most complained-about systems"));let a=i("div","complaint-chart");for(let[s,l]of r)a.append(Wn(s.toLowerCase(),l.toLocaleString("en-US"),l/o));n.push(a)}return t.complaint_messages[0]&&n.push(i("p","muted",t.complaint_messages[0])),t.complaint_messages[1]&&n.push(re(t.complaint_messages[1],"Source: NHTSA complaints database, by year/make/model.")),n}function Mr(e){let t=[L("Recalls","",Ia(e)),L("Complaints","",Pa(e))],n=e.vehicle_risk.decoded_spec;return n&&t.push(L("Vehicle specification","",[pt([["VIN decode",n]])])),t}function Rr(e){let t=e.seller_risk;return[L("Scam patterns",t?`${t.scam_signals_fired.length} of ${t.scam_signals_evaluable} fired`:"none fired",Ca(e)),L("Seller","",Oa(e))]}function Lr(e){let t=e.negotiation,n=i("span","summary-inline");n.append(U($e(t.leverage),`${t.leverage} leverage`));let r=[];return t.days_listed!==null&&r.push(`listed ${t.days_listed} day${t.days_listed===1?"":"s"}`),t.offer.opening_cents!==null&&r.push(`open at ${S(t.offer.opening_cents)}`),n.append(i("span","disclosure-summary",r.join(" \xB7 ")||"no posted date and no asking price")),n}function Na(e,t){let n=i("div","ladder");n.dataset.steps=`${e.length}`;let r=i("div","ladder-rail");for(let a of e){let s=i("i","ladder-dot");s.dataset.tone=a.tone,r.append(s)}let o=i("div","ladder-cells");for(let a of e){let s=i("div","ladder-cell");a.lead&&(s.dataset.lead="true"),s.dataset.tone=a.tone,s.append(i("div","ladder-label",a.label),i("div","ladder-figure",S(a.cents))),o.append(s)}return n.append(o,r),t!==null&&n.append(i("div","ladder-caption",`against the ${S(t)} asking price`)),n}function Ha(e,t){let n=i("div","timeline");n.setAttribute("role","img"),n.setAttribute("aria-label",`Listed ${e.days} day${e.days===1?"":"s"} -- ${e.phase}.`);let r=i("div","timeline-head");r.append(i("span","timeline-value",`${e.days} day${e.days===1?"":"s"} listed`),i("span","timeline-phase",e.phase));let o=i("div","timeline-rail"),a=i("i","timeline-fill");a.dataset.tone=t,o.append(ne(a,e.position));for(let c of e.marks){let u=i("i","timeline-tick");u.style.left=`${c.position*100}%`,u.title=`${c.label} listed`,o.append(u)}let s=i("i","timeline-dot");s.dataset.tone=t,s.style.left=`${e.position*100}%`,o.append(s);let l=i("div","timeline-scale");for(let c of e.marks){let u=i("span","timeline-scale-label",c.label);u.style.left=`${c.position*100}%`,l.append(u)}return n.append(r,o,l),n}function $a(e){let t=i("div","draft"),n=i("div","draft-head");n.append(i("span","draft-label","Message to send"),Ne(e,"Copy message"));let r=i("textarea","draft-body");return r.value=e,r.rows=Math.min(7,e.split(`
`).length+2),r.spellcheck=!1,r.setAttribute("aria-label","Draft opening message, editable before copying"),t.append(n,r),t}function Cr(e){let t=e.negotiation,n=t.offer,r=[],o=$e(t.leverage),a=ur(n.stance),s=lr(t);if(a&&s){let u=i("div","offer-head");u.append(U(a.tone,a.label)),r.push(u)}s?r.push(Na(s,e.pricing.ask_cents)):n.withheld_reason&&r.push(re(n.withheld_reason));for(let u of n.reasoning)r.push(i("p","muted",u));let l=ir(t.days_listed);l?r.push(Ha(l,o)):r.push(i("p","muted","Marketplace did not expose a posted date, so time on market is unknown."));let c=G(t.leverage_points);if(c&&(r.push(i("p","group-label","What gives you room")),r.push(c)),t.motivated_phrases.length||t.rigid_phrases.length){r.push(i("p","group-label","How the seller writes"));let u=i("div","chip-row");for(let d of t.motivated_phrases)u.append(U("favorable",d));for(let d of t.rigid_phrases)u.append(U("caution",d));r.push(u)}return t.opening_message&&r.push($a(t.opening_message)),n.caveat&&r.push(re(n.caveat)),r}function Or(e){return e.alternatives.message}function kt(e,t){let n=i("div","alt"),r=i("div","alt-head");r.append(i("span","alt-vehicle",sr(e.description))),n.append(r);let o=i("div","alt-price-row");o.append(i("span","alt-price",S(e.price_cents)));let a=ar(e.price_cents,t);a&&o.append(U(a.tone,a.text)),n.append(o);let s=[];if(e.mileage!==null&&s.push(`${e.mileage.toLocaleString("en-US")} mi`),e.location_text&&s.push(e.location_text),s.length&&n.append(i("div","alt-meta",s.join(" \xB7 "))),e.mileage_tradeoff){let l=i("div","alt-reason");l.append(U("caution","higher mileage"),i("span",void 0,"for the lower price.")),n.append(l)}return e.url&&n.append(mt(e.url)),n}function Ir(e){let t=[],n=e.pricing.ask_cents;for(let o of e.alternatives.items)t.push(kt(o,n));for(let o of e.alternatives.withheld){let a=kt(o,n);a.dataset.withheld="true";let s=i("div","alt-reason");s.append(U("caution","not recommended"),i("span",void 0,o.reason));let l=a.querySelector("a");l?a.insertBefore(s,l):a.append(s),t.push(a)}let r=e.alternatives.different_trim;if(r.length>0){let o=r.length,a=`${o} different-trim listing${o===1?"":"s"}, better priced.`,s=r.map(l=>kt(l,n));t.push(L("Different trim",a,s))}return t}function Pr(e){return""}function Nr(e){return e.helpful_links.map(t=>{let n=i("div","helpful-link");return n.append(mt(t.url,t.label)),t.note&&n.append(re(t.note)),n})}var Hr=`
  .summary-inline {
    display: inline-flex; align-items: center; gap: var(--sp-3); flex-wrap: wrap;
  }

  /* price gauge ------------------------------------------------------- */
  /* Four rows -- the ask label, the track, the two thresholds, the band's
     legend -- that used to sit almost flush against each other (an 8px and
     two 6px gaps for a section carrying five separate readings). Each gap
     below is now its own step up the scale rather than the smallest one
     repeated four times. */
  .gauge { margin: 0 0 var(--sp-6); }
  .gauge-ask-row { position: relative; height: 40px; }
  .gauge-ask-label {
    position: absolute; bottom: var(--sp-2); transform: translateX(-50%);
    display: flex; flex-direction: column; align-items: center; gap: 2px;
    white-space: nowrap; line-height: 1.15;
  }
  /* Centring a label over a marker near either end pushes half the figure out
     of the panel. At the ends it hangs inward instead. */
  .gauge-ask-label[data-align="start"] { transform: translateX(0); align-items: flex-start; }
  .gauge-ask-label[data-align="end"] { transform: translateX(-100%); align-items: flex-end; }
  .gauge-ask-value {
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-md); font-weight: 700; letter-spacing: -.01em;
  }
  .gauge-ask-caption {
    font-size: var(--fs-2xs); letter-spacing: .07em; text-transform: uppercase;
    color: var(--text-faint);
  }
  .gauge-ask-label[data-tone="favorable"] .gauge-ask-value { color: var(--tone-favorable-text); }
  .gauge-ask-label[data-tone="caution"] .gauge-ask-value   { color: var(--tone-caution-text); }
  .gauge-ask-label[data-tone="adverse"] .gauge-ask-value   { color: var(--tone-adverse-text); }
  .gauge-ask-label[data-tone="neutral"] .gauge-ask-value   { color: var(--text); }

  .gauge-track {
    position: relative; height: 11px; border-radius: var(--radius-pill);
    background: var(--track);
  }
  .gauge-band {
    position: absolute; top: 0; bottom: 0; width: 0;
    border-radius: var(--radius-pill);
    background: var(--tone-neutral-fill);
    transition: width var(--dur-slow) var(--ease-out);
  }
  /* Thresholds as hairlines through the track, recessive against the band and
     the ask marker -- they are reference lines, not data. */
  .gauge-tick {
    position: absolute; top: -3px; bottom: -3px; width: 2px;
    transform: translateX(-1px); border-radius: 1px;
    background: var(--text-faint); opacity: .75;
  }
  /* The ask overlaps the band, so it carries a ring in the panel's own surface
     colour: without it the marker and the fill merge into one shape at exactly
     the moment the reader is trying to see which side of the band it is on. */
  .gauge-ask {
    position: absolute; top: 50%; width: 14px; height: 14px;
    margin: -7px 0 0 -7px; border-radius: 50%;
    background: var(--text);
    box-shadow: 0 0 0 2.5px var(--sheet), var(--elev-1);
  }
  .gauge-ask[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .gauge-ask[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .gauge-ask[data-tone="adverse"]   { background: var(--tone-adverse-fill); }

  .gauge-caption {
    display: flex; justify-content: space-between; gap: var(--sp-4);
    margin-top: var(--sp-4);
    /* With only the walk-away figure present it still belongs on the right,
       where its tick is, rather than sliding left into the strong-offer slot. */
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-xs); color: var(--text-faint);
  }
  .gauge-caption-end { margin-left: auto; }
  .gauge-legend {
    display: flex; align-items: center; gap: var(--sp-2); margin-top: var(--sp-4);
    font-size: var(--fs-xs); color: var(--text-dim);
    font-variant-numeric: tabular-nums;
  }
  .gauge-swatch {
    width: 14px; height: 6px; border-radius: var(--radius-pill); flex: none;
    background: var(--tone-neutral-fill);
  }

  /* complaints -------------------------------------------------------- */
  .complaint-chart { margin-top: var(--sp-3); }
  .complaint-chart .meter-label { text-transform: capitalize; }

  /* negotiation ------------------------------------------------------- */
  .offer-head { display: flex; align-items: center; gap: var(--sp-3); margin-bottom: var(--sp-4); }

  /* The offer ladder. A grid rather than flex so the rail's dots line up under
     the middle of their own cells at any number of steps -- both rows share one
     column definition. */
  .ladder {
    margin: 0 0 var(--sp-5); padding: var(--sp-4) var(--sp-5) var(--sp-5);
    border: 1px solid var(--border); border-radius: var(--radius-md);
    background: var(--raised);
  }
  .ladder-cells, .ladder-rail { display: grid; grid-auto-flow: column; grid-auto-columns: 1fr; }
  .ladder-cell { min-width: 0; }
  /* Every step after the first reads right-of-centre, so the last one hugs the
     edge and the progression runs left to right rather than sitting in a block. */
  .ladder-cell + .ladder-cell { text-align: right; }
  .ladder[data-steps="3"] .ladder-cell:nth-child(2) { text-align: center; }
  .ladder-label {
    font-size: var(--fs-2xs); font-weight: 700; letter-spacing: .07em;
    text-transform: uppercase; color: var(--text-dim);
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  .ladder-figure {
    margin-top: 3px;
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-md); font-weight: 650; letter-spacing: -.01em; color: var(--text-muted);
  }
  /* The lead step is the only figure the buyer says out loud. */
  .ladder-cell[data-lead="true"] .ladder-figure {
    font-size: var(--fs-xl); font-weight: 700; letter-spacing: -.02em; color: var(--text);
  }
  .ladder-cell[data-lead="true"][data-tone="favorable"] .ladder-figure {
    color: var(--tone-favorable-text);
  }
  .ladder-cell[data-lead="true"][data-tone="caution"] .ladder-figure {
    color: var(--tone-caution-text);
  }
  .ladder-cell[data-lead="true"][data-tone="adverse"] .ladder-figure {
    color: var(--tone-adverse-text);
  }

  /* The rail: a hairline through dots that sit under their own cells. */
  .ladder-rail {
    position: relative; margin-top: var(--sp-4); align-items: center; height: 9px;
  }
  .ladder-rail::before {
    content: ""; position: absolute; left: 4px; right: 4px; top: 50%; height: 1px;
    background: var(--border); transform: translateY(-.5px);
  }
  .ladder-dot {
    position: relative; justify-self: start;
    width: 9px; height: 9px; border-radius: 50%;
    background: var(--track); box-shadow: 0 0 0 2px var(--raised);
  }
  .ladder-rail > .ladder-dot:not(:first-child) { justify-self: end; }
  .ladder[data-steps="3"] .ladder-rail > .ladder-dot:nth-child(2) { justify-self: center; }
  .ladder-dot[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .ladder-dot[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .ladder-dot[data-tone="adverse"]   { background: var(--tone-adverse-fill); }
  .ladder-caption {
    margin-top: var(--sp-3); font-size: var(--fs-xs); color: var(--text-faint);
    font-variant-numeric: tabular-nums;
  }

  /* time on market ---------------------------------------------------- */
  .timeline { margin-top: var(--sp-5); }
  .timeline-head {
    display: flex; align-items: baseline; gap: var(--sp-3); flex-wrap: wrap;
    margin-bottom: var(--sp-3);
  }
  .timeline-value {
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-base); font-weight: 650; color: var(--text);
  }
  .timeline-phase { font-size: var(--fs-sm); color: var(--text-dim); }
  .timeline-rail {
    position: relative; height: 6px; border-radius: var(--radius-pill);
    background: var(--track);
  }
  .timeline-fill {
    display: block; height: 100%; width: 0; border-radius: inherit;
    background: var(--tone-neutral-fill);
    transition: width var(--dur-slow) var(--ease-out);
  }
  .timeline-fill[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .timeline-fill[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .timeline-fill[data-tone="adverse"]   { background: var(--tone-adverse-fill); }
  /* The thresholds are reference lines, not data, so they stay recessive and sit
     over the fill rather than interrupting it. */
  .timeline-tick {
    position: absolute; top: -2px; bottom: -2px; width: 1px;
    transform: translateX(-.5px);
    background: var(--text-faint); opacity: .55;
  }
  .timeline-dot {
    position: absolute; top: 50%; width: 11px; height: 11px;
    margin: -5.5px 0 0 -5.5px; border-radius: 50%;
    background: var(--text); box-shadow: 0 0 0 2px var(--sheet), var(--elev-1);
  }
  .timeline-dot[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .timeline-dot[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .timeline-dot[data-tone="adverse"]   { background: var(--tone-adverse-fill); }
  .timeline-scale {
    position: relative; height: 14px; margin-top: var(--sp-2);
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-2xs); color: var(--text-faint);
  }
  .timeline-scale-label { position: absolute; transform: translateX(-50%); }

  /* shared small pieces ----------------------------------------------- */
  .group-label {
    margin: var(--sp-5) 0 0; font-size: var(--fs-2xs); font-weight: 700;
    letter-spacing: .07em; text-transform: uppercase; color: var(--text-dim);
  }
  .chip-row {
    display: flex; flex-wrap: wrap; gap: var(--sp-2); margin-top: var(--sp-3);
  }

  /* the drafted message ----------------------------------------------- */
  .draft {
    margin-top: var(--sp-5); padding: var(--sp-4);
    border: 1px solid var(--border); border-radius: var(--radius-md);
    background: var(--raised);
  }
  .draft-head {
    display: flex; align-items: center; justify-content: space-between; gap: var(--sp-4);
    margin-bottom: var(--sp-3);
  }
  .draft-label {
    font-size: var(--fs-2xs); font-weight: 700; letter-spacing: .07em;
    text-transform: uppercase; color: var(--text-dim);
  }
  /* A textarea, because a message nobody can edit before sending is a message
     nobody sends. Inherits the panel's type so it does not read as a form field
     dropped into a report. */
  .draft-body {
    display: block; width: 100%; box-sizing: border-box; resize: vertical;
    padding: var(--sp-3); border: 1px solid var(--border-faint);
    border-radius: var(--radius-sm); background: var(--sheet); color: var(--text-muted);
    font: 400 var(--fs-sm)/1.55 var(--font-sans);
  }
  .draft-body:focus-visible { outline: 2px solid var(--link); outline-offset: 1px; }

  /* alternatives ------------------------------------------------------ */
  .alt {
    padding: var(--sp-4) 0; border-top: 1px solid var(--border-faint);
    font-size: var(--fs-sm); line-height: 1.5;
  }
  .alt:first-child { border-top: 0; padding-top: var(--sp-1); }
  .alt[data-withheld="true"] { opacity: .82; }
  .alt-head { display: flex; align-items: baseline; gap: var(--sp-3); }
  .alt-vehicle { font-weight: 650; color: var(--text); font-size: var(--fs-base); }
  .alt-price-row {
    display: flex; align-items: center; gap: var(--sp-3); flex-wrap: wrap;
    margin-top: var(--sp-2);
  }
  .alt-price {
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-md); font-weight: 650; color: var(--text);
  }
  .alt-meta {
    margin-top: 3px; color: var(--text-dim); font-variant-numeric: tabular-nums;
  }
  .alt-reason {
    display: flex; gap: var(--sp-3); align-items: baseline; margin-top: var(--sp-2);
    font-size: var(--fs-sm); color: var(--text-dim);
  }
  .alt a { margin-top: var(--sp-2); }

  /* helpful links -------------------------------------------------------- */
  .helpful-link {
    padding: var(--sp-4) 0; border-top: 1px solid var(--border-faint);
    font-size: var(--fs-sm); line-height: 1.5;
  }
  .helpful-link:first-child { border-top: 0; padding-top: var(--sp-1); }
`;function Da(e){return e.replace(/_/g," ")}function Ba(e,t){switch(e){case"price_residual":return Sr(t);case"information_completeness":return Ar(t);case"vehicle_risk":return Mr(t);case"seller_and_scam_risk":return Rr(t);default:return[]}}function za(e,t,n){return`${Math.round(e)}/100 \xD7 ${Math.round(t)}% = ${n.toFixed(1)} pts`}function ja(e,t,n,r,o){let a=dr(t.value),s=i("details",`component${n===null?" missing":""}`);n!==null&&(s.dataset.tone=a);let l=i("summary","component-summary"),c=Ba(t.name,e),u=i("div","component-top"),d=i("span","component-name");if(n!==null&&d.append(i("span","component-glyph",N[a])),d.append(i("span",void 0,Da(t.name))),u.append(d),u.append(i("span","component-figures",n===null?"not assessed":za(t.value??0,r,n))),l.append(u),n!==null){let f=i("div","bar");f.style.width=`${r/o*100}%`;let m=i("i");m.dataset.tone=a,f.append(ne(m,(t.value??0)/100)),l.append(f)}s.append(l);let p=i("div","component-body");return n===null&&t.unavailable_reason&&p.append(i("p","component-reason",t.unavailable_reason)),p.append(...c),s.append(p),s}function $r(e){let t=cr(e.deal_score.components),n=[],r=Math.max(...t.map(s=>s.maxPoints),1);for(let{component:s,points:l,maxPoints:c}of t)n.push(ja(e,s,l,c,r));t.filter(s=>s.points===null).length&&n.push(i("p","muted","Dimensions that could not be assessed are dropped rather than scored as zero, and the remaining weights are shared out over what is left."));let a=G(e.pricing.fallback_reasons,"muted-list");return a&&n.push(a),n}var Dr=`
  .component {
    position: relative; border-bottom: 1px solid var(--border-faint);
    font-size: var(--fs-sm);
  }
  .component:last-child { border-bottom: 0; }
  /* A tone rail on the left edge, drawn only while the row is open. Closed,
     the bar is already the colour carrier; open, the row's content runs for
     half a screen and the rail is what still connects it to its dimension. */
  .component::before {
    content: ""; position: absolute; left: calc(var(--sp-4) * -1); top: 0; bottom: 0;
    width: 2px; border-radius: var(--radius-pill); background: transparent;
    transition: background var(--dur-base) var(--ease-out);
  }
  .component[open][data-tone="favorable"]::before { background: var(--tone-favorable-fill); }
  .component[open][data-tone="caution"]::before   { background: var(--tone-caution-fill); }
  .component[open][data-tone="adverse"]::before   { background: var(--tone-adverse-fill); }
  .component[open][data-tone="neutral"]::before   { background: var(--border); }

  .component-summary {
    display: block; cursor: pointer; list-style: none; position: relative;
    padding: var(--sp-3) var(--sp-5) var(--sp-3) 0;
    border-radius: var(--radius-sm);
    transition: background var(--dur-fast) var(--ease-out);
  }
  .component-summary::-webkit-details-marker { display: none; }
  .component-summary::after {
    content: ""; position: absolute; right: 2px; top: 14px;
    width: 6px; height: 6px;
    border-right: 1.5px solid var(--text-faint);
    border-bottom: 1.5px solid var(--text-faint);
    transform: rotate(45deg);
    transition: transform var(--dur-base) var(--ease-out), border-color var(--dur-fast);
  }
  .component[open] > .component-summary::after { transform: translateY(3px) rotate(-135deg); }
  .component-summary:hover .component-name { color: var(--text); }
  .component-summary:hover::after { border-color: var(--text-dim); }

  .component-top {
    display: flex; justify-content: space-between; gap: var(--sp-4);
    color: var(--text-muted); align-items: baseline;
  }
  .component-name {
    display: inline-flex; align-items: baseline; gap: var(--sp-2);
    text-transform: capitalize; font-weight: 600;
    transition: color var(--dur-fast) var(--ease-out);
  }
  .component-glyph { font-size: var(--fs-xs); }
  .component[data-tone="favorable"] .component-glyph { color: var(--tone-favorable-text); }
  .component[data-tone="caution"] .component-glyph   { color: var(--tone-caution-text); }
  .component[data-tone="adverse"] .component-glyph   { color: var(--tone-adverse-text); }
  .component[data-tone="neutral"] .component-glyph   { color: var(--text-faint); }

  .component-figures {
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    color: var(--text-dim); flex: none; font-size: var(--fs-xs);
  }
  .component.missing .component-top { color: var(--text-faint); font-style: italic; }
  .component-reason {
    margin: 3px 0 0; font-size: var(--fs-xs); line-height: 1.45; color: var(--text-faint);
  }

  .bar {
    height: 7px; border-radius: var(--radius-pill); background: var(--track);
    margin-top: var(--sp-2); overflow: hidden; min-width: 8%;
  }
  .bar > i {
    display: block; height: 100%; width: 0; border-radius: inherit;
    background: var(--tone-neutral-fill);
    transition: width var(--dur-slow) var(--ease-out);
  }
  .bar > i[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .bar > i[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .bar > i[data-tone="adverse"]   { background: var(--tone-adverse-fill); }
  /* Staggered so the four dimensions read as one chart arriving rather than
     four independent bars. Nth-of-type, not a class, because the row order is
     fixed by DIMENSION_ORDER in state.ts and cannot drift. */
  .component:nth-of-type(2) .bar > i { transition-delay: 60ms; }
  .component:nth-of-type(3) .bar > i { transition-delay: 120ms; }
  .component:nth-of-type(4) .bar > i { transition-delay: 180ms; }

  .component-body { padding: 0 0 var(--sp-4); }

  /* Vehicle risk / seller and scam risk's own nested dropdowns (Recalls,
     Complaints, Vehicle specification, Red flags). Indented from "Vehicle
     risk" / "Seller and scam risk" itself, with their own content indented a
     second step further from THEIR header -- two levels, not one. Overrides
     the shared .disclosure spacing, which is sized for a full-width top-level
     row rather than a nested one. */
  .component-body > .disclosure { border-bottom: 1px solid var(--border-faint); }
  .component-body > .disclosure:last-child { border-bottom: 0; }
  .component-body > .disclosure:first-of-type { margin-top: var(--sp-1); }
  .component-body > .disclosure > summary {
    padding: var(--sp-3) 0 var(--sp-3) var(--sp-4); border-radius: var(--radius-sm);
  }
  .component-body > .disclosure > .disclosure-body {
    padding: var(--sp-1) 0 var(--sp-4) var(--sp-7);
  }

  .breakdown-note {
    margin: 0 0 var(--sp-4); font-size: var(--fs-sm); line-height: 1.5; color: var(--text-muted);
  }
  .muted-list { color: var(--text-faint); font-size: var(--fs-xs); margin-top: var(--sp-4); }

  /* expand-all, pinned to the Score breakdown heading */
  .toggle-all {
    margin-left: auto; flex: none;
    font: 650 var(--fs-xs)/1 var(--font-sans); letter-spacing: .04em; text-transform: uppercase;
    background: none; border: 1px solid var(--border); border-radius: var(--radius-pill);
    color: var(--text-dim); padding: var(--sp-1) var(--sp-3); cursor: pointer;
    transition: color var(--dur-fast) var(--ease-out),
                border-color var(--dur-fast) var(--ease-out);
  }
  .toggle-all:hover { color: var(--text); border-color: var(--text-faint); }
`;function wt(){let e=i("span","beta","BETA");return e.title="Uncalibrated: the weights have not been checked against hand-evaluated listings.",e}function Ua(e){return null}function Fa(e){return e==="disqualifying"||e==="branded"?"adverse":e==="unstated"?"caution":"favorable"}function Br(e){let t=e.vehicle_risk,n=e.vehicle_details.title_status?`Title: ${e.vehicle_details.title_status}`:"Title status not stated",r=i("div","title-status");return r.append(U(Fa(t.title_risk),n)),r.append(i("p","title-status-message",t.title_message)),r}function Va(e,t){if(Gn()||typeof requestAnimationFrame!="function")return;let n=620,r=null,o=a=>{r===null&&(r=a);let s=Math.min(1,(a-r)/n),l=1-Math.pow(1-s,3);e.textContent=`${Math.round(t*l)}`,s<1&&requestAnimationFrame(o)};requestAnimationFrame(()=>{e.textContent="0",requestAnimationFrame(o)})}function qa(e,t){let n=bt(e),r=Math.round(e),o=i("div","score-wrap"),a=i("div","score-ring");a.dataset.grade=n,a.style.setProperty("--dr-dial",`${Math.max(0,Math.min(100,r))}%`);let s=i("div","score",`${r}`);s.dataset.grade=n,Va(s,r),o.append(a,s);let l=i("div","score-side");l.append(i("span","score-of","out of 100")),t&&l.append(wt());let c=i("div","score-row");return c.append(o,l),c}function Ga(e){let{score:t,suppressed_reason:n,beta:r}=e.deal_score,o;t===null?(o=i("div","score-row"),o.append(i("div","score-withheld","Score withheld")),r&&o.append(wt())):o=qa(t,r);let a=n??rr(e.pricing)??e.headline;return[o,i("p","headline",a),Br(e)]}function Ka(e){let t=[],{score:n,suppressed_reason:r,beta:o}=e.deal_score;t.push(i("p","verdict","This vehicle cannot be priced confidently.")),t.push(Br(e));let a=nr(e.pricing,2);if(a.length){let s=i("ul","problems");for(let l of a){let c=i("li");c.append(i("span","problem-glyph",N.caution),i("span",void 0,l)),s.append(c)}t.push(s)}if(o){let s=i("div","meta-row");s.append(wt()),t.push(s)}if(r!==null)t.push(i("p","headline",r));else if(n!==null){let s=i("details","score-reveal"),l=i("summary",void 0,"Show the score anyway"),c=i("p","score-secondary");c.append(i("strong",void 0,`${Math.round(n)} / 100`),i("span",void 0," \u2014 a summary of dimensions that rest on the comp set above. It is no more reliable than the comps are.")),s.append(l,c),t.push(s)}return t}function zr(e,t,n,r){let o=er(e),a=i("header");a.dataset.state=o,o==="confident"&&e.deal_score.score!==null&&(a.dataset.grade=bt(e.deal_score.score));let s=i("button","close");s.type="button",s.setAttribute("aria-label","Close evaluation"),s.append(i("span","close-glyph","\xD7")),s.addEventListener("click",t);let l=i("div","header-actions"),c=Ua(e);c&&l.append(c),r&&l.append(r),n&&l.append(n),l.append(s);let u=i("div","header-top");return u.append(i("div","vehicle",e.vehicle),l),a.append(u),a.append(...o==="confident"?Ga(e):Ka(e)),a}var jr=`
  /* The dial's sweep is a registered property so it can be transitioned --
     a plain custom property in a conic-gradient jumps. Namespaced because
     @property registers document-wide, and this stylesheet is injected into
     somebody else's page. */
  @property --dr-dial {
    syntax: "<percentage>";
    inherits: false;
    initial-value: 0%;
  }

  header {
    position: sticky; top: 0; z-index: 1;
    background: var(--sheet);
    padding: var(--sp-6) var(--sp-6) var(--sp-5);
    border-bottom: 1px solid var(--border);
  }
  /* A few percent of the grade colour, mixed into the sheet rather than laid
     over it, so the header is still the sheet in both themes. */
  header[data-grade="poor"]      { background: color-mix(in srgb, var(--grade-poor-text) 7%, var(--sheet)); }
  header[data-grade="weak"]      { background: color-mix(in srgb, var(--grade-weak-text) 7%, var(--sheet)); }
  header[data-grade="fair"]      { background: color-mix(in srgb, var(--grade-fair-text) 7%, var(--sheet)); }
  header[data-grade="good"]      { background: color-mix(in srgb, var(--grade-good-text) 7%, var(--sheet)); }
  header[data-grade="excellent"] { background: color-mix(in srgb, var(--grade-excellent-text) 9%, var(--sheet)); }
  header[data-state="unreliable"] {
    border-bottom-color: var(--tone-caution-border);
    box-shadow: inset 3px 0 0 var(--tone-caution-fill);
    background: color-mix(in srgb, var(--tone-caution-fill) 6%, var(--sheet));
  }

  /* The row the vehicle line and the controls share. Flex rather than the
     vehicle text reserving a fixed width for whatever the actions happen to
     add up to (a seller-type badge, a theme toggle, close): the actions take
     only the width they need and the vehicle text shrinks and wraps around
     them instead of running underneath. */
  .header-top {
    display: flex; align-items: flex-start; justify-content: space-between;
    gap: var(--sp-4);
  }
  .header-actions {
    display: flex; align-items: center; gap: var(--sp-2); flex: none;
    /* Nudged up to sit level with the vehicle text's cap-height rather than
       its line box. */
    margin-top: -2px;
  }
  .close, .theme-toggle {
    display: grid; place-items: center; flex: none;
    width: 28px; height: 28px; padding: 0;
    background: none; border: 1px solid transparent; border-radius: var(--radius-pill);
    color: var(--text-dim); cursor: pointer; font: inherit; line-height: 1;
    transition: color var(--dur-fast) var(--ease-out),
                background var(--dur-fast) var(--ease-out),
                border-color var(--dur-fast) var(--ease-out);
  }
  .close:hover, .theme-toggle:hover {
    color: var(--text); background: var(--raised); border-color: var(--border);
  }
  .close-glyph { font-size: var(--fs-lg); }
  .theme-toggle { font-size: var(--fs-base); }

  .seller-type-badge {
    font-size: var(--fs-2xs); font-weight: 700; letter-spacing: .04em;
    padding: 3px var(--sp-3); border-radius: var(--radius-pill);
    border: 1px solid currentColor; cursor: default; white-space: nowrap;
    flex: none;
  }
  .seller-type-badge[data-type="private_party"] { color: var(--tone-favorable-text); }
  .seller-type-badge[data-type="dealer"] { color: var(--tone-caution-text); }

  .vehicle {
    font-size: var(--fs-sm); color: var(--text-dim);
    letter-spacing: .05em; text-transform: uppercase; font-weight: 600;
    min-width: 0; flex: 1 1 auto;
    /* Long year/make/model/trim combinations wrap onto a second line rather
       than truncating -- this is the one place in the panel that states what
       the car actually is, so losing the end of it silently is worse than a
       taller header. */
    overflow-wrap: break-word;
    padding-top: 2px;
  }

  /* confident --------------------------------------------------------- */
  .score-row {
    display: flex; align-items: center; flex-wrap: wrap;
    gap: var(--sp-4); margin-top: var(--sp-4);
  }
  .score-wrap { position: relative; display: grid; place-items: center; flex: none; }
  .score-ring {
    grid-area: 1 / 1; width: 88px; height: 88px; border-radius: 50%;
    background: conic-gradient(from -90deg, var(--dial) var(--dr-dial), var(--track) 0);
    /* Masked to a ring rather than filled and covered, so the header's grade
       tint shows through the middle instead of a disc of flat --sheet. */
    -webkit-mask: radial-gradient(farthest-side, #0000 calc(100% - 5px), #000 calc(100% - 4px));
            mask: radial-gradient(farthest-side, #0000 calc(100% - 5px), #000 calc(100% - 4px));
    transition: --dr-dial var(--dur-slow) var(--ease-out);
  }
  .score-ring[data-grade="poor"]      { --dial: var(--grade-poor-text); }
  .score-ring[data-grade="weak"]      { --dial: var(--grade-weak-text); }
  .score-ring[data-grade="fair"]      { --dial: var(--grade-fair-text); }
  .score-ring[data-grade="good"]      { --dial: var(--grade-good-text); }
  .score-ring[data-grade="excellent"] { --dial: var(--grade-excellent-text); }

  .score {
    grid-area: 1 / 1;
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-d3); font-weight: 700; line-height: 1; letter-spacing: -.03em;
    color: var(--text);
  }
  /* Grade is a five-way read of the same 0-100 the rest of the panel keeps to
     three tones (Tone) -- justified here because this is the one number
     shown once, in isolation, at the size that draws the eye first. */
  .score[data-grade="poor"]      { color: var(--grade-poor-text);      font-size: var(--grade-poor-size); }
  .score[data-grade="weak"]      { color: var(--grade-weak-text);      font-size: var(--grade-weak-size); }
  .score[data-grade="fair"]      { color: var(--grade-fair-text);      font-size: var(--grade-fair-size); }
  .score[data-grade="good"]      { color: var(--grade-good-text);      font-size: var(--grade-good-size); }
  .score[data-grade="excellent"] { color: var(--grade-excellent-text); font-size: var(--grade-excellent-size); }

  .score-side { display: flex; flex-direction: column; align-items: flex-start; gap: var(--sp-2); }
  .score-of {
    font-size: var(--fs-xs); letter-spacing: .06em; text-transform: uppercase;
    color: var(--text-faint);
  }
  .score-withheld {
    font-size: var(--fs-md); font-weight: 650; color: var(--tone-caution-text);
  }
  .headline {
    margin: var(--sp-4) 0 0; font-size: var(--fs-base); line-height: 1.55; color: var(--text-muted);
  }

  /* title status, shared by both header states ------------------------ */
  .title-status { margin-top: var(--sp-4); }
  .title-status-message {
    margin: var(--sp-2) 0 0; font-size: var(--fs-sm); line-height: 1.45; color: var(--text-muted);
  }

  /* unreliable -------------------------------------------------------- */
  .verdict {
    margin: var(--sp-4) 0 0;
    font-size: var(--fs-lg); font-weight: 650; line-height: 1.25; letter-spacing: -.015em;
    color: var(--text); text-wrap: balance;
  }
  .problems { list-style: none; margin: var(--sp-4) 0 0; padding: 0; }
  .problems li {
    display: flex; gap: var(--sp-3); align-items: baseline;
    font-size: var(--fs-base); line-height: 1.45; color: var(--text-muted);
    margin-bottom: var(--sp-1);
  }
  .problem-glyph { color: var(--tone-caution-text); flex: none; }
  .meta-row {
    display: flex; align-items: center; flex-wrap: wrap; gap: var(--sp-3); margin-top: var(--sp-4);
  }

  .score-reveal { margin-top: var(--sp-4); }
  .score-reveal summary {
    font-size: var(--fs-sm); color: var(--text-dim); cursor: pointer;
    padding: 3px 0; border-radius: var(--radius-sm); width: fit-content;
    transition: color var(--dur-fast) var(--ease-out);
  }
  .score-reveal summary:hover { color: var(--text); }
  .score-secondary {
    margin: var(--sp-2) 0 0; font-size: var(--fs-sm); line-height: 1.5; color: var(--text-muted);
  }
  .score-secondary strong { color: var(--text); font-size: var(--fs-md); }

  /* chips and badges -------------------------------------------------- */
  .chip {
    display: inline-flex; align-items: center; gap: var(--sp-1);
    font-size: var(--fs-xs); font-weight: 650;
    padding: 3px var(--sp-3); border-radius: var(--radius-pill);
    border: 1px solid currentColor;
  }
  .chip-glyph { font-size: var(--fs-xs); }
  .chip[data-tone="favorable"] { color: var(--tone-favorable-text); }
  .chip[data-tone="caution"]   { color: var(--tone-caution-text); }
  .chip[data-tone="adverse"]   { color: var(--tone-adverse-text); }
  .chip[data-tone="neutral"]   { color: var(--text-dim); }
  .beta {
    font-size: var(--fs-2xs); font-weight: 700; letter-spacing: .08em;
    background: var(--beta); color: var(--beta-on);
    padding: 3px var(--sp-2); border-radius: var(--radius-sm);
  }
`;var Ya=`
  :host { all: initial; }

  .backdrop {
    position: fixed; inset: 0; z-index: 2147483646;
    background: var(--scrim);
    display: flex; justify-content: flex-end;
    font-family: var(--font-sans);
    -webkit-font-smoothing: antialiased;
    opacity: 0;
    transition: opacity var(--dur-base) var(--ease-out);
  }
  .sheet {
    width: min(444px, 100vw);
    height: 100%;
    overflow-y: auto;
    overscroll-behavior: contain;
    background: var(--sheet);
    color: var(--text);
    box-shadow: var(--elev-3);
    transform: translateX(20px);
    transition: transform var(--dur-slow) var(--ease-out);
  }

  /* Entry and exit are the same two properties in opposite directions. The
     class is added a frame after mount and removed on close (see index.ts),
     which is what lets the panel animate OUT as well -- an overlay that snaps
     out of existence reads as a crash rather than a dismissal. */
  .backdrop[data-open="true"] { opacity: 1; }
  .backdrop[data-open="true"] .sheet { transform: translateX(0); }

  .sheet::-webkit-scrollbar { width: 10px; }
  .sheet::-webkit-scrollbar-track { background: transparent; }
  .sheet::-webkit-scrollbar-thumb {
    background: var(--border); border-radius: var(--radius-pill);
    border: 3px solid var(--sheet);
  }
  .sheet::-webkit-scrollbar-thumb:hover { background: var(--text-faint); }

  /* One visible focus ring for every interactive element in the panel. The
     panel is an overlay on somebody else's page; a keyboard user who cannot
     see where they are has no way back out to the close button. */
  :where(button, summary, a, [tabindex]):focus-visible {
    outline: 2px solid var(--focus);
    outline-offset: 2px;
    border-radius: var(--radius-sm);
  }

  /* Nothing in this panel animates for effect, but the entry transition,
     the growing bars and the disclosure rows are all motion. Honour the system
     preference rather than assuming a 200ms fade is beneath notice. The JS
     animations check the same query and jump to their final value. */
  @media (prefers-reduced-motion: reduce) {
    * {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
      scroll-behavior: auto !important;
    }
  }
`,Ja=`
  .notices {
    padding: var(--sp-5) var(--sp-6) var(--sp-7);
    background: var(--raised);
    border-top: 1px solid var(--border-faint);
  }
  .notices p {
    margin: 0 0 var(--sp-3); font-size: var(--fs-xs); line-height: 1.55;
    color: var(--text-faint);
  }
  .notices p:last-child { margin-bottom: 0; }
  .notices strong { color: var(--text-dim); font-weight: 700; }
`;function Ur(e=":host"){return`
${Pe(e)}
${Ya}
${Xn}
${jr}
${yr}
${Dr}
${Hr}
${gr}
${Ja}
`}var ze=["auto","light","dark"];function Fr(e){return typeof e=="string"&&ze.includes(e)}function Vr(e,t){return e==="auto"?t?"dark":"light":e}function qr(e){return e==="auto"?null:e}function Et(e){let t=ze.indexOf(e);return ze[(t+1)%ze.length]}function Gr(e,t){let n=e==="auto"?"\u25D0":t==="dark"?"\u263E":"\u2600",r=e==="auto"?`following your system (${t})`:`${e} theme`;return{glyph:n,label:`Theme: ${r}. Switch to ${Et(e)}.`}}function Kr(){return typeof matchMedia=="function"&&matchMedia("(prefers-color-scheme: dark)").matches}var Yr="deal-rater-overlay",Wa="deal-rater-trigger",Xa='button, a[href], summary, input, select, textarea, [tabindex]:not([tabindex="-1"])';function Qa(e){let t=i("div","notices"),n=i("p");n.append(i("strong",void 0,"Beta signal, not a rating. "),i("span",void 0,"The weights and the discount curve are starting hypotheses that have not been checked against hand-evaluated listings yet. This is an informational analysis of one listing, not a purchase recommendation, and never a substitute for a pre-purchase inspection or a vehicle history report.")),t.append(n);let r=/beta signal|informational analysis/i;for(let o of e.notices)r.test(o)||t.append(i("p",void 0,o));return t}function Za(e){let t=i("button","theme-toggle");t.type="button";let n="auto",r=()=>{let o=Vr(n,Kr()),a=qr(n);a?e.dataset.theme=a:delete e.dataset.theme;let{glyph:s,label:l}=Gr(n,o);t.textContent=s,t.title=l,t.setAttribute("aria-label",l)};return r(),te().then(o=>{Fr(o.theme)&&(n=o.theme,r())}).catch(()=>{}),t.addEventListener("click",()=>{n=Et(n),r(),Sn({theme:n}).catch(()=>{})}),t}function es(e){let t=i("button","toggle-all","Expand all");t.type="button";let n=()=>Array.from(e.querySelectorAll("details")),r=()=>{t.textContent=n().some(o=>o.open)?"Collapse all":"Expand all"};return t.addEventListener("click",()=>{let o=!n().some(a=>a.open);for(let a of n())a.open=o;r()}),e.addEventListener("toggle",r,!0),t}function Jr(e){document.getElementById(Yr)?.remove();let t=i("div");t.id=Yr;let n=t.attachShadow({mode:"open"}),r=document.createElement("style");r.textContent=Ur();let o=i("div","backdrop"),a=i("div","sheet");a.setAttribute("role","dialog"),a.setAttribute("aria-modal","true"),a.setAttribute("aria-label",`Deal evaluation for ${e.vehicle}`);let s=!1,l=()=>{if(s)return;s=!0,window.removeEventListener("keydown",c,!0),o.dataset.open="false";let p=()=>{t.remove(),document.getElementById(Wa)?.shadowRoot?.querySelector("button")?.focus()},f=setTimeout(p,400);o.addEventListener("transitionend",m=>{m.target!==o||m.propertyName!=="opacity"||(clearTimeout(f),p())})};function c(p){if(p.key==="Escape"){p.preventDefault(),p.stopPropagation(),l();return}if(p.key!=="Tab")return;let f=Array.from(a.querySelectorAll(Xa)).filter(h=>!h.disabled&&h.offsetParent!==null);if(f.length===0)return;let m=f[0],v=f[f.length-1],b=n.activeElement;p.shiftKey&&(b===m||b===null)?(p.preventDefault(),v.focus()):!p.shiftKey&&b===v&&(p.preventDefault(),m.focus())}o.addEventListener("click",p=>{p.target===o&&l()}),window.addEventListener("keydown",c,!0);let u=xr(e.capture_id);a.append(zr(e,l,Za(t),u.button)),a.append(u.strip,u.panel),a.append(Jn("Score breakdown",$r(e),void 0,es(a)));let d=fr(e);d&&a.append(d),a.append(L("Negotiation",Lr(e),Cr(e))),a.append(L("Alternatives",Or(e),Ir(e))),a.append(L("Helpful Links",Pr(e),Nr(e))),a.append(Qa(e)),o.append(a),n.append(r,o),document.body.append(t),typeof requestAnimationFrame=="function"?requestAnimationFrame(()=>{o.dataset.open="true"}):o.dataset.open="true",Kn(a),n.querySelector("button.close")?.focus()}var ts="chrome-extension",ns="0.1.0";function rs(e){return{client:{name:ts,version:ns},capture:{client_capture_id:e.captureId,captured_at:e.capturedAt.toISOString(),comp_search_query:e.compSearchQuery},target:e.target,comps:e.comps,extraction_report:ce(e.issues)}}async function Wr(e=()=>{}){let t=new Date;e("Reading listing\u2026","reading");let n=await de(document,location.href,t);if(n.usable&&!n.payloadMatched){e("Loading listing data\u2026","reading");let P=n.observation.listing_url??location.href,se=await ct(P);if(se){let T=await de(se,P,t);T.payloadMatched&&(n=T)}if(!n.payloadMatched){e("Reloading listing\u2026","reading");let T=await j({type:"HARVEST_TARGET_VIA_TAB",url:P});T?.ok&&T.payloadMatched&&(n={observation:T.observation,issues:T.issues,pageSignature:T.pageSignature,usable:T.usable,locationId:T.locationId,searchRadiusKm:T.searchRadiusKm,payloadMatched:T.payloadMatched})}}if(!n.usable)return{ok:!1,message:"Could not identify this listing.",compCount:0,extractionOk:!1};let{make:r,model:o,year:a,price_cents:s}=n.observation;if(r===null&&o===null&&s===null)return{ok:!1,message:"This listing is still loading.",compCount:0,extractionOk:!1};if(r===null&&o===null&&a===null)return{ok:!1,message:"This does not look like a vehicle listing. Nothing was saved.",compCount:0,extractionOk:!1};let l=[...n.issues],c=await te(),u=[],d=[],p=null,f=null,m=0,v=0,b=null,h=null,y=null,H=null,K=0,F=0,A=Me(n.observation,n.locationId),x=[],w="none",E=A?.query.location_id!==null;if(A===null)l.push({scope:"comp_search",field_name:"comp_search_query",status:"missing",expectation:"expected",strategies_attempted:[],page_signature:n.pageSignature});else{e("Searching comparable listings\u2026","comps");let P=await me(A.url,t);P.observations.length===0&&A.fallbackUrl&&(P=await me(A.fallbackUrl,t),E=!1),w=P.source,l.push(...P.issues);let se=new Set([n.observation.source_listing_id]),T=[],Fe=R=>{for(let $ of R)se.has($.source_listing_id)||(se.add($.source_listing_id),T.push($))};Fe(P.observations),m=P.observations.length,v=Ce(n.observation,T),K=Oe(n.observation,T);let ao=T.map(R=>R.location_text);if(!E)H="unscoped_home_search";else if(K>=it)H="trim_target_already_met";else if(!jn(m,v))H="market_exhausted";else{let R=On(n.observation,n.locationId);if(R===null)H="no_trim_level";else{e("Searching this trim\u2026","comps");let $=await me(R.url,t);b=R.query.query,h=$.observations.length;let ge=T.length;Fe($.observations),y=T.length-ge,l.push(...$.issues)}}F=Oe(n.observation,T);let X=Dn(n.observation.latitude,n.observation.longitude);X?f="coordinates":(X=zn(n.observation.location_text,ao),X&&(f="location_text")),p=X?.slug??null;let so=await ut(),Mt=c.extraMetroIds,Rt=X?Fn(Hn(X),so):[],Lt=Mt.length>0?Mt:Rt.map(R=>R.slug),io=Lt.length;for(let R of Lt){if(!Vn(n.observation,T,io--))break;if(R===n.locationId)continue;let $=Cn(n.observation,R);if(!$)continue;e("Searching nearby markets\u2026","widening");let ge=await me($.url,t),Ct=Rt.find(Ve=>Ve.slug===R);if(Ct){let Ve=ge.observations.map(lo=>lo.location_text??"");if(!$n(Ct,Ve)){await qn(R),d.push(R);continue}}Fe(ge.observations),u.push(R)}x=T,P.source==="none"&&l.push({scope:"comp_search",field_name:"comp_results",status:"missing",expectation:"expected",strategies_attempted:["json_payload","aria_dom"],page_signature:n.pageSignature})}let M=rs({capturedAt:t,captureId:crypto.randomUUID(),target:n.observation,comps:x,issues:l,compSearchQuery:A?{...A.query,source:w,location_scoped:E,search_radius_km:n.searchRadiusKm,home_metro:p,home_metro_source:f,home_returned:m,home_usable:v,trim_query:b,trim_query_skipped:H,trim_query_returned:h,trim_query_new:y,trim_matched_before:K,trim_matched_after:F,extra_metros_searched:u,extra_metros_unresolved:d,usable_comp_estimate:Ce(n.observation,x)}:null});e("Saving\u2026","saving");let fe=await j({type:"SUBMIT_CAPTURE",payload:M});if(!fe?.ok)return{ok:!1,message:fe?.error??"No response from the extension background worker.",compCount:x.length,extractionOk:!1};let{response:ae}=fe;e("Evaluating\u2026","evaluating");let je=await j({type:"FETCH_EVALUATION",captureId:ae.capture_id}),Ue=ae.duplicate?"Already captured.":`Captured with ${x.length} comparable listing${x.length===1?"":"s"}.`;return je?.ok?(Jr(je.evaluation),{ok:!0,message:ae.extraction_ok?Ue:`${Ue} Some fields could not be read.`,compCount:x.length,extractionOk:ae.extraction_ok}):{ok:!1,message:`${Ue} Could not load the evaluation (${je?.error??"no response from the extension background worker"}).`,compCount:x.length,extractionOk:ae.extraction_ok}}var Xr=/^send$/i;function os(e){if(e.offsetParent===null)return!1;let t=e.getBoundingClientRect();return t.width>0&&t.height>0}function Tt(e=document){let t=he(e),n=Array.from(t.querySelectorAll('[role="button"], button, [aria-label]')).filter(os);for(let r of n){let o=r.getAttribute("aria-label");if(o&&Xr.test(k(o)))return r}for(let r of n)if(!r.querySelector('[role="button"], button')&&Xr.test(k(r.textContent??"")))return r;return null}var St=[{key:"reading",label:"Listing"},{key:"comps",label:"Comps"},{key:"widening",label:"Nearby"},{key:"saving",label:"Saving"},{key:"evaluating",label:"Scoring"}];function Qr(e){return St.findIndex(t=>t.key===e)}var Zr="deal-rater-trigger",eo="Evaluate Listing",as="Evaluating\u2026",ss="Reload the page and try again.";function is(e){if(/reload/i.test(e))return e;let t=e.trim(),n=t.length>0&&!/[.!?]$/.test(t);return`${t}${n?".":""} ${ss}`.trim()}var ls=`

  .dock {
    position: fixed;
    /* Defaults for when no Send button was found. mountTriggerButton and
       updateAnchor override right/bottom with inline styles once one is --
       inline styles win over these regardless of specificity, so the
       fallback and the anchored position never fight each other. */
    right: 16px;
    bottom: 16px;
    /* One BELOW the evaluation overlay's backdrop (2147483646), which is the
       whole point. At 2147483647 this panel floated over the open evaluation,
       covering the VIN decode row and the disclaimers at the bottom of the
       sheet -- the two things a reader is most likely to want and least likely
       to think to scroll for. The overlay is modal while it is open; the
       trigger belongs underneath it. */
    z-index: 2147483645;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: var(--sp-3);
    font-family: var(--font-sans);
    -webkit-font-smoothing: antialiased;
    transition: right var(--dur-base) var(--ease-out), bottom var(--dur-base) var(--ease-out);
  }

  button.capture {
    font: 650 14px/1 var(--font-sans);
    padding: var(--sp-4) var(--sp-6);
    border: 0;
    border-radius: var(--radius-pill);
    background: var(--accent);
    color: var(--accent-on);
    cursor: pointer;
    box-shadow: var(--elev-2);
    transition: transform var(--dur-fast) var(--ease-out),
                filter var(--dur-fast) var(--ease-out);
  }
  button.capture:hover:not(:disabled) { filter: brightness(1.12); }
  button.capture:active:not(:disabled) { transform: scale(.97); }
  button.capture:disabled { opacity: .7; cursor: default; }
  :where(button, [tabindex]):focus-visible { outline: 2px solid var(--focus); outline-offset: 3px; }

  /* The fixture control is secondary to the one action this button exists for,
     and is only ever mounted in a dev build. */
  button.extra {
    font: 600 12px/1 var(--font-sans);
    padding: var(--sp-3) var(--sp-4);
    border: 1px solid var(--border); border-radius: var(--radius-pill);
    background: var(--raised); color: var(--text-dim); cursor: pointer;
  }
  button.extra:hover:not(:disabled) { color: var(--text); border-color: var(--text-faint); }

  /* card ------------------------------------------------------------- */
  .card {
    width: 268px;
    padding: var(--sp-4);
    border-radius: var(--radius-lg);
    border: 1px solid var(--border);
    background: var(--sheet);
    color: var(--text);
    box-shadow: var(--elev-2);
    font-size: 12.5px;
    line-height: 1.45;
  }
  .card[hidden] { display: none; }
  .card[data-tone="error"] {
    border-color: var(--tone-adverse-border);
    background: var(--tone-adverse-surface);
    color: var(--tone-adverse-on-surface);
  }

  .card-message { margin: 0; }
  .card[data-tone="error"] .card-title {
    display: flex; align-items: baseline; gap: var(--sp-2);
    margin: 0 0 var(--sp-2); font-weight: 700; color: var(--tone-adverse-text);
  }

  /* progress rail ---------------------------------------------------- */
  .rail { display: flex; gap: 3px; margin-bottom: var(--sp-3); }
  /* display:flex beats the hidden attribute, so a terminal message kept
     showing a rail of five pending steps under it -- a finished run that looks
     like it never started. */
  .rail[hidden] { display: none; }
  .rail-step { flex: 1; min-width: 0; }
  .rail-bar {
    height: 3px; border-radius: var(--radius-pill); background: var(--track);
    overflow: hidden; position: relative;
  }
  .rail-step[data-state="done"] .rail-bar { background: var(--tone-favorable-fill); }
  /* An indeterminate sweep rather than a percentage: the step's duration is
     genuinely unknown -- the widening pass is however many metros it takes --
     and a fake progress bar that stalls at 80% is worse than an honest one
     that only says "still working". */
  .rail-step[data-state="active"] .rail-bar::after {
    content: ""; position: absolute; inset: 0;
    background: linear-gradient(90deg, transparent, var(--accent), transparent);
    animation: sweep 1.15s var(--ease-out) infinite;
  }
  @keyframes sweep {
    from { transform: translateX(-100%); }
    to   { transform: translateX(100%); }
  }
  .rail-label {
    display: block; margin-top: 5px;
    font-size: 9.5px; letter-spacing: .05em; text-transform: uppercase;
    color: var(--text-faint);
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  .rail-step[data-state="active"] .rail-label { color: var(--text); font-weight: 700; }
  .rail-step[data-state="done"] .rail-label { color: var(--text-dim); }

  .progress-line {
    display: flex; align-items: baseline; justify-content: space-between; gap: var(--sp-3);
  }
  .elapsed {
    flex: none; font-variant-numeric: tabular-nums; color: var(--text-faint); font-size: 11px;
  }

  .retry {
    margin-top: var(--sp-3);
    font: 700 11px/1 var(--font-sans); letter-spacing: .05em; text-transform: uppercase;
    padding: var(--sp-2) var(--sp-4); border-radius: var(--radius-pill);
    border: 1px solid var(--tone-adverse-border); background: transparent;
    color: var(--tone-adverse-text); cursor: pointer;
  }
  .retry:hover { background: var(--tone-adverse-border); color: var(--text); }

  @media (prefers-reduced-motion: reduce) {
    * { transition-duration: 0.01ms !important; }
    /* The sweep is the only thing saying the run is still alive, so it is
       slowed rather than removed -- a static card and a hung card would
       otherwise look identical. */
    .rail-step[data-state="active"] .rail-bar::after { animation-duration: 3s !important; }
  }
`;function us(e){let t=o=>e.startsWith(":host")?`${e}([data-theme="${o}"])`:`${e}[data-theme="${o}"]`,n="--accent: #2f6f9f; --accent-on: #ffffff;",r="--accent: #3d86bd; --accent-on: #06101a;";return`
  ${e} { ${n} }
  @media (prefers-color-scheme: dark) { ${e} { ${r} } }
  ${t("light")} { ${n} }
  ${t("dark")} { ${r} }
`}function cs(e=":host"){return`${e===":host"?":host { all: initial; }":""}
${Pe(e)}
${us(e)}
${ls}`}var ds=16;function to(e,t){if(document.getElementById(Zr))return null;let n=document.createElement("div");n.id=Zr;let r=n.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=cs();let a=document.createElement("div");a.className="dock";let s=document.createElement("div");s.className="card",s.hidden=!0,s.setAttribute("role","status"),s.setAttribute("aria-live","polite");let l=document.createElement("div");l.className="rail";let c=St.map(x=>{let w=document.createElement("div");w.className="rail-step";let E=document.createElement("div");E.className="rail-bar";let M=document.createElement("span");return M.className="rail-label",M.textContent=x.label,w.append(E,M),l.append(w),w}),u=document.createElement("div");u.className="progress-line";let d=document.createElement("p");d.className="card-message";let p=document.createElement("span");p.className="elapsed",u.append(d,p),s.append(l,u);let f=document.createElement("button");f.type="button",f.className="capture",f.textContent=eo,f.addEventListener("click",e),a.append(s,f),r.append(o,a),document.body.appendChild(n);let m=t,v=()=>{let x=m?.isConnected?m.getBoundingClientRect():null;if(!x||x.width===0||x.height===0){a.style.removeProperty("right"),a.style.removeProperty("bottom");return}a.style.right=`${Math.max(window.innerWidth-x.right,8)}px`,a.style.bottom=`${Math.max(window.innerHeight-x.top+ds,8)}px`};v(),window.addEventListener("scroll",v,{passive:!0,capture:!0}),window.addEventListener("resize",v,{passive:!0});let b,h,y=0,H=()=>s.querySelector(".retry")?.remove(),K=()=>s.querySelector(".card-title")?.remove(),F=x=>{let w=x?Qr(x):-1;l.hidden=w<0,c.forEach((E,M)=>{E.dataset.state=w<0?"pending":M<w?"done":M===w?"active":"pending"})},A=()=>{h&&clearInterval(h),h=void 0};return{setProgress(x,w){b&&clearTimeout(b),H(),K(),delete s.dataset.tone,d.textContent=x,F(w),s.hidden=!1,h||(y=Date.now(),p.textContent="",h=window.setInterval(()=>{let E=Math.round((Date.now()-y)/1e3);p.textContent=E>=4?`${E}s`:""},1e3))},setStatus(x,w="info"){if(b&&clearTimeout(b),A(),H(),K(),p.textContent="",F(void 0),d.textContent=w==="error"?is(x):x,s.hidden=!1,w==="error"){s.dataset.tone="error";let E=document.createElement("div");E.className="card-title",E.append("\u26A0"," That didn't finish"),s.insertBefore(E,d.parentElement);let M=document.createElement("button");M.type="button",M.className="retry",M.textContent="Try again",M.addEventListener("click",e),s.append(M)}else delete s.dataset.tone,b=window.setTimeout(()=>{s.hidden=!0},8e3)},setBusy(x){f.disabled=x,f.textContent=x?as:eo,x||A()},remove(){b&&clearTimeout(b),A(),window.removeEventListener("scroll",v,!0),window.removeEventListener("resize",v),n.remove()},addExtraAction(x,w){let E=document.createElement("button");E.type="button",E.className="extra",E.textContent=x,E.addEventListener("click",w),a.appendChild(E)},updateAnchor(x){m=x,v()}}}var ps=300,I=null,no=location.href,At=!1;function ro(){return/\/marketplace\/item\/\d+/.test(location.pathname)}function ms(){return/\/marketplace\/(search|category)/.test(location.pathname)}async function fs(){if(!(At||!I)){At=!0,I.setBusy(!0);try{let e=await Wr((t,n)=>I?.setProgress(t,n));I.setStatus(e.message,e.ok?"info":"error")}catch(e){I.setStatus(e instanceof Error?e.message:String(e),"error")}finally{At=!1,I.setBusy(!1)}}}async function oo(){if(!(await te()).enabled||!ro()){I?.remove(),I=null;return}if(I){I.updateAnchor(Tt());return}I=to(()=>void fs(),Tt())}function gs(){let e,t=()=>{location.href!==no&&(no=location.href,oo())},n=()=>{e&&clearTimeout(e),e=window.setTimeout(t,ps)};new MutationObserver(n).observe(document.documentElement,{childList:!0,subtree:!0}),window.addEventListener("popstate",t)}chrome.runtime.onMessage.addListener((e,t,n)=>e?.type==="HARVEST_COMPS"?(Se(document,location.href).then(r=>n({ok:!0,observations:r.observations,issues:r.issues})).catch(r=>n({ok:!1,error:r instanceof Error?r.message:String(r)})),!0):e?.type==="HARVEST_TARGET"?(de(document,location.href).then(r=>n({ok:!0,observation:r.observation,issues:r.issues,pageSignature:r.pageSignature,usable:r.usable,locationId:r.locationId,searchRadiusKm:r.searchRadiusKm,payloadMatched:r.payloadMatched})).catch(r=>n({ok:!1,error:r instanceof Error?r.message:String(r)})),!0):!1);(ms()||ro())&&chrome.runtime.sendMessage({type:"CONTENT_READY",url:location.href}).catch(()=>{});oo();gs();})();
