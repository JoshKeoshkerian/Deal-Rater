"use strict";(()=>{var Vr=new Date().getFullYear()+2;function y(e){return e.replace(/\s+/g," ").trim()}function R(e){if(e==null)return null;let t=y(e);return t===""?null:t}var Gr={$:"USD","\xA3":"GBP","\u20AC":"EUR"};function X(e){if(!e)return null;let t=y(e);if(/^free$/i.test(t))return{cents:0,currency:"USD"};let n=t.match(/([$£€])?\s?(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d{2}))?/);if(!n)return null;let r=Number(n[2].replace(/,/g,""));if(!Number.isFinite(r))return null;let o=n[3]?Number(n[3]):0,a=n[1],s=a&&Gr[a]||"USD";return{cents:r*100+o,currency:s}}function Ct(e){let t=typeof e=="string"?Number(e):e;return typeof t!="number"||!Number.isFinite(t)||t<0?null:Math.round(t*100)}var ze=15e5;function K(e){if(!e)return null;let t=y(e),n=t.match(/\b(\d{1,3}),?([xX]{2,4})\b(?:\s*(km\b|kilometers|kilometres))?/);if(n){let s=Number(n[1]);if(Number.isFinite(s)){let l=Math.round(s*10**n[2].length);if(l>=0&&l<=ze){let c=n[3]?"km":"mi";return{value:l,unit:c}}}}let r=t.match(/(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*(k\b)?\s*(miles|mile|mi\b|km\b|kilometers|kilometres)/i);if(!r)return null;let o=Number(r[1].replace(/,/g,""));if(!Number.isFinite(o)||(r[2]&&(o*=1e3),o=Math.round(o),o<0||o>ze))return null;let a=/km|kilometer|kilometre/i.test(r[3])?"km":"mi";return{value:o,unit:a}}function Ot(e){let t=typeof e=="string"?Number(e.replace(/,/g,"")):e;if(typeof t!="number"||!Number.isFinite(t))return null;let n=Math.round(t);return n<0||n>ze?null:n}var Lt=["alfa romeo","aston martin","land rover","range rover","mercedes benz","mercedes-benz","rolls royce","rolls-royce"],Pt=["acura","audi","bmw","buick","cadillac","chevrolet","chevy","chrysler","dodge","ferrari","fiat","ford","genesis","gmc","honda","hummer","hyundai","infiniti","isuzu","jaguar","jeep","kia","lamborghini","lexus","lincoln","lucid","maserati","mazda","mclaren","mercedes","mercury","mini","mitsubishi","nissan","oldsmobile","peugeot","plymouth","polestar","pontiac","porsche","ram","renault","rivian","saab","saturn","scion","smart","subaru","suzuki","tesla","toyota","volkswagen","volvo","vw","amc","austin","bentley","bugatti","datsun","delorean","eagle","fisker","geo","international","lotus","maybach","mg","morgan","packard","rover","sterling","studebaker","sunbeam","triumph","willys","yugo"],Kr=2,Yr={chevy:"Chevrolet",vw:"Volkswagen",mercedes:"Mercedes-Benz","mercedes benz":"Mercedes-Benz","mercedes-benz":"Mercedes-Benz","rolls royce":"Rolls-Royce","rolls-royce":"Rolls-Royce",bmw:"BMW",gmc:"GMC",ram:"RAM",kia:"Kia"},Mt="\xB7";function Ue(e){return e.split(" ").map(t=>t&&t[0].toUpperCase()+t.slice(1)).join(" ")}function At(e){return Yr[e.toLowerCase()]??Ue(e)}function Rt(e){let t=e.toLowerCase();return t?Lt.some(n=>t===n||t.startsWith(`${n} `))?!0:Pt.includes(t.split(" ")[0]??""):!1}function j(e){let t={year:null,make:null,model:null,trim:null,trimSource:null};if(!e)return t;let n=y(e),r=n.indexOf(Mt),o=r>=0?y(n.slice(r+Mt.length)):null,a=n.match(/\b(1[89]\d{2}|20\d{2})\b/),s=a&&Number(a[1])>=1900&&Number(a[1])<=Vr?Number(a[1]):null,l=b=>y(b.replace(/[·|,]/g," ")),c;if(a){let b=l(n.slice(a.index+a[0].length)),T=l(n.slice(0,a.index));c=Rt(b)||!Rt(T)?b:T}else c=l(n);let u=c.toLowerCase(),d=null,f="";for(let b of Lt)if(u.startsWith(`${b} `)||u===b){d=At(b),f=c.slice(b.length).trim();break}if(d===null){let b=c.split(" ")[0]??"";Pt.includes(b.toLowerCase())&&(d=At(b),f=c.slice(b.length).trim())}if(d===null)return{year:s,make:null,model:null,trim:null,trimSource:null};let g=f.split(" ").filter(Boolean),m=Math.min(Kr,g.length-1);for(let b=m;b>=1;b--)if(Be(g.slice(0,b).join(""))===Be(d)){g.splice(0,b);break}let h=g.length>0?Ue(g[0]):null,S=g.length>1?g.slice(1).join(" "):null;return{year:s,make:d,model:h,trim:S,trimSource:Jr(S,o)}}function Jr(e,t){return e===null?null:t!==null&&t.toLowerCase().endsWith(e.toLowerCase())?"fb_catalog":"title_text"}function Be(e){return e.toLowerCase().replace(/[^a-z0-9]+/g,"")}function Fe(e){return e?Be(e):""}var Wr={minute:6e4,hour:36e5,day:864e5,week:6048e5,month:2592e6,year:31536e6};function Nt(e,t=new Date){if(!e)return null;let n=y(e);if(/just listed|listed (just )?now|a few seconds ago/i.test(n))return{postedAt:new Date(t.getTime()),relativeText:n.slice(0,64)};let r=n.match(/(?:about\s+)?(an?|\d+)\s*(minute|hour|day|week|month|year)s?\s*ago/i);if(!r)return null;let o=r[1].toLowerCase(),a=o==="a"||o==="an"?1:Number(o);if(!Number.isFinite(a))return null;let s=Wr[r[2].toLowerCase()];return s===void 0?null:{postedAt:new Date(t.getTime()-a*s),relativeText:n.slice(0,64)}}function It(e){let t=typeof e=="string"?Number(e):e;if(typeof t!="number"||!Number.isFinite(t)||t<=0)return null;let n=new Date(t*1e3);return Number.isNaN(n.getTime())?null:n}var Xr=[["parts_only",/\b(for parts|parts only|parts car|not running|non[- ]?running)\b/i],["no_title",/\b(no title|lost title|bill of sale only|bos only)\b/i],["salvage",/\bsalvage\b/i],["rebuilt",/\b(rebuilt|reconstructed|prior salvage)\b/i],["branded",/\b(branded title|flood|lemon|hail damage title)\b/i],["clean",/\b(clean title|clear title|title in hand)\b/i]];function qe(...e){let t=e.filter(Boolean).join(` 
 `);if(!t)return null;for(let[n,r]of Xr)if(r.test(t))return n;return null}var Qr=["grand touring","grand sport","grand limited","trailhawk","overland","laredo","altitude","summit","touring","limited","platinum","titanium","denali","lariat","premium"],Zr=new RegExp(`\\b(${Qr.map(e=>e.replace(/ /g,"\\s+")).join("|")})\\b`,"i");function $t(e){if(!e)return null;let t=e.match(Zr);return t?Ue(t[0].replace(/\s+/g," ").toLowerCase()):null}function Ht(e){if(!e)return null;let t=y(e).replace(/^.*?\bin\s+/i,"");return R(t)?.slice(0,255)??null}function Q(e){if(!e)return null;let t=e.match(/\/marketplace\/item\/(\d+)/);return t?t[1]:null}var Dt='a[href*="/marketplace/item/"]',eo=/seller.?s\s*description|about this vehicle|seller information/i;function Y(e){let n=(e.querySelector("h1")??e.querySelector('[role="heading"][aria-level="1"]')??e.querySelector('[role="heading"]'))?.textContent;return n&&y(n)||null}function pe(e){let t=e.querySelector('[role="main"]')??e.querySelector("main")??e.body,n=Y(t);if(n){let o=Array.from(e.querySelectorAll('[role="dialog"]')).reverse().find(a=>{if(!eo.test(a.textContent??""))return!1;let s=Y(a);if(!s)return!1;let l=n.toLowerCase(),c=s.toLowerCase();return!l.includes(c)&&!c.includes(l)});if(o)return o}return t}function Ve(e){return Array.from(e.querySelectorAll(Dt))}function jt(e){let t=new Set;for(let n of Ve(e)){let r=n.getAttribute("href")?.match(/\/marketplace\/item\/(\d+)/);r&&t.add(r[1])}return Array.from(t)}function me(e,t){let n=Array.from(e.querySelectorAll('h1, h2, h3, h4, [role="heading"]'));for(let r of n){let o=y(r.textContent??"");if(!t.test(o))continue;let a=r.parentElement;for(let s=0;s<12&&a;s+=1){let l=y(a.textContent??"");if(a.querySelector(Dt)||l.length>o.length+20)return a;a=a.parentElement}return r.parentElement}return null}function zt(e){return Array.from(e.querySelectorAll("[aria-label]")).map(t=>t.getAttribute("aria-label")??"").filter(t=>t!=="")}function Bt(e){let t=new Set;for(let n of Array.from(e.querySelectorAll("img"))){let r=n.getAttribute("src");r&&/scontent|fbcdn/i.test(r)&&t.add(r.split("?")[0])}return Array.from(t)}function Ut(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function Ft(e){let t=[],n=e.querySelectorAll('script[type="application/json"]');for(let r of Array.from(n)){let o=r.textContent;if(!(!o||o.length<2))try{t.push(JSON.parse(o))}catch{}}return t}function qt(e,t){let n=e.map(o=>({node:o,depth:0})),r=0;for(;n.length>0;){let o=n.pop();if(o.depth>60)continue;if((r+=1)>4e5)return;let{node:a,depth:s}=o;if(Array.isArray(a)){for(let l of a)typeof l=="object"&&l!==null&&n.push({node:l,depth:s+1});continue}if(Ut(a)){if(t(a)===!0)return;for(let l of Object.values(a))typeof l=="object"&&l!==null&&n.push({node:l,depth:s+1})}}}function Ge(e,t,n=200){let r=[];return qt(e,o=>{if(t(o)&&(r.push(o),r.length>=n))return!0}),r}function fe(e,t){return Ge(e,t,1)[0]??null}function ge(e,t){let n;return qt(e,r=>{for(let o of t){let a=r[o];if(a!=null)return n=a,!0}}),n}function z(e,t){if(e)for(let n of t){let r=e[n];if(r!=null)return r}}function C(e,t){let n=z(e,t);return Ut(n)?n:null}function x(e,t){let n=z(e,t);return typeof n=="string"&&n.trim()!==""?n:typeof n=="number"?String(n):null}function F(e,t){let n=z(e,t),r=typeof n=="string"?Number(n):n;return typeof r=="number"&&Number.isFinite(r)?r:null}function ae(e,t){let n=z(e,t);return Array.isArray(n)?n:null}var Z=class{doc;url;now;listingId;cachedPayloads=null;cachedMain=null;cachedSignature=null;constructor(t,n,r=new Date){this.doc=t,this.url=n,this.now=r,this.listingId=Q(n)}get payloads(){return this.cachedPayloads===null&&(this.cachedPayloads=Ft(this.doc)),this.cachedPayloads}get main(){return this.cachedMain===null&&(this.cachedMain=pe(this.doc)),this.cachedMain}get pageSignature(){if(this.cachedSignature!==null)return this.cachedSignature;let t=[`p:${Vt(this.doc.querySelectorAll('script[type="application/json"]').length)}`,`m:${this.doc.querySelector('[role="main"]')?1:0}`,`h:${this.doc.querySelectorAll('h1, [role="heading"]').length>0?1:0}`,`og:${this.doc.querySelectorAll('meta[property^="og:"]').length}`,`il:${Vt(this.doc.querySelectorAll('a[href*="/marketplace/item/"]').length)}`];return this.cachedSignature=to(t.join("|")),this.cachedSignature}};function Vt(e){return e===0?0:e<=5?1:e<=20?2:e<=60?3:4}function to(e){let t=2166136261;for(let n=0;n<e.length;n+=1)t^=e.charCodeAt(n),t=Math.imul(t,16777619)>>>0;return t.toString(16).padStart(8,"0")}var p={listingTitle:["marketplace_listing_title","custom_title"],listingId:["id","listing_id"],price:["listing_price","price","formatted_price"],priceAmount:["amount"],priceAmountOffset:["amount_with_offset"],priceCurrency:["currency","currency_code"],priceText:["formatted_amount","text"],odometer:["vehicle_odometer_data","odometer"],odometerValue:["value","odometer_value"],odometerUnit:["unit","odometer_unit"],subtitles:["custom_sub_titles_with_rendering_flags","custom_sub_titles"],subtitleText:["subtitle","text"],description:["redacted_description","listing_description","description"],descriptionText:["text"],photos:["listing_photos","all_listing_photos","listing_photo_ids"],location:["location","listing_location"],latitude:["latitude"],longitude:["longitude"],reverseGeocode:["reverse_geocode","reverse_geocode_detailed"],locationVanityOrId:["location_vanity_or_id"],searchRadius:["radius"],city:["city"],state:["state","state_page"],displayName:["display_name"],createdAt:["creation_time","created_time","listing_creation_time"],seller:["marketplace_listing_seller","seller","story_actor"],sellerId:["id"],sellerListingCount:["marketplace_listing_count","active_listings_count","listing_count"],vehicleTrim:["vehicle_trim_display_name","vehicle_trim","trim"],vehicleMake:["vehicle_make_display_name","vehicle_make","make"],vehicleModel:["vehicle_model_display_name","vehicle_model","model"],vehicleYear:["vehicle_year","year"],vehicleSellerType:["vehicle_seller_type","seller_type"],vehicleTransmission:["vehicle_transmission_type","vehicle_transmission"],vehicleCondition:["vehicle_title_status","title_status"],vehicleNumberOfOwners:["vehicle_number_of_owners"],vehicleVin:["vehicle_identification_number"]};function Gt(e,t){return t.some(n=>e[n]!==void 0&&e[n]!==null)}function Kt(e){let t=z(e,p.listingId);return typeof t=="string"&&/^\d+$/.test(t)?t:typeof t=="number"?String(t):null}function Ke(e){return Gt(e,p.listingTitle)}function Yt(e,t){return t?fe(e,n=>Ke(n)&&Kt(n)===t):fe(e,Ke)}function Jt(e){return fe(e,t=>Gt(t,p.photos))}function Wt(e,t=200){let n=Ge(e,Ke,t*4),r=new Map;for(let o of n){let a=Kt(o);if(!a)continue;let s=r.get(a);if((!s||Object.keys(o).length>Object.keys(s).length)&&r.set(a,o),r.size>=t)break}return Array.from(r,([o,a])=>({id:o,node:a}))}var he=/[$£€]\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?|\bfree\b/i,no=/\b\d{1,3},?[xX]{2,4}\b/,Ye=new RegExp(`\\b\\d{1,3}(?:,\\d{3})*(?:\\.\\d+)?\\s*k?\\s*(?:miles|mile|mi|km|kilometers|kilometres)\\b|${no.source}(?:\\s*(?:miles|mile|mi|km|kilometers|kilometres)\\b)?`,"i"),Xt=/\b(?:just listed|listed\s+(?:about\s+)?(?:an?|\d+)\s*(?:minute|hour|day|week|month|year)s?\s+ago|(?:an?|\d+)\s*(?:minute|hour|day|week|month|year)s?\s+ago)/i,Qt=/\b(\d+)\s+of\s+(\d+)\b/,Zt=/\bprice\s*(?:drop|dropped|reduced|lowered)\b|\breduced\b/i;function q(e,t){let n=Array.from(e.querySelectorAll("*")),r=null,o=1/0;for(let a of n){let s=y(a.textContent??"");if(s===""||s.length>=o)continue;let l=s.match(t);l&&(r=y(l[0]),o=s.length)}return r}function en(e,t=40){let n=Array.from(e.querySelectorAll("div, span, p")),r=null;for(let o of n){if(o.querySelector("div, p, a, button"))continue;let a=y(o.textContent??"");a.length<t||(r===null||a.length>r.length)&&(r=a)}return r}function Je(e){let t=ae(e,p.subtitles);if(!t)return[];let n=[];for(let r of t)if(typeof r=="string")n.push(r);else if(typeof r=="object"&&r!==null){let o=x(r,p.subtitleText);o&&n.push(o)}return n}function ve(e,t,n,r=null,o=null){let a=null,s=null,l=e.resolve("mileage",[["json_payload",()=>{let c=C(t,p.odometer);if(!c)return null;let u=Ot(c.value??c.odometer_value);if(u===null)return null;let d=x(c,p.odometerUnit);return a=d&&/km|kilomet/i.test(d)?"km":"mi",u}],["json_payload",()=>{for(let c of Je(t)){let u=K(c);if(u)return a=u.unit,s=c,u.value}return null}],["text_pattern",()=>{if(!o)return null;let c=K(o);return c?(a=c.unit,s=o,c.value):null}],["text_pattern",()=>{if(!n)return null;let c=q(n,Ye);if(!c)return null;let u=K(c);return u?(a=u.unit,s=c,u.value):null}],["text_pattern",()=>{if(!r)return null;let c=q(r,Ye);if(!c)return null;let u=K(c);return u?(a=u.unit,s=c,u.value):null}]]);return{value:l,unit:l===null?null:a??"mi",text:s}}var ro=/\b(?:in\s+)?[A-Z][A-Za-z.'-]+(?:\s+[A-Z][A-Za-z.'-]+)*,\s*[A-Z]{2}\b/;function oo(e){let t=C(e,p.reverseGeocode);if(!t)return null;let n=x(t,p.displayName);if(n)return n;let r=x(t,p.city),o=t.state,a=typeof o=="string"?o:x(C(t,p.state),p.displayName);return r&&a?`${r}, ${a}`:r??null}function be(e,t,n){let r=C(t,p.location),o=e.resolve("location_text",[["json_payload",()=>R(oo(r))],["json_payload",()=>R(x(r,p.displayName))],["text_pattern",()=>n?Ht(q(n,ro)):null]]),a=e.resolve("latitude",[["json_payload",()=>F(r,p.latitude)]]),s=a===null?null:F(r,p.longitude);return{text:o?o.slice(0,255):null,latitude:a,longitude:s}}function tn(e){let t=ge(e,p.searchRadius),n=typeof t=="string"?Number(t):t;if(typeof n!="number"||!Number.isFinite(n)||n<=0)return null;let r=n>1e3?n/1e3:n;return r>5e3?null:Math.round(r)}function ao(e){let t=C(e,p.price);if(!t)return null;let n=z(t,p.priceAmount);if(n!==void 0){let a=Ct(n);if(a!==null)return a}let r=F(t,p.priceAmountOffset);if(r!==null)return Math.round(r);let o=x(t,p.priceText);return o?X(o)?.cents??null:null}function xe(e,t,n){let r=null,o=e.resolve("price_cents",[["json_payload",()=>ao(t)],["text_pattern",()=>n?(r=q(n,he),r?X(r)?.cents??null:null):null]]),a=e.resolve("currency",[["json_payload",()=>x(C(t,p.price),p.priceCurrency)],["text_pattern",()=>r?X(r)?.currency??null:null]]);return{cents:o,currency:a,text:r}}function nn(e,t){let n=[["aria_dom",()=>t&&t.querySelector("s, del, [style*='line-through']")?!0:null],["text_pattern",()=>t&&Zt.test(t.textContent??"")?!0:null]];return e.resolve("price_changed",n)}var so="deal-rater/seller/v1/2f4c8a1d6b93e05f";async function rn(e){let t=e.trim();if(t==="")throw new Error("hashSellerId: empty seller id");let n=new TextEncoder().encode(`${so}:${t}`),r=await crypto.subtle.digest("SHA-256",n);return Array.from(new Uint8Array(r)).map(o=>o.toString(16).padStart(2,"0")).join("")}function on(e){let t=e.querySelector("h1")??e.querySelector('[role="heading"][aria-level="1"]')??e.querySelector('[role="heading"]');if(!t)return e;let n=t.parentElement,r=t.parentElement??e;for(let o=0;o<8&&n&&n!==e;o+=1){let a=y(n.textContent??"");if(/[$£€]\s?\d/.test(a))return n;r=n,n=n.parentElement}return r}function an(e){return me(e,/other listings|more from this seller|seller'?s other|more listings from/i)}function sn(e){return me(e,/seller.?s\s*description/i)??me(e,/^description$|^details$|about this vehicle/i)}var lo=/\/marketplace\/profile\/(\d+)|profile\.php\?id=(\d+)/;function ln(e,t){let n=C(e,p.seller),r=x(n,p.sellerId);if(r&&/^\d+$/.test(r))return r;if(!t)return null;for(let o of Array.from(t.querySelectorAll("a[href]"))){let a=o.getAttribute("href")?.match(lo),s=a?.[1]??a?.[2];if(s)return s}return null}function un(e,t,n){let r=C(e,p.seller),o=F(r,p.sellerListingCount);if(o!==null&&o>=0)return Math.round(o);if(!t)return null;let a=an(t);return a?jt(a).filter(l=>l!==n).length+1:null}var uo=/(\d+(?:\.\d+)?)\s*out of\s*5\s*stars?/i,co=/^\(\s*(\d+)\s*\)$/,po=8;function mo(e){return e.querySelector('[role="img"][aria-label*="out of 5 star"]')}function fo(e){let t=e.parentElement;for(let n=0;n<po&&t;n+=1){for(let r of Array.from(t.querySelectorAll("span"))){let a=y(r.textContent??"").match(co);if(a)return Number(a[1])}t=t.parentElement}return null}function go(e){if(!e)return null;let t=mo(e);if(!t)return null;let r=(t.getAttribute("aria-label")??"").match(uo),o=r?Number(r[1]):null;return o===null||!Number.isFinite(o)||o<0||o>5?null:{average:o,count:fo(t)}}async function ye(e,t,n,r){let o=e.resolve("seller_hash",[["json_payload",()=>ln(t,null)],["url_path",()=>ln(null,n)]]);if(o===null)return null;let a=e.resolve("seller_listing_count",[["json_payload",()=>un(t,null,r)],["aria_dom",()=>un(null,n,r)]]),s=e.resolve("seller_rating",[["aria_dom",()=>go(n)]]);return{seller_hash:await rn(o),hash_version:1,active_vehicle_listing_count:a,rating_average:s?.average??null,rating_count:s?.count??null}}function We(e,t){let r=(e.querySelector(`meta[property="${t}"]`)??e.querySelector(`meta[name="${t}"]`))?.getAttribute("content");return r&&r.trim()!==""?r.trim():null}function se(e){return We(e,"og:title")}function cn(e){return We(e,"og:description")}function Xe(e){return We(e,"og:url")}function Qe(e){let t=e.querySelector('link[rel="canonical"]')?.getAttribute("href");return t&&t.trim()!==""?t.trim():null}function _e(e,t){let{node:n,doc:r,block:o,description:a}=t,s=x(n,p.listingTitle)??(r?se(r):null)??(o?Y(o):null),l=j(s),c=e.resolve("year",[["json_payload",()=>F(n,p.vehicleYear)],["title_text",()=>s?l.year:null],["meta_tag",()=>r?j(se(r)).year:null],["aria_dom",()=>o?j(Y(o)).year:null]]),u=e.resolve("make",[["json_payload",()=>R(x(n,p.vehicleMake))],["title_text",()=>s?l.make:null],["meta_tag",()=>r?j(se(r)).make:null],["aria_dom",()=>o?j(Y(o)).make:null]]),d=e.resolve("model",[["title_text",()=>s?l.model:null],["json_payload",()=>R(x(n,p.vehicleModel))],["meta_tag",()=>r?j(se(r)).model:null],["aria_dom",()=>o?j(Y(o)).model:null]]),f=null,g=e.resolve("trim_text",[["json_payload",()=>{let T=R(x(n,p.vehicleTrim));return T&&(f="fb_catalog"),T}],["title_text",()=>!s||l.trim===null?null:(f=l.trimSource,l.trim)],["text_pattern",()=>{let T=$t(a);return T&&(f="description"),T}]]),m=e.resolve("seller_type",[["json_payload",()=>R(x(n,p.vehicleSellerType))]]),h=e.resolve("transmission",[["json_payload",()=>R(x(n,p.vehicleTransmission))]]),S=e.resolve("title_status",[["json_payload",()=>{let T=x(n,p.vehicleCondition);return T?qe(T)??R(T):null}],["text_pattern",()=>qe(a,s)]]),b=e.resolve("owner_count",[["json_payload",()=>R(x(n,p.vehicleNumberOfOwners))]]);return{year:c,make:u,model:d,trim:g,trimSource:g===null?null:f,titleStatus:S,sellerType:m,transmission:h,ownerCount:b,title:s}}var dn={source_listing_id:"required",listing_url:"required",listing_payload:"required",price_cents:"expected",year:"expected",make:"expected",model:"expected",mileage:"expected",location_text:"expected",photo_count:"expected",posted_at:"expected",seller_hash:"expected",description:"optional",trim_text:"optional",trim_source:"optional",title_status:"optional",vin:"optional",price_changed:"optional",seller_listing_count:"optional",latitude:"optional",currency:"optional",seller_type:"expected",transmission:"optional",owner_count:"optional"},Ze={source_listing_id:"required",listing_url:"required",price_cents:"expected",year:"expected",make:"expected",model:"expected",mileage:"optional",location_text:"optional",photo_count:"optional",posted_at:"optional",seller_hash:"optional",description:"optional",trim_text:"optional",trim_source:"optional",title_status:"optional",vin:"optional",seller_type:"optional",transmission:"optional",owner_count:"optional"},J=class{strategies={};issues=[];scope;expectations;pageSignature;constructor(t,n,r){this.scope=t,this.expectations=n,this.pageSignature=r}resolve(t,n){let r=[];for(let[o,a]of n){r.push(o);let s;try{s=a()}catch{continue}if(s!=null)return this.strategies[t]=o,s}return this.report(t,"missing",r),null}reportUnparsed(t,n=[]){this.report(t,"unparsed",n)}reportSuspect(t,n=[]){this.report(t,"suspect",n)}report(t,n,r){let o=this.expectations[t];o!==void 0&&this.issues.push({scope:this.scope,field_name:t,status:n,expectation:o,strategies_attempted:r,page_signature:this.pageSignature})}};function ie(e){let t=new Map;for(let n of e){let r=`${n.scope}|${n.field_name}|${n.status}`;t.has(r)||t.set(r,n)}return Array.from(t.values())}var ho=120;function pn(e){return{source:"facebook_marketplace",source_listing_id:e,listing_url:`https://www.facebook.com/marketplace/item/${e}/`,role:"comp",price_cents:null,currency:null,mileage:null,mileage_unit:null,year:null,make:null,model:null,trim_text:null,trim_source:null,seller_type:null,transmission:null,title_status:null,owner_count:null,description:null,photo_count:null,posted_at:null,posted_relative_text:null,price_changed:null,location_text:null,latitude:null,longitude:null,vin:null,seller:null,field_strategies:{},raw_extract:null}}async function vo(e,t){let n=Wt(e.payloads,t),r=[],o=[];for(let{id:a,node:s}of n){let l=new J("comp_card",Ze,e.pageSignature);l.strategies.source_listing_id="json_payload",l.strategies.listing_url="url_path";let c=xe(l,s,null),u=_e(l,{node:s,doc:null,block:null,description:null}),d=ve(l,s,null,null,u.title),f=be(l,s,null),g=await ye(l,s,null,a),m=pn(a);m.price_cents=c.cents,m.currency=c.currency,m.mileage=d.value,m.mileage_unit=d.unit,m.year=u.year,m.make=u.make,m.model=u.model,m.trim_text=u.trim,m.trim_source=u.trimSource,m.seller_type=u.sellerType,m.transmission=u.transmission,m.title_status=u.titleStatus,m.owner_count=u.ownerCount,m.location_text=f.text,m.latitude=f.latitude,m.longitude=f.longitude,m.seller=g,m.field_strategies=l.strategies,m.raw_extract={title:u.title,subtitles:Je(s).slice(0,4)},r.push(m),o.push(...l.issues)}return{observations:r,issues:o}}function bo(e,t){let n=[],r=[],o=new Set;for(let a of Ve(e.main)){if(n.length>=t)break;let s=Q(a.getAttribute("href"));if(!s||o.has(s))continue;o.add(s);let l=new J("comp_card",Ze,e.pageSignature);l.strategies.source_listing_id="url_path",l.strategies.listing_url="url_path";let c=y(a.textContent??""),u=pn(s),d=c.match(he)?.[0]??null,f=d?X(d):null;f?(u.price_cents=f.cents,u.currency=f.currency,l.strategies.price_cents="text_pattern"):l.reportUnparsed("price_cents",["text_pattern"]);let g=K(c);g&&(u.mileage=g.value,u.mileage_unit=g.unit,l.strategies.mileage="text_pattern");let m=d?c.replace(d," "):c,h=j(m);u.year=h.year,u.make=h.make,u.model=h.model,u.trim_text=h.trim,u.trim_source=h.trimSource,h.year!==null&&(l.strategies.year="text_pattern"),h.make!==null&&(l.strategies.make="text_pattern"),h.model!==null&&(l.strategies.model="text_pattern"),u.field_strategies=l.strategies,u.raw_extract={card_text:c.slice(0,300)},n.push(u),r.push(...l.issues)}return{observations:n,issues:r}}async function we(e,t,n=new Date,r=ho){let o=new Z(e,t,n),a=await vo(o,r);if(a.observations.length>0)return{observations:a.observations,issues:ie(a.issues)};let s=bo(o,r);return{observations:s.observations,issues:ie(s.issues)}}var xo=200;function mn(e,t,n,r=null){return e.resolve("photo_count",[["aria_dom",()=>{if(!n)return null;for(let o of zt(n)){let a=o.match(Qt);if(a){let s=Number(a[2]);if(Number.isFinite(s)&&s>0&&s<=xo)return s}}return null}],["json_payload",()=>{let o=ae(r,p.photos)??ae(t,p.photos),a=n?Bt(n).length:0;return o===null&&a===0?null:Math.max(o?.length??0,a)}]])}var fn="[PHONE]",yo="[EMAIL]",_o=/\b[\w.+-]+@[\w-]+\.[\w.-]{2,}\b/gi,wo=/(?<![\w-])(?:\+?1[\s.\-]*)?(?:\(\s*\d{3}\s*\)|\d{3})[\s.\-]*\d{3}[\s.\-]*\d{4}(?![\w-])/g,gn="(?:zero|one|two|three|four|five|six|seven|eight|nine|oh)",ko=new RegExp(`\\b(?:${gn}[\\s.\\-]+){6,}${gn}\\b`,"gi");function hn(e){return e==null?null:e.replace(_o,yo).replace(wo,fn).replace(ko,fn)}var Eo="[A-HJ-NPR-Z0-9]",To=new RegExp(`(?<![A-Z0-9])${Eo}{17}(?![A-Z0-9])`,"gi"),So={A:1,B:2,C:3,D:4,E:5,F:6,G:7,H:8,J:1,K:2,L:3,M:4,N:5,P:7,R:9,S:2,T:3,U:4,V:5,W:6,X:7,Y:8,Z:9},Mo=[8,7,6,5,4,3,2,10,0,9,8,7,6,5,4,3,2],Ao=8;function Ro(e){let t=e.toUpperCase();if(t.length!==17||/[IOQ]/.test(t)||!/^[A-HJ-NPR-Z0-9]{17}$/.test(t))return!1;let n=0;for(let a=0;a<17;a+=1){let s=t[a],l=s>="0"&&s<="9"?Number(s):So[s];if(l===void 0)return!1;n+=l*Mo[a]}let r=n%11,o=r===10?"X":String(r);return t[Ao]===o}function ke(e){if(!e)return null;let t=e.toUpperCase().match(To);if(!t)return null;for(let n of t)if(Ro(n))return n;return null}var Co=2e4;function vn(e,t,n,r){let o=e.resolve("description",[["json_payload",()=>{let s=C(t,p.description);return s?x(s,p.descriptionText):x(t,p.description)}],["aria_dom",()=>r?en(r):null],["meta_tag",()=>n?cn(n):null]]);if(o===null)return null;let a=hn(o.slice(0,Co));return R(a)===null?"":a}function bn(e,t,n,r){return e.resolve("vin",[["json_payload",()=>ke(x(t,p.vehicleVin))],["text_pattern",()=>ke(n)],["text_pattern",()=>ke(r)]])}function xn(e,t,n,r){let o=null;return{postedAt:e.resolve("posted_at",[["json_payload",()=>It(z(t,p.createdAt))],["text_pattern",()=>{if(!n)return null;let s=q(n,Xt);if(!s)return null;let l=Nt(s,r);return l?(o=l.relativeText,l.postedAt):null}]]),relativeText:o}}function Oo(e){return e?`https://www.facebook.com/marketplace/item/${e}/`:null}async function le(e,t,n=new Date){let r=new Z(e,t,n),o=new J("target",dn,r.pageSignature),a=o.resolve("listing_payload",[["json_payload",()=>Yt(r.payloads,r.listingId)]]),s=o.resolve("source_listing_id",[["url_path",()=>r.listingId],["meta_tag",()=>Q(Qe(e)??Xe(e))]]),l=o.resolve("listing_url",[["url_path",()=>Oo(s)],["meta_tag",()=>Qe(e)??Xe(e)]]),c=r.main,u=on(c),d=sn(c),f=xe(o,a,u),g=nn(o,u),m=vn(o,a,e,d),h=_e(o,{node:a,doc:e,block:u,description:m}),S=ve(o,a,u,d,h.title),b=bn(o,a,m,h.title),T=a?Jt(r.payloads):null,I=mn(o,a,u,T),$=be(o,a,u),H=xn(o,a,u,n),O=await ye(o,a,c,s),v=ge(r.payloads,p.locationVanityOrId),k=tn(r.payloads),_=typeof v=="string"&&/^[A-Za-z0-9.-]{3,64}$/.test(v)?v:null;return{observation:{source:"facebook_marketplace",source_listing_id:s??"",listing_url:l,role:"target",price_cents:f.cents,currency:f.currency,mileage:S.value,mileage_unit:S.unit,year:h.year,make:h.make,model:h.model,trim_text:h.trim,trim_source:h.trimSource,seller_type:h.sellerType,transmission:h.transmission,title_status:h.titleStatus,owner_count:h.ownerCount,description:m,photo_count:I,posted_at:H.postedAt?H.postedAt.toISOString():null,posted_relative_text:H.relativeText,price_changed:g,location_text:$.text,latitude:$.latitude,longitude:$.longitude,vin:b,seller:O,field_strategies:o.strategies,raw_extract:{title:h.title,price_text:f.text,mileage_text:S.text,posted_text:H.relativeText,page_signature:r.pageSignature}},issues:o.issues,pageSignature:r.pageSignature,usable:s!==null,locationId:_,searchRadiusKm:k,payloadMatched:a!==null}}var yn={apiBaseUrl:"https://deal-rater-production.up.railway.app",theme:"auto",enabled:!0,devMode:!1,disclosureAcceptedAt:null,extraMetroIds:[]};async function ee(){let e=await chrome.storage.sync.get(yn);return{...yn,...e}}async function _n(e){await chrome.storage.sync.set(e)}var Lo=["all wheel drive","front wheel drive","rear wheel drive","four wheel drive","sport utility","passenger van","regular cab","extended cab","double cab","supercrew","quad cab","crew cab","ext cab","hatchback","convertible","minivan","roadster","pickup","coupe","sedan","wagon","truck","suv","van","cab","4dr","2dr","awd","fwd","rwd","4wd","4x4","4d","2d","ft"],Po=[/[^\x00-\x7f]+/g,/\bw\/.*$/g,/\b\d[\d,]*\s*k?\s*miles?\b/g],No=/^\d+\.\d+[a-z]*$/,et=/[^a-z0-9.]+/g;function ue(e,t){if(!e)return new Set;let n=e.toLowerCase();for(let a of Po)n=n.replace(a," ");n=n.replace(et," ");let r=` ${n.split(/\s+/).filter(Boolean).join(" ")} `;for(let a of Lo)for(;r.includes(` ${a} `);)r=r.replace(` ${a} `," ");let o=new Set((t??"").toLowerCase().split(et).filter(Boolean));return new Set(r.split(/\s+/).filter(a=>a.length>0&&!o.has(a)&&!/^\d+$/.test(a)&&!No.test(a)))}function wn(e,t){if(e.size===0||t.size===0||e.size!==t.size)return!1;for(let n of e)if(!t.has(n))return!1;return!0}function kn(e,t){let n=ue(e,t);if(n.size===0)return null;let r=(e??"").toLowerCase().replace(et," ").split(/\s+/).filter(o=>n.has(o));return[...new Set(r)].join(" ")||null}var Tn="https://www.facebook.com/marketplace",Io=`${Tn}/search/`,tt=/^(?:[0-9]{15}|[a-z][a-z0-9-]{2,40})$/i,En="546583916084032";function Sn(e,t){return tt.test(t)?Ee(e,t):null}function Mn(e,t){if(!tt.test(t??""))return null;let n=kn(e.trim_text,e.model);if(n===null)return null;let r=Ee(e,t,n);return r===null?null:{...r,fallbackUrl:null}}function Ee(e,t=null,n=null){let{year:r,make:o,model:a}=e;if(!a||!o)return null;let l=[r!==null?String(r):null,o,a,n].filter(Boolean).join(" "),c={year:r,make:o,model:a,trim:n},u=new URL(Io);u.searchParams.set("query",l),u.searchParams.set("category_id",En);let d=tt.test(t??"")?t:null;if(d===null)return{url:u.toString(),fallbackUrl:null,query:{query:l,derived_from:c,location_id:null}};let f=new URL(`${Tn}/${d}/search/`);return f.searchParams.set("query",l),f.searchParams.set("category_id",En),{url:f.toString(),fallbackUrl:u.toString(),query:{query:l,derived_from:c,location_id:d}}}var Se=[{slug:"nyc",name:"New York",states:["NY","NJ","CT","PA"],lat:40.71,lon:-74.01,rust:"salt",tier:"high"},{slug:"boston",name:"Boston",states:["MA","NH","RI"],lat:42.36,lon:-71.06,rust:"salt",tier:"high"},{slug:"philadelphia",name:"Philadelphia",states:["PA","NJ","DE"],lat:39.95,lon:-75.17,rust:"salt",tier:"moderate"},{slug:"pittsburgh",name:"Pittsburgh",states:["PA","WV","OH"],lat:40.44,lon:-79.996,rust:"salt",tier:"low"},{slug:"hartford",name:"Hartford",states:["CT","MA"],lat:41.76,lon:-72.69,rust:"salt",tier:"moderate"},{slug:"buffalo",name:"Buffalo",states:["NY"],lat:42.89,lon:-78.88,rust:"salt",tier:"low"},{slug:"rochester",name:"Rochester",states:["NY"],lat:43.16,lon:-77.61,rust:"salt",tier:"low"},{slug:"providence",name:"Providence",states:["RI","MA"],lat:41.82,lon:-71.41,rust:"salt",tier:"moderate"},{slug:"chicago",name:"Chicago",states:["IL","IN","WI"],lat:41.88,lon:-87.63,rust:"salt",tier:"moderate"},{slug:"detroit",name:"Detroit",states:["MI","OH"],lat:42.33,lon:-83.05,rust:"salt",tier:"low"},{slug:"milwaukee",name:"Milwaukee",states:["WI"],lat:43.04,lon:-87.91,rust:"salt",tier:"low"},{slug:"minneapolis",name:"Minneapolis",states:["MN","WI"],lat:44.98,lon:-93.27,rust:"salt",tier:"moderate"},{slug:"cleveland",name:"Cleveland",states:["OH"],lat:41.5,lon:-81.69,rust:"salt",tier:"low"},{slug:"columbus",name:"Columbus",states:["OH"],lat:39.96,lon:-83,rust:"salt",tier:"low"},{slug:"cincinnati",name:"Cincinnati",states:["OH","KY","IN"],lat:39.1,lon:-84.51,rust:"mixed",tier:"low"},{slug:"indianapolis",name:"Indianapolis",states:["IN"],lat:39.77,lon:-86.16,rust:"mixed",tier:"low"},{slug:"grandrapids",name:"Grand Rapids",states:["MI"],lat:42.96,lon:-85.67,rust:"salt",tier:"low"},{slug:"washingtondc",name:"Washington DC",states:["DC","VA","MD"],lat:38.91,lon:-77.04,rust:"mixed",tier:"high"},{slug:"baltimore",name:"Baltimore",states:["MD"],lat:39.29,lon:-76.61,rust:"mixed",tier:"moderate"},{slug:"richmond",name:"Richmond",states:["VA"],lat:37.54,lon:-77.44,rust:"mixed",tier:"moderate"},{slug:"virginiabeach",name:"Virginia Beach",states:["VA","NC"],lat:36.85,lon:-75.98,rust:"mixed",tier:"moderate"},{slug:"stlouis",name:"St. Louis",states:["MO","IL"],lat:38.63,lon:-90.2,rust:"mixed",tier:"low"},{slug:"kansascity",name:"Kansas City",states:["MO","KS"],lat:39.1,lon:-94.58,rust:"mixed",tier:"low"},{slug:"springfieldmo",name:"Springfield MO",states:["MO"],lat:37.21,lon:-93.29,rust:"mixed",tier:"low"},{slug:"desmoines",name:"Des Moines",states:["IA"],lat:41.59,lon:-93.62,rust:"salt",tier:"low"},{slug:"omaha",name:"Omaha",states:["NE","IA"],lat:41.26,lon:-95.93,rust:"salt",tier:"low"},{slug:"wichita",name:"Wichita",states:["KS"],lat:37.69,lon:-97.34,rust:"mixed",tier:"low"},{slug:"louisville",name:"Louisville",states:["KY","IN"],lat:38.25,lon:-85.76,rust:"mixed",tier:"low"},{slug:"dallas",name:"Dallas",states:["TX"],lat:32.78,lon:-96.8,rust:"sun",tier:"moderate"},{slug:"houston",name:"Houston",states:["TX"],lat:29.76,lon:-95.37,rust:"sun",tier:"moderate"},{slug:"austin",name:"Austin",states:["TX"],lat:30.27,lon:-97.74,rust:"sun",tier:"moderate"},{slug:"sanantonio",name:"San Antonio",states:["TX"],lat:29.42,lon:-98.49,rust:"sun",tier:"low"},{slug:"oklahomacity",name:"Oklahoma City",states:["OK"],lat:35.47,lon:-97.52,rust:"mixed",tier:"low"},{slug:"tulsa",name:"Tulsa",states:["OK"],lat:36.15,lon:-95.99,rust:"mixed",tier:"low"},{slug:"littlerock",name:"Little Rock",states:["AR"],lat:34.75,lon:-92.29,rust:"sun",tier:"low"},{slug:"neworleans",name:"New Orleans",states:["LA"],lat:29.95,lon:-90.07,rust:"sun",tier:"low"},{slug:"memphis",name:"Memphis",states:["TN","MS","AR"],lat:35.15,lon:-90.05,rust:"sun",tier:"low"},{slug:"nashville",name:"Nashville",states:["TN"],lat:36.16,lon:-86.78,rust:"mixed",tier:"moderate"},{slug:"atlanta",name:"Atlanta",states:["GA"],lat:33.75,lon:-84.39,rust:"sun",tier:"moderate"},{slug:"charlotte",name:"Charlotte",states:["NC","SC"],lat:35.23,lon:-80.84,rust:"sun",tier:"moderate"},{slug:"raleigh",name:"Raleigh",states:["NC"],lat:35.78,lon:-78.64,rust:"sun",tier:"moderate"},{slug:"jacksonville",name:"Jacksonville",states:["FL","GA"],lat:30.33,lon:-81.66,rust:"sun",tier:"moderate"},{slug:"orlando",name:"Orlando",states:["FL"],lat:28.54,lon:-81.38,rust:"sun",tier:"moderate"},{slug:"tampa",name:"Tampa",states:["FL"],lat:27.95,lon:-82.46,rust:"sun",tier:"moderate"},{slug:"miami",name:"Miami",states:["FL"],lat:25.76,lon:-80.19,rust:"sun",tier:"high"},{slug:"birmingham",name:"Birmingham",states:["AL"],lat:33.52,lon:-86.8,rust:"sun",tier:"low"},{slug:"denver",name:"Denver",states:["CO"],lat:39.74,lon:-104.99,rust:"mixed",tier:"high"},{slug:"saltlakecity",name:"Salt Lake City",states:["UT"],lat:40.76,lon:-111.89,rust:"mixed",tier:"moderate"},{slug:"albuquerque",name:"Albuquerque",states:["NM"],lat:35.08,lon:-106.65,rust:"sun",tier:"low"},{slug:"boise",name:"Boise",states:["ID"],lat:43.62,lon:-116.2,rust:"mixed",tier:"moderate"},{slug:"phoenix",name:"Phoenix",states:["AZ"],lat:33.45,lon:-112.07,rust:"sun",tier:"moderate"},{slug:"tucson",name:"Tucson",states:["AZ"],lat:32.22,lon:-110.97,rust:"sun",tier:"low"},{slug:"lasvegas",name:"Las Vegas",states:["NV"],lat:36.17,lon:-115.14,rust:"sun",tier:"moderate"},{slug:"losangeles",name:"Los Angeles",states:["CA"],lat:34.05,lon:-118.24,rust:"sun",tier:"high"},{slug:"sandiego",name:"San Diego",states:["CA"],lat:32.72,lon:-117.16,rust:"sun",tier:"high"},{slug:"sanfrancisco",name:"San Francisco",states:["CA"],lat:37.77,lon:-122.42,rust:"sun",tier:"high"},{slug:"sacramento",name:"Sacramento",states:["CA"],lat:38.58,lon:-121.49,rust:"sun",tier:"moderate"},{slug:"fresno",name:"Fresno",states:["CA"],lat:36.74,lon:-119.79,rust:"sun",tier:"low"},{slug:"portland",name:"Portland",states:["OR","WA"],lat:45.51,lon:-122.68,rust:"mixed",tier:"high"},{slug:"seattle",name:"Seattle",states:["WA"],lat:47.61,lon:-122.33,rust:"mixed",tier:"high"},{slug:"spokane",name:"Spokane",states:["WA","ID"],lat:47.66,lon:-117.43,rust:"mixed",tier:"low"}],Bi=new Map(Se.map(e=>[e.slug,e])),$o=550,Ho=["salt","mixed","sun"],Do=["low","moderate","high"];function An(e,t,n){return Math.abs(e.indexOf(t)-e.indexOf(n))}function Cn(e,t){let n=s=>s*Math.PI/180,r=n(t.lat-e.lat),o=n(t.lon-e.lon),a=Math.sin(r/2)**2+Math.cos(n(e.lat))*Math.cos(n(t.lat))*Math.sin(o/2)**2;return 3958.8*2*Math.asin(Math.sqrt(a))}function On(e,t=8){return Se.filter(n=>n.slug!==e.slug).filter(n=>An(Ho,n.rust,e.rust)<=1).filter(n=>An(Do,n.tier,e.tier)<=1).map(n=>({metro:n,miles:Cn(e,n)})).filter(({miles:n})=>n<=$o).sort((n,r)=>n.miles-r.miles).slice(0,t).map(({metro:n})=>n)}function Ln(e,t){if(t.length===0)return!1;let n=new Set(e.states);return t.some(r=>{let o=r.split(",").pop()?.trim().toUpperCase();return o?n.has(o):!1})}var jo=120;function Pn(e,t){if(e===null||t===null)return null;let n={lat:e,lon:t},r=null,o=1/0;for(let a of Se){let s=Cn(n,a);s<o&&(o=s,r=a)}return o<=jo?r:null}var zo=2,Bo=/ [a-z]{2}$/;function Nn(e){return e.toLowerCase().replace(/[^a-z0-9 ]/g,"").replace(/\s+/g," ").trim()}function Rn(e){if(!e||!e.includes(","))return[null,null];let t=e.lastIndexOf(","),n=Nn(e.slice(0,t)),r=e.slice(t+1).trim().toUpperCase();return[n||null,r||null]}var Te=new Map;for(let e of Se){let t=Nn(e.name),n=t.replace(Bo,"");for(let r of n===t?[t]:[t,n]){let o=Te.get(r);o?o.push(e):Te.set(r,[e])}}function Uo(e,t){if(!e)return null;for(let n of Te.get(e)??[])if(t===null||n.states.includes(t))return n;return null}function In(e,t=[]){let[n,r]=Rn(e),o=Uo(n,r);if(o)return o;if(r===null)return null;let a=new Map;for(let c of t){let[u]=Rn(c);if(u)for(let d of Te.get(u)??[]){if(!d.states.includes(r))continue;let f=a.get(d.slug);f?f.count+=1:a.set(d.slug,{metro:d,count:1});break}}let[s,l]=[...a.values()].sort((c,u)=>u.count-c.count);return!s||s.count<zo||l&&l.count===s.count?null:s.metro}var Fo=30,nt=6,qo=4,Vo=.5;function $n(e,t){return e<=0?!0:t/e>=Vo}function Hn(e,t){return!(t.price_cents===null||t.price_cents<=0||!t.make||!t.model||!e.make||!e.model||t.make.toLowerCase()!==e.make.toLowerCase()||Fe(t.model)!==Fe(e.model)||e.year!==null&&t.year!==null&&Math.abs(t.year-e.year)>qo)}function Me(e,t){return t.reduce((n,r)=>n+(Hn(e,r)?1:0),0)}function Go(e,t){return wn(ue(e.trim_text,e.model),ue(t.trim_text,t.model))}function Ae(e,t){return t.reduce((n,r)=>n+(Hn(e,r)&&Go(e,r)?1:0),0)}function Dn(e,t){let n=new Set(t);return e.filter(r=>!n.has(r.slug))}function jn(e,t,n,r=Fo,o=nt){return n<=0?!1:Me(e,t)<r||ue(e.trim_text,e.model).size>0&&Ae(e,t)<o}var rt="badMetroSlugs";async function ot(){let t=(await chrome.storage.local.get({[rt]:[]}))[rt];return Array.isArray(t)?t:[]}async function zn(e){let t=await ot();t.includes(e)||await chrome.storage.local.set({[rt]:[...t,e]})}function te(e){return chrome.runtime.sendMessage(e)}var Ko=2e4;function Yo(e){let t=e.querySelectorAll('script[type="application/json"]').length>0,n=e.querySelectorAll('a[href*="/marketplace/item/"]').length>0;return!t&&!n}async function at(e){let t=new AbortController,n=setTimeout(()=>t.abort(),Ko);try{let r=await fetch(e,{credentials:"include",signal:t.signal,headers:{Accept:"text/html"}});if(!r.ok)return null;let o=await r.text();return new DOMParser().parseFromString(o,"text/html")}catch{return null}finally{clearTimeout(n)}}async function ce(e,t=new Date){let n=await at(e);if(n&&!Yo(n)){let o=await we(n,e,t);if(o.observations.length>0)return{...o,source:"same_origin_fetch"}}let r=await te({type:"HARVEST_COMPS_VIA_TAB",url:e});return r?.ok?{observations:r.observations,issues:r.issues,source:"background_tab"}:{observations:[],issues:[],source:"none"}}var V={dark:{sheet:"#10181f",raised:"#16212b",text:"#e8eef4",textMuted:"#a9bccb",textDim:"#8fa3b4",textFaint:"#76899b",border:"#24333f",borderFaint:"#1b2831",track:"#22313d",link:"#7fb8e8",beta:"#d9b26a",betaOn:"#10181f",scrim:"rgba(6, 12, 18, 0.55)",elev1:"0 1px 2px rgba(0,0,0,.32)",elev2:"0 6px 20px rgba(0,0,0,.38)",elev3:"-6px 0 32px rgba(0,0,0,.48)"},light:{sheet:"#ffffff",raised:"#f3f6f9",text:"#0f1a22",textMuted:"#41576a",textDim:"#566e80",textFaint:"#5f7383",border:"#d5dee5",borderFaint:"#e7edf1",track:"#e2e9ef",link:"#1e6aa8",beta:"#8a5f06",betaOn:"#ffffff",scrim:"rgba(16, 26, 34, 0.38)",elev1:"0 1px 2px rgba(16,26,34,.07)",elev2:"0 6px 20px rgba(16,26,34,.10)",elev3:"-6px 0 32px rgba(16,26,34,.16)"}},Jo={favorable:{dark:{text:"#7fd1a8",fill:"#4f9e78",surface:"#12291f",border:"#245c40",onSurface:"#cfe7db"},light:{text:"#0e6a41",fill:"#2f9e6a",surface:"#eaf6f0",border:"#b4dcc8",onSurface:"#0c4c30"}},caution:{dark:{text:"#e2b877",fill:"#c99a4e",surface:"#2b2113",border:"#5f4620",onSurface:"#ecdcc0"},light:{text:"#8a5806",fill:"#cf9a3a",surface:"#fdf4e4",border:"#ecd2a4",onSurface:"#5c3c05"}},adverse:{dark:{text:"#f0a5a5",fill:"#c2685f",surface:"#3a1719",border:"#7a2f2f",onSurface:"#f2d5d5"},light:{text:"#b02a23",fill:"#d3544a",surface:"#fdeeed",border:"#f1c3bf",onSurface:"#6d1f1a"}},neutral:{dark:{text:V.dark.textDim,fill:"#5c9ecf",surface:V.dark.raised,border:V.dark.border,onSurface:V.dark.textMuted},light:{text:V.light.textDim,fill:"#3d84bd",surface:V.light.raised,border:V.light.border,onSurface:V.light.textMuted}}},N={favorable:"\u2713",caution:"\u26A0",adverse:"\u2715",neutral:"\xB7"},Wo={poor:{text:{dark:"#e35c58",light:"#c22f28"},size:"var(--fs-d1)"},weak:{text:{dark:"#e0904a",light:"#a9600c"},size:"var(--fs-d2)"},fair:{text:{dark:"#dcc257",light:"#7d6a06"},size:"var(--fs-d3)"},good:{text:{dark:"#8ecb6b",light:"#3d7f2a"},size:"var(--fs-d4)"},excellent:{text:{dark:"#3fab5e",light:"#166b38"},size:"var(--fs-d5)"}},Xo=`
    --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
    --font-num: var(--font-sans);

    --fs-2xs: 10px;
    --fs-xs: 11px;
    --fs-sm: 12px;
    --fs-base: 13px;
    --fs-md: 15px;
    --fs-lg: 19px;
    --fs-xl: 24px;

    --fs-d1: 32px;
    --fs-d2: 34px;
    --fs-d3: 36px;
    --fs-d4: 39px;
    --fs-d5: 42px;

    --sp-1: 4px;
    --sp-2: 6px;
    --sp-3: 8px;
    --sp-4: 12px;
    --sp-5: 16px;
    --sp-6: 20px;
    --sp-7: 28px;

    --radius-sm: 4px;
    --radius-md: 8px;
    --radius-lg: 12px;
    --radius-pill: 999px;

    --dur-fast: 110ms;
    --dur-base: 200ms;
    --dur-slow: 320ms;
    --ease-out: cubic-bezier(.16, .84, .44, 1);
    --ease-spring: cubic-bezier(.34, 1.28, .64, 1);
`;function Re(e){let t=V[e],n=[`--sheet: ${t.sheet};`,`--raised: ${t.raised};`,`--text: ${t.text};`,`--text-muted: ${t.textMuted};`,`--text-dim: ${t.textDim};`,`--text-faint: ${t.textFaint};`,`--border: ${t.border};`,`--border-faint: ${t.borderFaint};`,`--track: ${t.track};`,`--link: ${t.link};`,`--focus: ${t.link};`,`--beta: ${t.beta};`,`--beta-on: ${t.betaOn};`,`--scrim: ${t.scrim};`,`--elev-1: ${t.elev1};`,`--elev-2: ${t.elev2};`,`--elev-3: ${t.elev3};`,`color-scheme: ${e};`];for(let[r,o]of Object.entries(Jo)){let a=o[e];n.push(`--tone-${r}-text: ${a.text};`,`--tone-${r}-fill: ${a.fill};`,`--tone-${r}-surface: ${a.surface};`,`--tone-${r}-border: ${a.border};`,`--tone-${r}-on-surface: ${a.onSurface};`)}for(let[r,o]of Object.entries(Wo))n.push(`--grade-${r}-text: ${o.text[e]};`,`--grade-${r}-size: ${o.size};`);return n.map(r=>`    ${r}`).join(`
`)}function Ce(e=":host"){let t=n=>e.startsWith(":host")?`${e}([data-theme="${n}"])`:`${e}[data-theme="${n}"]`;return`
  ${e} {
${Xo}
${Re("light")}
  }

  @media (prefers-color-scheme: dark) {
    ${e} {
${Re("dark")}
    }
  }

  ${t("light")} {
${Re("light")}
  }

  ${t("dark")} {
${Re("dark")}
  }
`}function i(e,t,n){let r=document.createElement(e);return t&&(r.className=t),n!==void 0&&(r.textContent=n),r}function E(e){return e==null?"n/a":`$${Math.round(e/100).toLocaleString("en-US")}`}function Bn(){return typeof matchMedia=="function"&&matchMedia("(prefers-reduced-motion: reduce)").matches}function ne(e,t){let n=Math.max(0,Math.min(1,Number.isFinite(t)?t:0));return e.dataset.fill=`${n*100}%`,e}function Un(e){let t=Array.from(e.querySelectorAll("[data-fill]")),n=()=>{for(let r of t)r.style.width=r.dataset.fill??"0%"};typeof requestAnimationFrame=="function"?requestAnimationFrame(()=>requestAnimationFrame(n)):n()}function B(e,t){let n=i("span","chip");return n.dataset.tone=e,n.append(i("span","chip-glyph",N[e]),i("span",void 0,t)),n}function Fn(e,t,n){let r=i("div","callout");r.dataset.tone=e;let o=i("h3");o.append(i("span","callout-glyph",N[e]),i("span",void 0,t)),r.append(o);for(let a of n)r.append(typeof a=="string"?i("p",void 0,a):a);return r}function U(e,t,n,r){let o=i("details","disclosure"),a=i("summary"),s=i("span","disclosure-title",e);a.append(s),r&&a.append(r),t!==""&&a.append(typeof t=="string"?i("span","disclosure-summary",t):t);let l=i("div","disclosure-body");return l.append(...n),o.append(a,l),o}function Oe(e,t){let n=i("div","note-pill"),r=i("div","note-pill-body");return r.append(i("span",void 0,e)),t&&r.append(i("span","note-pill-source",t)),n.append(i("span","note-pill-glyph","\u24D8"),r),n}function st(){let e=i("span","ai-badge");return e.title="Written by Claude for this model and mileage.",e.append(i("span","ai-badge-glyph","\u2726"),i("span",void 0,"AI")),e}function qn(e,t,n,r){if(t.length===0)return null;let o=i("section"),a=i("h2",void 0,e);if(n||r){let s=i("div","section-heading-row");s.append(a),n&&s.append(n),r&&s.append(r),o.append(s,...t)}else o.append(a,...t);return o}function G(e,t){if(e.length===0)return null;let n=i("ul",t);for(let r of e)n.append(i("li",void 0,r));return n}function it(e){let t=i("dl","rows");for(let[n,r,o]of e){let a=i("dd",o?.big?"big":void 0);o?.tone?(a.dataset.tone=o.tone,a.append(i("span","row-glyph",N[o.tone]),i("span",void 0,r))):a.textContent=r,t.append(i("dt",void 0,n),a)}return t}function lt(e,t,n="neutral",r){let o=i("div","stat");o.dataset.tone=n;let a=i("div","stat-figure");return n!=="neutral"&&a.append(i("span","stat-glyph",N[n])),a.append(i("span","stat-value",t)),o.append(a,i("div","stat-label",e)),r&&o.append(i("p","stat-note",r)),o}function Vn(e,t,n,r="neutral"){let o=i("div","meter-row"),a=i("div","meter-head");a.append(i("span","meter-label",e),i("span","meter-value",t));let s=i("div","meter"),l=i("i");return l.dataset.tone=r,s.append(ne(l,n)),o.append(a,s),o}function ut(e,t="Copy"){let n=i("button","copy");n.type="button";let r=i("span","copy-glyph","\u29C9"),o=i("span",void 0,t);n.append(r,o);let a,s=(l,c,u)=>{n.dataset.state=l,r.textContent=u,o.textContent=c,a&&clearTimeout(a),a=setTimeout(()=>{delete n.dataset.state,r.textContent="\u29C9",o.textContent=t},1600)};return n.addEventListener("click",l=>{l.preventDefault(),l.stopPropagation(),navigator.clipboard?.writeText(e).then(()=>s("done","Copied",N.favorable)).catch(()=>s("failed","Press \u2318C",N.caution))}),n}function Gn(e,t="Open listing"){let n=i("a");return n.href=e,n.target="_blank",n.rel="noopener noreferrer",n.textContent=t,n.append(i("span","link-arrow","\u2192")),n}var Kn=`
  section { padding: var(--sp-5) var(--sp-6); border-bottom: 1px solid var(--border-faint); }
  h2 {
    margin: 0 0 var(--sp-4); font-size: var(--fs-xs); font-weight: 700;
    letter-spacing: .08em; text-transform: uppercase; color: var(--text-dim);
  }
  .section-heading-row {
    display: flex; align-items: center; gap: var(--sp-3); margin: 0 0 var(--sp-4);
  }
  .section-heading-row h2 { margin: 0; }

  /* rows -------------------------------------------------------------- */
  .rows {
    display: grid; grid-template-columns: auto 1fr;
    gap: var(--sp-2) var(--sp-5); font-size: var(--fs-base);
    align-items: baseline;
  }
  .rows dt { color: var(--text-dim); }
  .rows dd {
    margin: 0; font-family: var(--font-num);
    font-variant-numeric: tabular-nums; font-feature-settings: "tnum" 1;
  }
  .rows dd.big {
    font-size: var(--fs-md); font-weight: 650; letter-spacing: -.01em; color: var(--text);
  }
  .rows dd[data-tone] { display: flex; align-items: baseline; gap: var(--sp-2); }
  .rows dd[data-tone="favorable"] { color: var(--tone-favorable-text); }
  .rows dd[data-tone="caution"]   { color: var(--tone-caution-text); }
  .rows dd[data-tone="adverse"]   { color: var(--tone-adverse-text); }
  .row-glyph { font-size: var(--fs-xs); }

  ul {
    margin: var(--sp-3) 0 0; padding-left: var(--sp-5);
    font-size: var(--fs-sm); line-height: 1.55; color: var(--text-muted);
  }
  li { margin-bottom: var(--sp-1); }
  li::marker { color: var(--text-faint); }
  .muted {
    color: var(--text-dim); font-size: var(--fs-sm); line-height: 1.5; margin: var(--sp-3) 0 0;
  }

  /* callout ----------------------------------------------------------- */
  .callout {
    position: relative; overflow: hidden;
    border: 1px solid; border-radius: var(--radius-md);
    padding: var(--sp-4) var(--sp-4) var(--sp-4) var(--sp-5);
    margin: 0 0 var(--sp-4);
  }
  /* A left rail as well as a tint. On light the tint alone is a very pale
     wash, and a pale wash is not a warning. */
  .callout::before {
    content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 3px;
    background: currentColor; opacity: .85;
  }
  .callout h3 {
    margin: 0 0 var(--sp-2); font-size: var(--fs-base); font-weight: 650;
    display: flex; align-items: baseline; gap: var(--sp-2);
  }
  .callout p { margin: 0; font-size: var(--fs-sm); line-height: 1.5; }
  .callout p + p { margin-top: var(--sp-2); }
  .callout ul { color: inherit; }
  .callout-glyph { font-size: var(--fs-sm); }
  .callout[data-tone="adverse"] {
    background: var(--tone-adverse-surface); border-color: var(--tone-adverse-border);
    color: var(--tone-adverse-on-surface);
  }
  .callout[data-tone="adverse"] h3, .callout[data-tone="adverse"]::before {
    color: var(--tone-adverse-text);
  }
  .callout[data-tone="caution"] {
    background: var(--tone-caution-surface); border-color: var(--tone-caution-border);
    color: var(--tone-caution-on-surface);
  }
  .callout[data-tone="caution"] h3, .callout[data-tone="caution"]::before {
    color: var(--tone-caution-text);
  }
  .callout[data-tone="favorable"] {
    background: var(--tone-favorable-surface); border-color: var(--tone-favorable-border);
    color: var(--tone-favorable-on-surface);
  }
  .callout[data-tone="favorable"] h3, .callout[data-tone="favorable"]::before {
    color: var(--tone-favorable-text);
  }
  .callout[data-tone="neutral"] {
    background: var(--raised); border-color: var(--border); color: var(--text-muted);
  }
  .callout[data-tone="neutral"]::before { color: var(--border); }

  /* disclosure -------------------------------------------------------- */
  .disclosure { border-bottom: 1px solid var(--border-faint); }
  .disclosure > summary {
    display: flex; align-items: center; gap: var(--sp-3); flex-wrap: wrap;
    padding: var(--sp-4) var(--sp-6); cursor: pointer; list-style: none;
    transition: background var(--dur-fast) var(--ease-out);
  }
  .disclosure > summary::-webkit-details-marker { display: none; }
  /* A chevron rather than +/-: it rotates, so opening and closing is one
     continuous motion instead of a glyph swap. */
  .disclosure > summary::after {
    content: ""; margin-left: auto; flex: none;
    width: 6px; height: 6px; margin-right: 2px;
    border-right: 1.5px solid var(--text-faint);
    border-bottom: 1.5px solid var(--text-faint);
    transform: translateY(-2px) rotate(45deg);
    transition: transform var(--dur-base) var(--ease-out), border-color var(--dur-fast);
  }
  .disclosure[open] > summary::after { transform: translateY(1px) rotate(-135deg); }
  .disclosure > summary:hover { background: var(--raised); }
  .disclosure > summary:hover::after { border-color: var(--text-dim); }
  .disclosure-title {
    font-size: var(--fs-xs); font-weight: 700; letter-spacing: .08em;
    text-transform: uppercase; color: var(--text-dim); flex: none;
    transition: color var(--dur-fast) var(--ease-out);
  }
  .disclosure > summary:hover .disclosure-title { color: var(--text); }
  .disclosure-summary { font-size: var(--fs-sm); color: var(--text-muted); }
  .disclosure-body { padding: var(--sp-1) var(--sp-6) var(--sp-5); }

  /* Chrome 131+ animates a <details> through ::details-content; everything
     older ignores both rules and opens instantly, which is the same behaviour
     the panel has today. Progressive, so the manifest's minimum stays put. */
  @supports (interpolate-size: allow-keywords) {
    .disclosure, .component { interpolate-size: allow-keywords; }
    .disclosure::details-content, .component::details-content {
      block-size: 0; opacity: 0; overflow: clip;
      transition: block-size var(--dur-base) var(--ease-out),
                  content-visibility var(--dur-base) allow-discrete,
                  opacity var(--dur-fast) var(--ease-out);
    }
    .disclosure[open]::details-content, .component[open]::details-content {
      block-size: auto; opacity: 1;
    }
  }

  /* stat tile --------------------------------------------------------- */
  .stat {
    display: inline-flex; flex-direction: column; gap: 2px;
    padding: var(--sp-3) var(--sp-4); border-radius: var(--radius-md);
    border: 1px solid var(--border); background: var(--raised);
    min-width: 104px;
  }
  .stat-figure { display: flex; align-items: baseline; gap: var(--sp-2); }
  .stat-value {
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-lg); font-weight: 650; line-height: 1.1; letter-spacing: -.02em;
    color: var(--text);
  }
  .stat-glyph { font-size: var(--fs-sm); }
  .stat-label {
    font-size: var(--fs-xs); letter-spacing: .04em; text-transform: uppercase;
    color: var(--text-dim);
  }
  .stat-note {
    margin: var(--sp-2) 0 0; font-size: var(--fs-sm); line-height: 1.45; color: var(--text-muted);
  }
  .stat[data-tone="favorable"] {
    border-color: var(--tone-favorable-border); background: var(--tone-favorable-surface);
  }
  .stat[data-tone="favorable"] .stat-value,
  .stat[data-tone="favorable"] .stat-glyph { color: var(--tone-favorable-text); }
  .stat[data-tone="caution"] {
    border-color: var(--tone-caution-border); background: var(--tone-caution-surface);
  }
  .stat[data-tone="caution"] .stat-value,
  .stat[data-tone="caution"] .stat-glyph { color: var(--tone-caution-text); }
  .stat[data-tone="adverse"] {
    border-color: var(--tone-adverse-border); background: var(--tone-adverse-surface);
  }
  .stat[data-tone="adverse"] .stat-value,
  .stat[data-tone="adverse"] .stat-glyph { color: var(--tone-adverse-text); }

  /* meter ------------------------------------------------------------- */
  .meter-row { margin-top: var(--sp-3); }
  .meter-row:first-child { margin-top: 0; }
  .meter-head {
    display: flex; justify-content: space-between; align-items: baseline; gap: var(--sp-4);
    font-size: var(--fs-sm); color: var(--text-muted); margin-bottom: var(--sp-1);
  }
  .meter-label { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .meter-value {
    flex: none; font-family: var(--font-num); font-variant-numeric: tabular-nums;
    color: var(--text-dim);
  }
  .meter {
    height: 6px; border-radius: var(--radius-pill); background: var(--track); overflow: hidden;
  }
  .meter > i {
    display: block; height: 100%; width: 0; border-radius: inherit;
    background: var(--tone-neutral-fill);
    transition: width var(--dur-slow) var(--ease-out);
  }
  .meter > i[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .meter > i[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .meter > i[data-tone="adverse"]   { background: var(--tone-adverse-fill); }

  /* copy button ------------------------------------------------------- */
  .copy {
    display: inline-flex; align-items: center; gap: var(--sp-1);
    font: 600 var(--fs-xs)/1 var(--font-sans);
    padding: var(--sp-1) var(--sp-3); border-radius: var(--radius-pill);
    border: 1px solid var(--border); background: var(--raised); color: var(--text-dim);
    cursor: pointer;
    transition: color var(--dur-fast) var(--ease-out),
                border-color var(--dur-fast) var(--ease-out),
                transform var(--dur-fast) var(--ease-out);
  }
  .copy:hover { color: var(--text); border-color: var(--text-faint); }
  .copy:active { transform: scale(.96); }
  .copy-glyph { font-size: var(--fs-2xs); }
  .copy[data-state="done"] {
    color: var(--tone-favorable-text); border-color: var(--tone-favorable-border);
    background: var(--tone-favorable-surface);
  }
  .copy[data-state="failed"] {
    color: var(--tone-caution-text); border-color: var(--tone-caution-border);
    background: var(--tone-caution-surface);
  }

  /* note pill ----------------------------------------------------------- */
  .note-pill {
    display: flex; align-items: flex-start; gap: var(--sp-3);
    margin-top: var(--sp-4);
    padding: var(--sp-4) var(--sp-5);
    border-radius: var(--radius-lg);
    background: var(--tone-neutral-surface);
    border: 1px solid var(--tone-neutral-border);
    color: var(--tone-neutral-on-surface);
    font-size: var(--fs-xs);
    line-height: 1.55;
  }
  .note-pill-glyph {
    flex: none; font-size: var(--fs-sm); line-height: 1.55; color: var(--tone-neutral-text);
  }
  .note-pill-body { display: flex; flex-direction: column; gap: var(--sp-2); }
  .note-pill-source { color: var(--text-faint); font-size: var(--fs-2xs); }

  /* badges and links -------------------------------------------------- */
  .ai-badge {
    display: inline-flex; align-items: center; gap: var(--sp-1); flex: none;
    font-size: var(--fs-2xs); font-weight: 700; letter-spacing: .03em;
    padding: 2px 7px; border-radius: var(--radius-pill); color: #fff;
    background: linear-gradient(135deg, #7c5cff, #4f9eff 55%, #34d8c9);
    box-shadow: 0 0 0 1px rgba(255,255,255,.14) inset;
  }
  .ai-badge-glyph { font-size: 9.5px; }

  a {
    color: var(--link); text-decoration: none; word-break: break-word;
    font-size: var(--fs-sm); font-weight: 600;
    display: inline-flex; align-items: baseline; gap: var(--sp-1);
  }
  a:hover { text-decoration: underline; }
  .link-arrow {
    font-size: .9em; transition: transform var(--dur-fast) var(--ease-out);
  }
  a:hover .link-arrow { transform: translateX(2px); }
`;function Wn(e){let{confidence:t}=e.pricing;return t==="low"||t==="none"?"unreliable":"confident"}function Xn(e){switch(e){case"high":return"favorable";case"medium":return"caution";default:return"adverse"}}var Le=["trim_disagreement","wrong_market","no_estimate","comp_count","no_mileage_adjustment","trim_unknown","widened_year_window","outlier_sensitive","weak_mileage_fit","mileage_extrapolation","wide_interval","adverse_selection","dealer_filtering_unavailable","no_recency_weighting"];function Qo(e,t){switch(e){case"trim_disagreement":return"most comparable listings look like a different trim";case"wrong_market":return"the comparable listings are not from this vehicle's area";case"no_estimate":return"there are too few comparable listings to price this at all";case"comp_count":return t.comps_included===1?"only 1 comparable listing was usable":`only ${t.comps_included} comparable listings were usable`;case"no_mileage_adjustment":return"no mileage adjustment was possible, so this is a plain median";case"trim_unknown":return"trim is unknown for most of the comparable listings";case"widened_year_window":return`the search had to widen to a ${t.year_window}-year window`;case"outlier_sensitive":return"one or two listings are holding up the whole estimate";case"weak_mileage_fit":return"mileage barely explains the spread in asking prices";case"mileage_extrapolation":return"this car's mileage sits outside the range the comps cover";case"wide_interval":return"the comparable asks are spread too widely to narrow";case"adverse_selection":return"the ask is far below the comps with nothing explaining why";case"dealer_filtering_unavailable":return"dealer listings could not be filtered out";case"no_recency_weighting":return"the comps carry no posted dates, so stale asks count fully";default:return e.replace(/_/g," ")}}function Qn(e,t=2){return[...e.confidence_limiters].sort((r,o)=>{let a=Le.indexOf(r),s=Le.indexOf(o);return(a===-1?Le.length:a)-(s===-1?Le.length:s)}).slice(0,t).map(r=>Qo(r,e))}function ct(e){return`$${Math.round(e/100).toLocaleString("en-US")}`}function Zn(e){let{asking_interval_low_cents:t,asking_interval_high_cents:n}=e,r=e.ask_cents;return t===null||n===null||r===null?null:`${e.comps_included} comparable listings suggest ${ct(t)}\u2013${ct(n)}. This asks ${ct(r)}.`}var Yn=.08;function er(e){let t=e.asking_interval_low_cents,n=e.asking_interval_high_cents;if(t===null||n===null||n<t)return null;let r=e.ask_cents,o=e.strong_offer_cents,a=e.walk_away_above_cents,s=[t,n,r,o,a].filter(m=>m!==null&&Number.isFinite(m)),l=Math.min(...s),c=Math.max(...s),u=c-l||Math.max(c*.1,1),d=l-u*Yn,f=c+u*Yn,g=m=>m===null?null:(m-d)/(f-d);return{min:d,max:f,band:{start:g(t),end:g(n)},ask:g(r),strongOffer:g(o),walkAway:g(a),askTone:Zo(r,t,n,a)}}function Zo(e,t,n,r){return e===null?"neutral":r!==null&&e>r?"adverse":e>n?"caution":e<t?"favorable":"neutral"}function tr(e,t){if(e===null||t===null)return null;let n=Math.round((e-t)/100);if(n===0)return{text:"same price",tone:"neutral"};let r=`$${Math.abs(n).toLocaleString("en-US")}`;return n<0?{text:`${r} less`,tone:"favorable"}:{text:`${r} more`,tone:"caution"}}function nr(e){let[t]=e.split(" - "),n=t?.trim();return n&&n.length>0?n:e}function Pe(e){return e==="strong"?"favorable":e==="moderate"?"caution":"neutral"}var ea=1,dt=14,pt=30,mt=75,ta=90;function rr(e){if(e===null||e<0)return null;let t=Math.max(ta,Math.ceil(e*1.15)),n=r=>Math.max(0,Math.min(1,r/t));return{days:e,position:n(e),marks:[{position:n(dt),label:`${dt}d`},{position:n(pt),label:`${pt}d`},{position:n(mt),label:`${mt}d`}],phase:na(e)}}function na(e){return e<ea?"just listed, so everyone who saw it is still looking":e<dt?"still fresh, and early interest has not passed":e<pt?"past the first rush of interest":e<mt?"sat longer than a car that is priced right usually does":"unsold for months at this price"}function or(e){let{offer:t}=e,n=t.opening_cents,r=t.target_cents;if(n===null||r===null)return null;let o=Pe(e.leverage),a=[];return n===r?a.push({label:t.stance==="pay_near_asking"?"Offer their ask":"Offer",cents:n,lead:!0,tone:o}):(a.push({label:"Open at",cents:n,lead:!0,tone:o}),a.push({label:t.stance==="pay_near_asking"?"Their ask":"Expect to pay",cents:r,lead:!1,tone:"neutral"})),t.walk_away_cents!==null&&a.push({label:"Walk away above",cents:t.walk_away_cents,lead:!1,tone:"caution"}),a}function ar(e){switch(e){case"negotiate":return{tone:"favorable",label:"room to negotiate"};case"pay_near_asking":return{tone:"caution",label:"little to argue down"};case"stretch":return{tone:"adverse",label:"asking well over the comps"};default:return null}}var Jn=["price_residual","vehicle_risk","seller_and_scam_risk","information_completeness"];function sr(e){let n=e.filter(o=>o.value!==null).reduce((o,a)=>o+a.weight,0);return e.map(o=>{let a=n>0?o.weight/n*100:0,s=o.value===null||n<=0?null:a*o.value/100;return{component:o,points:s,maxPoints:a}}).sort((o,a)=>{let s=l=>{let c=Jn.indexOf(l);return c===-1?Jn.length:c};return s(o.component.name)-s(a.component.name)})}function ir(e){return e===null?"neutral":e>=70?"favorable":e>=45?"caution":"adverse"}function ft(e){return e>=85?"excellent":e>=75?"good":e>=65?"fair":e>=55?"weak":"poor"}function gt(e){return e!==null&&!e.startsWith("deployment_")}var lr=.16;function ht(e,t,n){let r=i("div",e);return r.style.left=`${Math.max(0,Math.min(1,t))*100}%`,r.title=n,r}function ra(e,t){let n=i("div","gauge");n.setAttribute("role","img"),n.setAttribute("aria-label",`Asking ${E(t.ask_cents)} against an expected range of ${E(t.asking_interval_low_cents)} to ${E(t.asking_interval_high_cents)}.`);let r=i("div","gauge-ask-row");if(e.ask!==null){let l=i("div","gauge-ask-label");l.dataset.tone=e.askTone,l.style.left=`${e.ask*100}%`,e.ask<lr?l.dataset.align="start":e.ask>1-lr&&(l.dataset.align="end"),l.append(i("span","gauge-ask-value",E(t.ask_cents)),i("span","gauge-ask-caption","asking")),r.append(l)}let o=i("div","gauge-track"),a=i("div","gauge-band");if(a.style.left=`${e.band.start*100}%`,a.title=`Expected asking ${E(t.asking_interval_low_cents)} \u2013 ${E(t.asking_interval_high_cents)}`,ne(a,e.band.end-e.band.start),o.append(a),e.strongOffer!==null&&o.append(ht("gauge-tick",e.strongOffer,`Strong offer ${E(t.strong_offer_cents)}`)),e.walkAway!==null&&o.append(ht("gauge-tick",e.walkAway,`Walk away above ${E(t.walk_away_above_cents)}`)),e.ask!==null){let l=ht("gauge-ask",e.ask,`Asking ${E(t.ask_cents)}`);l.dataset.tone=e.askTone,o.append(l)}if(n.append(r,o),t.strong_offer_cents!==null||t.walk_away_above_cents!==null){let l=i("div","gauge-caption");t.strong_offer_cents!==null&&l.append(i("span",void 0,`Strong offer ${E(t.strong_offer_cents)}`)),t.walk_away_above_cents!==null&&l.append(i("span","gauge-caption-end",`Walk away above ${E(t.walk_away_above_cents)}`)),n.append(l)}let s=i("div","gauge-legend");return s.append(i("span","gauge-swatch"),i("span",void 0,`Expected asking ${E(t.asking_interval_low_cents)} \u2013 ${E(t.asking_interval_high_cents)}`)),n.append(s),n}function cr(e){let t=e.pricing,n=[],r=er(t);r&&n.push(ra(r,t));let o=[["Current ask",E(t.ask_cents),{big:!0}]];return!r&&t.expected_asking_cents!==null&&o.push(["Expected asking",`${E(t.asking_interval_low_cents)} \u2013 ${E(t.asking_interval_high_cents)}`]),o.push(["Confidence",t.confidence,{tone:Xn(t.confidence)}]),n.push(it(o)),n}function dr(e){let{present:t,missing:n}=e.completeness,r=[i("p","muted",n.length===0?"The seller disclosed everything this tool looks for.":`Not stated: ${n.join(", ")}.`)];return t.length&&r.push(i("p","muted",`Stated: ${t.join(", ")}.`)),r}var oa={unexplained_deep_discount:"Priced far below comparable listings with no explanation in the description.",few_or_stock_photos:"Very few photos for a vehicle at this price.",minimal_description:"Description is minimal or looks templated.",vin_omitted_from_detailed_listing:"The listing is detailed in every other respect but omits the VIN.",payment_or_meeting_red_flags:"Payment or meeting terms that legitimate private sellers rarely ask for."};function aa(e){return oa[e]??e.replace(/_/g," ")}var sa=4,ur={two:"Seller states this vehicle has had two owners.",three_plus:"Seller states this vehicle has had three or more owners."};function ia(e){let t=e.seller_risk,n=[],r=[],o=e.vehicle_details.owner_count;if(o&&ur[o]&&r.push(ur[o]),t&&r.push(...t.scam_signals_fired.map(aa)),t?.seller_rating_average!=null&&t.seller_rating_average<sa){let a=t.seller_rating_count??0;r.push(`Low seller rating: ${t.seller_rating_average.toFixed(1)}/5 from ${a} review${a===1?"":"s"} on Marketplace.`)}if(t?.scam_warning)n.push(Fn("adverse","Several scam patterns fired together",[`${t.scam_signals_fired.length} independent signals fired on this listing. Any one of them is weak. This many at once is not, and it is why no deal score is shown.`,G(r)??i("span")]));else{let a=G(r);a&&n.push(a)}return n.length===0&&n.push(i("p","muted","No red flags identified on this listing.")),n}function la(e){let t=e.vehicle_risk;if(t.recall_count===null)return[i("p","muted","No recall data available for this vehicle.")];let n=[lt(t.recall_count===1?"Open recall campaign":"Open recall campaigns",`${t.recall_count}`,t.recall_count>0?"caution":"favorable")];return t.recall_count>0&&t.recall_messages[1]&&n.push(i("p","muted",t.recall_messages[1])),n}function ua(e){let t=e.vehicle_risk;if(t.complaint_count===null)return[i("p","muted","No complaint data available for this vehicle.")];let n=[lt("Owner complaints filed",t.complaint_count.toLocaleString("en-US"))],r=t.top_complaint_components;if(r.length){let o=Math.max(...r.map(([,s])=>s),1);n.push(i("p","muted","Most complained-about systems"));let a=i("div","complaint-chart");for(let[s,l]of r)a.append(Vn(s.toLowerCase(),l.toLocaleString("en-US"),l/o));n.push(a)}return t.complaint_messages[0]&&n.push(i("p","muted",t.complaint_messages[0])),t.complaint_messages[1]&&n.push(Oe(t.complaint_messages[1],"Source: NHTSA complaints database, by year/make/model.")),n}function ca(e){let t=[],n=e.vehicle_risk,r=e.known_issues;if(r?t.push(i("p","known-summary",r.summary)):e.known_issues_unavailable_reason&&gt(e.known_issues_unavailable_code)&&t.push(i("p","muted",e.known_issues_unavailable_reason)),n.decoded_spec&&t.push(it([["VIN decode",n.decoded_spec]])),r){let o=[["Known to go wrong",r.failure_modes],["Check on the viewing",r.inspect],["Living with it",r.ownership_notes]];for(let[a,s]of o){let l=G(s);l&&t.push(i("p","muted",a),l)}}return t.length===0&&t.push(i("p","muted","No known-issue data available for this vehicle.")),t}function pr(e){return[U("Recalls","",la(e)),U("Complaints","",ua(e)),U("Known issues","",ca(e),st())]}function mr(e){let t=[U("Red flags","",ia(e))],n=da(e);return n.length&&t.push(U("Questions to ask the seller","",n,st())),t}function da(e){let t=e.known_issues;if(t){let n=G(t.ask);if(n){let r=i("div","questions-actions");return r.append(ut(t.ask.join(`
`),"Copy all")),[r,n]}return[i("p","muted","No vehicle-specific questions -- the standard checklist (title, service history, accident history) covers this one.")]}return e.known_issues_unavailable_reason&&gt(e.known_issues_unavailable_code)?[i("p","muted",e.known_issues_unavailable_reason)]:[]}function fr(e){let t=e.negotiation,n=i("span","summary-inline");n.append(B(Pe(t.leverage),`${t.leverage} leverage`));let r=[];return t.days_listed!==null&&r.push(`listed ${t.days_listed} day${t.days_listed===1?"":"s"}`),t.offer.opening_cents!==null&&r.push(`open at ${E(t.offer.opening_cents)}`),n.append(i("span","disclosure-summary",r.join(" \xB7 ")||"no posted date and no asking price")),n}function pa(e,t){let n=i("div","ladder");n.dataset.steps=`${e.length}`;let r=i("div","ladder-rail");for(let a of e){let s=i("i","ladder-dot");s.dataset.tone=a.tone,r.append(s)}let o=i("div","ladder-cells");for(let a of e){let s=i("div","ladder-cell");a.lead&&(s.dataset.lead="true"),s.dataset.tone=a.tone,s.append(i("div","ladder-label",a.label),i("div","ladder-figure",E(a.cents))),o.append(s)}return n.append(o,r),t!==null&&n.append(i("div","ladder-caption",`against the ${E(t)} asking price`)),n}function ma(e,t){let n=i("div","timeline");n.setAttribute("role","img"),n.setAttribute("aria-label",`Listed ${e.days} day${e.days===1?"":"s"} -- ${e.phase}.`);let r=i("div","timeline-head");r.append(i("span","timeline-value",`${e.days} day${e.days===1?"":"s"} listed`),i("span","timeline-phase",e.phase));let o=i("div","timeline-rail"),a=i("i","timeline-fill");a.dataset.tone=t,o.append(ne(a,e.position));for(let c of e.marks){let u=i("i","timeline-tick");u.style.left=`${c.position*100}%`,u.title=`${c.label} listed`,o.append(u)}let s=i("i","timeline-dot");s.dataset.tone=t,s.style.left=`${e.position*100}%`,o.append(s);let l=i("div","timeline-scale");for(let c of e.marks){let u=i("span","timeline-scale-label",c.label);u.style.left=`${c.position*100}%`,l.append(u)}return n.append(r,o,l),n}function fa(e){let t=i("div","draft"),n=i("div","draft-head");n.append(i("span","draft-label","Message to send"),ut(e,"Copy message"));let r=i("textarea","draft-body");return r.value=e,r.rows=Math.min(7,e.split(`
`).length+2),r.spellcheck=!1,r.setAttribute("aria-label","Draft opening message, editable before copying"),t.append(n,r),t}function gr(e){let t=e.negotiation,n=t.offer,r=[],o=Pe(t.leverage),a=ar(n.stance),s=or(t);if(a&&s){let u=i("div","offer-head");u.append(B(a.tone,a.label)),r.push(u)}s?r.push(pa(s,e.pricing.ask_cents)):n.withheld_reason&&r.push(Oe(n.withheld_reason));for(let u of n.reasoning)r.push(i("p","muted",u));let l=rr(t.days_listed);l?r.push(ma(l,o)):r.push(i("p","muted","Marketplace did not expose a posted date, so time on market is unknown."));let c=G(t.leverage_points);if(c&&(r.push(i("p","group-label","What gives you room")),r.push(c)),t.motivated_phrases.length||t.rigid_phrases.length){r.push(i("p","group-label","How the seller writes"));let u=i("div","chip-row");for(let d of t.motivated_phrases)u.append(B("favorable",d));for(let d of t.rigid_phrases)u.append(B("caution",d));r.push(u)}return t.opening_message&&r.push(fa(t.opening_message)),n.caveat&&r.push(Oe(n.caveat)),r}function hr(e){return e.alternatives.message}function vt(e,t){let n=i("div","alt"),r=i("div","alt-head");r.append(i("span","alt-vehicle",nr(e.description))),n.append(r);let o=i("div","alt-price-row");o.append(i("span","alt-price",E(e.price_cents)));let a=tr(e.price_cents,t);a&&o.append(B(a.tone,a.text)),n.append(o);let s=[];if(e.mileage!==null&&s.push(`${e.mileage.toLocaleString("en-US")} mi`),e.location_text&&s.push(e.location_text),s.length&&n.append(i("div","alt-meta",s.join(" \xB7 "))),e.mileage_tradeoff){let l=i("div","alt-reason");l.append(B("caution","higher mileage"),i("span",void 0,"for the lower price.")),n.append(l)}return e.url&&n.append(Gn(e.url)),n}function vr(e){let t=[],n=e.pricing.ask_cents;for(let o of e.alternatives.items)t.push(vt(o,n));for(let o of e.alternatives.withheld){let a=vt(o,n);a.dataset.withheld="true";let s=i("div","alt-reason");s.append(B("caution","not recommended"),i("span",void 0,o.reason));let l=a.querySelector("a");l?a.insertBefore(s,l):a.append(s),t.push(a)}let r=e.alternatives.different_trim;if(r.length>0){let o=r.length,a=`${o} different-trim listing${o===1?"":"s"}, better priced.`,s=r.map(l=>vt(l,n));t.push(U("Different trim",a,s))}return t}var br=`
  .summary-inline {
    display: inline-flex; align-items: center; gap: var(--sp-3); flex-wrap: wrap;
  }

  /* price gauge ------------------------------------------------------- */
  /* Four rows -- the ask label, the track, the two thresholds, the band's
     legend -- that used to sit almost flush against each other (an 8px and
     two 6px gaps for a section carrying five separate readings). Each gap
     below is now its own step up the scale rather than the smallest one
     repeated four times. */
  .gauge { margin: 0 0 var(--sp-6); }
  .gauge-ask-row { position: relative; height: 40px; }
  .gauge-ask-label {
    position: absolute; bottom: var(--sp-2); transform: translateX(-50%);
    display: flex; flex-direction: column; align-items: center; gap: 2px;
    white-space: nowrap; line-height: 1.15;
  }
  /* Centring a label over a marker near either end pushes half the figure out
     of the panel. At the ends it hangs inward instead. */
  .gauge-ask-label[data-align="start"] { transform: translateX(0); align-items: flex-start; }
  .gauge-ask-label[data-align="end"] { transform: translateX(-100%); align-items: flex-end; }
  .gauge-ask-value {
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-md); font-weight: 700; letter-spacing: -.01em;
  }
  .gauge-ask-caption {
    font-size: var(--fs-2xs); letter-spacing: .07em; text-transform: uppercase;
    color: var(--text-faint);
  }
  .gauge-ask-label[data-tone="favorable"] .gauge-ask-value { color: var(--tone-favorable-text); }
  .gauge-ask-label[data-tone="caution"] .gauge-ask-value   { color: var(--tone-caution-text); }
  .gauge-ask-label[data-tone="adverse"] .gauge-ask-value   { color: var(--tone-adverse-text); }
  .gauge-ask-label[data-tone="neutral"] .gauge-ask-value   { color: var(--text); }

  .gauge-track {
    position: relative; height: 11px; border-radius: var(--radius-pill);
    background: var(--track);
  }
  .gauge-band {
    position: absolute; top: 0; bottom: 0; width: 0;
    border-radius: var(--radius-pill);
    background: var(--tone-neutral-fill);
    transition: width var(--dur-slow) var(--ease-out);
  }
  /* Thresholds as hairlines through the track, recessive against the band and
     the ask marker -- they are reference lines, not data. */
  .gauge-tick {
    position: absolute; top: -3px; bottom: -3px; width: 2px;
    transform: translateX(-1px); border-radius: 1px;
    background: var(--text-faint); opacity: .75;
  }
  /* The ask overlaps the band, so it carries a ring in the panel's own surface
     colour: without it the marker and the fill merge into one shape at exactly
     the moment the reader is trying to see which side of the band it is on. */
  .gauge-ask {
    position: absolute; top: 50%; width: 14px; height: 14px;
    margin: -7px 0 0 -7px; border-radius: 50%;
    background: var(--text);
    box-shadow: 0 0 0 2.5px var(--sheet), var(--elev-1);
  }
  .gauge-ask[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .gauge-ask[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .gauge-ask[data-tone="adverse"]   { background: var(--tone-adverse-fill); }

  .gauge-caption {
    display: flex; justify-content: space-between; gap: var(--sp-4);
    margin-top: var(--sp-4);
    /* With only the walk-away figure present it still belongs on the right,
       where its tick is, rather than sliding left into the strong-offer slot. */
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-xs); color: var(--text-faint);
  }
  .gauge-caption-end { margin-left: auto; }
  .gauge-legend {
    display: flex; align-items: center; gap: var(--sp-2); margin-top: var(--sp-4);
    font-size: var(--fs-xs); color: var(--text-dim);
    font-variant-numeric: tabular-nums;
  }
  .gauge-swatch {
    width: 14px; height: 6px; border-radius: var(--radius-pill); flex: none;
    background: var(--tone-neutral-fill);
  }

  /* complaints -------------------------------------------------------- */
  .complaint-chart { margin-top: var(--sp-3); }
  .complaint-chart .meter-label { text-transform: capitalize; }

  /* negotiation ------------------------------------------------------- */
  .offer-head { display: flex; align-items: center; gap: var(--sp-3); margin-bottom: var(--sp-4); }

  /* The offer ladder. A grid rather than flex so the rail's dots line up under
     the middle of their own cells at any number of steps -- both rows share one
     column definition. */
  .ladder {
    margin: 0 0 var(--sp-5); padding: var(--sp-4) var(--sp-5) var(--sp-5);
    border: 1px solid var(--border); border-radius: var(--radius-md);
    background: var(--raised);
  }
  .ladder-cells, .ladder-rail { display: grid; grid-auto-flow: column; grid-auto-columns: 1fr; }
  .ladder-cell { min-width: 0; }
  /* Every step after the first reads right-of-centre, so the last one hugs the
     edge and the progression runs left to right rather than sitting in a block. */
  .ladder-cell + .ladder-cell { text-align: right; }
  .ladder[data-steps="3"] .ladder-cell:nth-child(2) { text-align: center; }
  .ladder-label {
    font-size: var(--fs-2xs); font-weight: 700; letter-spacing: .07em;
    text-transform: uppercase; color: var(--text-dim);
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  .ladder-figure {
    margin-top: 3px;
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-md); font-weight: 650; letter-spacing: -.01em; color: var(--text-muted);
  }
  /* The lead step is the only figure the buyer says out loud. */
  .ladder-cell[data-lead="true"] .ladder-figure {
    font-size: var(--fs-xl); font-weight: 700; letter-spacing: -.02em; color: var(--text);
  }
  .ladder-cell[data-lead="true"][data-tone="favorable"] .ladder-figure {
    color: var(--tone-favorable-text);
  }
  .ladder-cell[data-lead="true"][data-tone="caution"] .ladder-figure {
    color: var(--tone-caution-text);
  }
  .ladder-cell[data-lead="true"][data-tone="adverse"] .ladder-figure {
    color: var(--tone-adverse-text);
  }

  /* The rail: a hairline through dots that sit under their own cells. */
  .ladder-rail {
    position: relative; margin-top: var(--sp-4); align-items: center; height: 9px;
  }
  .ladder-rail::before {
    content: ""; position: absolute; left: 4px; right: 4px; top: 50%; height: 1px;
    background: var(--border); transform: translateY(-.5px);
  }
  .ladder-dot {
    position: relative; justify-self: start;
    width: 9px; height: 9px; border-radius: 50%;
    background: var(--track); box-shadow: 0 0 0 2px var(--raised);
  }
  .ladder-rail > .ladder-dot:not(:first-child) { justify-self: end; }
  .ladder[data-steps="3"] .ladder-rail > .ladder-dot:nth-child(2) { justify-self: center; }
  .ladder-dot[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .ladder-dot[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .ladder-dot[data-tone="adverse"]   { background: var(--tone-adverse-fill); }
  .ladder-caption {
    margin-top: var(--sp-3); font-size: var(--fs-xs); color: var(--text-faint);
    font-variant-numeric: tabular-nums;
  }

  /* time on market ---------------------------------------------------- */
  .timeline { margin-top: var(--sp-5); }
  .timeline-head {
    display: flex; align-items: baseline; gap: var(--sp-3); flex-wrap: wrap;
    margin-bottom: var(--sp-3);
  }
  .timeline-value {
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-base); font-weight: 650; color: var(--text);
  }
  .timeline-phase { font-size: var(--fs-sm); color: var(--text-dim); }
  .timeline-rail {
    position: relative; height: 6px; border-radius: var(--radius-pill);
    background: var(--track);
  }
  .timeline-fill {
    display: block; height: 100%; width: 0; border-radius: inherit;
    background: var(--tone-neutral-fill);
    transition: width var(--dur-slow) var(--ease-out);
  }
  .timeline-fill[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .timeline-fill[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .timeline-fill[data-tone="adverse"]   { background: var(--tone-adverse-fill); }
  /* The thresholds are reference lines, not data, so they stay recessive and sit
     over the fill rather than interrupting it. */
  .timeline-tick {
    position: absolute; top: -2px; bottom: -2px; width: 1px;
    transform: translateX(-.5px);
    background: var(--text-faint); opacity: .55;
  }
  .timeline-dot {
    position: absolute; top: 50%; width: 11px; height: 11px;
    margin: -5.5px 0 0 -5.5px; border-radius: 50%;
    background: var(--text); box-shadow: 0 0 0 2px var(--sheet), var(--elev-1);
  }
  .timeline-dot[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .timeline-dot[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .timeline-dot[data-tone="adverse"]   { background: var(--tone-adverse-fill); }
  .timeline-scale {
    position: relative; height: 14px; margin-top: var(--sp-2);
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-2xs); color: var(--text-faint);
  }
  .timeline-scale-label { position: absolute; transform: translateX(-50%); }

  /* shared small pieces ----------------------------------------------- */
  .group-label {
    margin: var(--sp-5) 0 0; font-size: var(--fs-2xs); font-weight: 700;
    letter-spacing: .07em; text-transform: uppercase; color: var(--text-dim);
  }
  .chip-row {
    display: flex; flex-wrap: wrap; gap: var(--sp-2); margin-top: var(--sp-3);
  }

  /* the drafted message ----------------------------------------------- */
  .draft {
    margin-top: var(--sp-5); padding: var(--sp-4);
    border: 1px solid var(--border); border-radius: var(--radius-md);
    background: var(--raised);
  }
  .draft-head {
    display: flex; align-items: center; justify-content: space-between; gap: var(--sp-4);
    margin-bottom: var(--sp-3);
  }
  .draft-label {
    font-size: var(--fs-2xs); font-weight: 700; letter-spacing: .07em;
    text-transform: uppercase; color: var(--text-dim);
  }
  /* A textarea, because a message nobody can edit before sending is a message
     nobody sends. Inherits the panel's type so it does not read as a form field
     dropped into a report. */
  .draft-body {
    display: block; width: 100%; box-sizing: border-box; resize: vertical;
    padding: var(--sp-3); border: 1px solid var(--border-faint);
    border-radius: var(--radius-sm); background: var(--sheet); color: var(--text-muted);
    font: 400 var(--fs-sm)/1.55 var(--font-sans);
  }
  .draft-body:focus-visible { outline: 2px solid var(--link); outline-offset: 1px; }

  .questions-actions { display: flex; justify-content: flex-end; margin-bottom: var(--sp-1); }

  /* alternatives ------------------------------------------------------ */
  .alt {
    padding: var(--sp-4) 0; border-top: 1px solid var(--border-faint);
    font-size: var(--fs-sm); line-height: 1.5;
  }
  .alt:first-child { border-top: 0; padding-top: var(--sp-1); }
  .alt[data-withheld="true"] { opacity: .82; }
  .alt-head { display: flex; align-items: baseline; gap: var(--sp-3); }
  .alt-vehicle { font-weight: 650; color: var(--text); font-size: var(--fs-base); }
  .alt-price-row {
    display: flex; align-items: center; gap: var(--sp-3); flex-wrap: wrap;
    margin-top: var(--sp-2);
  }
  .alt-price {
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-md); font-weight: 650; color: var(--text);
  }
  .alt-meta {
    margin-top: 3px; color: var(--text-dim); font-variant-numeric: tabular-nums;
  }
  .alt-reason {
    display: flex; gap: var(--sp-3); align-items: baseline; margin-top: var(--sp-2);
    font-size: var(--fs-sm); color: var(--text-dim);
  }
  .alt a { margin-top: var(--sp-2); }

  .known-summary {
    margin: 0 0 var(--sp-2); font-size: var(--fs-base); line-height: 1.55; color: var(--text-muted);
  }
`;function ga(e){return e.replace(/_/g," ")}function ha(e,t){switch(e){case"price_residual":return cr(t);case"information_completeness":return dr(t);case"vehicle_risk":return pr(t);case"seller_and_scam_risk":return mr(t);default:return[]}}function va(e,t,n){return`${Math.round(e)}/100 \xD7 ${Math.round(t)}% = ${n.toFixed(1)} pts`}function ba(e,t,n,r,o){let a=ir(t.value),s=i("details",`component${n===null?" missing":""}`);n!==null&&(s.dataset.tone=a);let l=i("summary","component-summary"),c=ha(t.name,e),u=i("div","component-top"),d=i("span","component-name");if(n!==null&&d.append(i("span","component-glyph",N[a])),d.append(i("span",void 0,ga(t.name))),u.append(d),u.append(i("span","component-figures",n===null?"not assessed":va(t.value??0,r,n))),l.append(u),n!==null){let g=i("div","bar");g.style.width=`${r/o*100}%`;let m=i("i");m.dataset.tone=a,g.append(ne(m,(t.value??0)/100)),l.append(g)}s.append(l);let f=i("div","component-body");return n===null&&t.unavailable_reason&&f.append(i("p","component-reason",t.unavailable_reason)),f.append(...c),s.append(f),s}function xr(e){let t=sr(e.deal_score.components),n=[],r=Math.max(...t.map(s=>s.maxPoints),1);for(let{component:s,points:l,maxPoints:c}of t)n.push(ba(e,s,l,c,r));t.filter(s=>s.points===null).length&&n.push(i("p","muted","Dimensions that could not be assessed are dropped rather than scored as zero, and the remaining weights are shared out over what is left."));let a=G(e.pricing.fallback_reasons,"muted-list");return a&&n.push(a),n}var yr=`
  .component {
    position: relative; border-bottom: 1px solid var(--border-faint);
    font-size: var(--fs-sm);
  }
  .component:last-child { border-bottom: 0; }
  /* A tone rail on the left edge, drawn only while the row is open. Closed,
     the bar is already the colour carrier; open, the row's content runs for
     half a screen and the rail is what still connects it to its dimension. */
  .component::before {
    content: ""; position: absolute; left: calc(var(--sp-4) * -1); top: 0; bottom: 0;
    width: 2px; border-radius: var(--radius-pill); background: transparent;
    transition: background var(--dur-base) var(--ease-out);
  }
  .component[open][data-tone="favorable"]::before { background: var(--tone-favorable-fill); }
  .component[open][data-tone="caution"]::before   { background: var(--tone-caution-fill); }
  .component[open][data-tone="adverse"]::before   { background: var(--tone-adverse-fill); }
  .component[open][data-tone="neutral"]::before   { background: var(--border); }

  .component-summary {
    display: block; cursor: pointer; list-style: none; position: relative;
    padding: var(--sp-3) var(--sp-5) var(--sp-3) 0;
    border-radius: var(--radius-sm);
    transition: background var(--dur-fast) var(--ease-out);
  }
  .component-summary::-webkit-details-marker { display: none; }
  .component-summary::after {
    content: ""; position: absolute; right: 2px; top: 14px;
    width: 6px; height: 6px;
    border-right: 1.5px solid var(--text-faint);
    border-bottom: 1.5px solid var(--text-faint);
    transform: rotate(45deg);
    transition: transform var(--dur-base) var(--ease-out), border-color var(--dur-fast);
  }
  .component[open] > .component-summary::after { transform: translateY(3px) rotate(-135deg); }
  .component-summary:hover .component-name { color: var(--text); }
  .component-summary:hover::after { border-color: var(--text-dim); }

  .component-top {
    display: flex; justify-content: space-between; gap: var(--sp-4);
    color: var(--text-muted); align-items: baseline;
  }
  .component-name {
    display: inline-flex; align-items: baseline; gap: var(--sp-2);
    text-transform: capitalize; font-weight: 600;
    transition: color var(--dur-fast) var(--ease-out);
  }
  .component-glyph { font-size: var(--fs-xs); }
  .component[data-tone="favorable"] .component-glyph { color: var(--tone-favorable-text); }
  .component[data-tone="caution"] .component-glyph   { color: var(--tone-caution-text); }
  .component[data-tone="adverse"] .component-glyph   { color: var(--tone-adverse-text); }
  .component[data-tone="neutral"] .component-glyph   { color: var(--text-faint); }

  .component-figures {
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    color: var(--text-dim); flex: none; font-size: var(--fs-xs);
  }
  .component.missing .component-top { color: var(--text-faint); font-style: italic; }
  .component-reason {
    margin: 3px 0 0; font-size: var(--fs-xs); line-height: 1.45; color: var(--text-faint);
  }

  .bar {
    height: 7px; border-radius: var(--radius-pill); background: var(--track);
    margin-top: var(--sp-2); overflow: hidden; min-width: 8%;
  }
  .bar > i {
    display: block; height: 100%; width: 0; border-radius: inherit;
    background: var(--tone-neutral-fill);
    transition: width var(--dur-slow) var(--ease-out);
  }
  .bar > i[data-tone="favorable"] { background: var(--tone-favorable-fill); }
  .bar > i[data-tone="caution"]   { background: var(--tone-caution-fill); }
  .bar > i[data-tone="adverse"]   { background: var(--tone-adverse-fill); }
  /* Staggered so the four dimensions read as one chart arriving rather than
     four independent bars. Nth-of-type, not a class, because the row order is
     fixed by DIMENSION_ORDER in state.ts and cannot drift. */
  .component:nth-of-type(2) .bar > i { transition-delay: 60ms; }
  .component:nth-of-type(3) .bar > i { transition-delay: 120ms; }
  .component:nth-of-type(4) .bar > i { transition-delay: 180ms; }

  .component-body { padding: 0 0 var(--sp-4); }

  /* Vehicle risk / seller and scam risk's own nested dropdowns (Recalls,
     Complaints, Known issues, Red flags, Questions). Indented from "Vehicle
     risk" / "Seller and scam risk" itself, with their own content indented a
     second step further from THEIR header -- two levels, not one. Overrides
     the shared .disclosure spacing, which is sized for a full-width top-level
     row rather than a nested one. */
  .component-body > .disclosure { border-bottom: 1px solid var(--border-faint); }
  .component-body > .disclosure:last-child { border-bottom: 0; }
  .component-body > .disclosure:first-of-type { margin-top: var(--sp-1); }
  .component-body > .disclosure > summary {
    padding: var(--sp-3) 0 var(--sp-3) var(--sp-4); border-radius: var(--radius-sm);
  }
  .component-body > .disclosure > .disclosure-body {
    padding: var(--sp-1) 0 var(--sp-4) var(--sp-7);
  }

  .breakdown-note {
    margin: 0 0 var(--sp-4); font-size: var(--fs-sm); line-height: 1.5; color: var(--text-muted);
  }
  .muted-list { color: var(--text-faint); font-size: var(--fs-xs); margin-top: var(--sp-4); }

  /* expand-all, pinned to the Score breakdown heading */
  .toggle-all {
    margin-left: auto; flex: none;
    font: 650 var(--fs-xs)/1 var(--font-sans); letter-spacing: .04em; text-transform: uppercase;
    background: none; border: 1px solid var(--border); border-radius: var(--radius-pill);
    color: var(--text-dim); padding: var(--sp-1) var(--sp-3); cursor: pointer;
    transition: color var(--dur-fast) var(--ease-out),
                border-color var(--dur-fast) var(--ease-out);
  }
  .toggle-all:hover { color: var(--text); border-color: var(--text-faint); }
`;function bt(){let e=i("span","beta","BETA");return e.title="Uncalibrated: the weights have not been checked against hand-evaluated listings.",e}function xa(e){return null}function ya(e){return e==="disqualifying"||e==="branded"?"adverse":e==="unstated"?"caution":"favorable"}function _r(e){let t=e.vehicle_risk,n=e.vehicle_details.title_status?`Title: ${e.vehicle_details.title_status}`:"Title status not stated",r=i("div","title-status");return r.append(B(ya(t.title_risk),n)),r.append(i("p","title-status-message",t.title_message)),r}function _a(e,t){if(Bn()||typeof requestAnimationFrame!="function")return;let n=620,r=null,o=a=>{r===null&&(r=a);let s=Math.min(1,(a-r)/n),l=1-Math.pow(1-s,3);e.textContent=`${Math.round(t*l)}`,s<1&&requestAnimationFrame(o)};requestAnimationFrame(()=>{e.textContent="0",requestAnimationFrame(o)})}function wa(e,t){let n=ft(e),r=Math.round(e),o=i("div","score-wrap"),a=i("div","score-ring");a.dataset.grade=n,a.style.setProperty("--dr-dial",`${Math.max(0,Math.min(100,r))}%`);let s=i("div","score",`${r}`);s.dataset.grade=n,_a(s,r),o.append(a,s);let l=i("div","score-side");l.append(i("span","score-of","out of 100")),t&&l.append(bt());let c=i("div","score-row");return c.append(o,l),c}function ka(e){let{score:t,suppressed_reason:n,beta:r}=e.deal_score,o;t===null?(o=i("div","score-row"),o.append(i("div","score-withheld","Score withheld")),r&&o.append(bt())):o=wa(t,r);let a=n??Zn(e.pricing)??e.headline;return[o,i("p","headline",a),_r(e)]}function Ea(e){let t=[],{score:n,suppressed_reason:r,beta:o}=e.deal_score;t.push(i("p","verdict","This vehicle cannot be priced confidently.")),t.push(_r(e));let a=Qn(e.pricing,2);if(a.length){let s=i("ul","problems");for(let l of a){let c=i("li");c.append(i("span","problem-glyph",N.caution),i("span",void 0,l)),s.append(c)}t.push(s)}if(o){let s=i("div","meta-row");s.append(bt()),t.push(s)}if(r!==null)t.push(i("p","headline",r));else if(n!==null){let s=i("details","score-reveal"),l=i("summary",void 0,"Show the score anyway"),c=i("p","score-secondary");c.append(i("strong",void 0,`${Math.round(n)} / 100`),i("span",void 0," \u2014 a summary of dimensions that rest on the comp set above. It is no more reliable than the comps are.")),s.append(l,c),t.push(s)}return t}function wr(e,t,n){let r=Wn(e),o=i("header");o.dataset.state=r,r==="confident"&&e.deal_score.score!==null&&(o.dataset.grade=ft(e.deal_score.score));let a=i("button","close");a.type="button",a.setAttribute("aria-label","Close evaluation"),a.append(i("span","close-glyph","\xD7")),a.addEventListener("click",t);let s=i("div","header-actions"),l=xa(e);l&&s.append(l),n&&s.append(n),s.append(a);let c=i("div","header-top");return c.append(i("div","vehicle",e.vehicle),s),o.append(c),o.append(...r==="confident"?ka(e):Ea(e)),o}var kr=`
  /* The dial's sweep is a registered property so it can be transitioned --
     a plain custom property in a conic-gradient jumps. Namespaced because
     @property registers document-wide, and this stylesheet is injected into
     somebody else's page. */
  @property --dr-dial {
    syntax: "<percentage>";
    inherits: false;
    initial-value: 0%;
  }

  header {
    position: sticky; top: 0; z-index: 1;
    background: var(--sheet);
    padding: var(--sp-6) var(--sp-6) var(--sp-5);
    border-bottom: 1px solid var(--border);
  }
  /* A few percent of the grade colour, mixed into the sheet rather than laid
     over it, so the header is still the sheet in both themes. */
  header[data-grade="poor"]      { background: color-mix(in srgb, var(--grade-poor-text) 7%, var(--sheet)); }
  header[data-grade="weak"]      { background: color-mix(in srgb, var(--grade-weak-text) 7%, var(--sheet)); }
  header[data-grade="fair"]      { background: color-mix(in srgb, var(--grade-fair-text) 7%, var(--sheet)); }
  header[data-grade="good"]      { background: color-mix(in srgb, var(--grade-good-text) 7%, var(--sheet)); }
  header[data-grade="excellent"] { background: color-mix(in srgb, var(--grade-excellent-text) 9%, var(--sheet)); }
  header[data-state="unreliable"] {
    border-bottom-color: var(--tone-caution-border);
    box-shadow: inset 3px 0 0 var(--tone-caution-fill);
    background: color-mix(in srgb, var(--tone-caution-fill) 6%, var(--sheet));
  }

  /* The row the vehicle line and the controls share. Flex rather than the
     vehicle text reserving a fixed width for whatever the actions happen to
     add up to (a seller-type badge, a theme toggle, close): the actions take
     only the width they need and the vehicle text shrinks and wraps around
     them instead of running underneath. */
  .header-top {
    display: flex; align-items: flex-start; justify-content: space-between;
    gap: var(--sp-4);
  }
  .header-actions {
    display: flex; align-items: center; gap: var(--sp-2); flex: none;
    /* Nudged up to sit level with the vehicle text's cap-height rather than
       its line box. */
    margin-top: -2px;
  }
  .close, .theme-toggle {
    display: grid; place-items: center; flex: none;
    width: 28px; height: 28px; padding: 0;
    background: none; border: 1px solid transparent; border-radius: var(--radius-pill);
    color: var(--text-dim); cursor: pointer; font: inherit; line-height: 1;
    transition: color var(--dur-fast) var(--ease-out),
                background var(--dur-fast) var(--ease-out),
                border-color var(--dur-fast) var(--ease-out);
  }
  .close:hover, .theme-toggle:hover {
    color: var(--text); background: var(--raised); border-color: var(--border);
  }
  .close-glyph { font-size: var(--fs-lg); }
  .theme-toggle { font-size: var(--fs-base); }

  .seller-type-badge {
    font-size: var(--fs-2xs); font-weight: 700; letter-spacing: .04em;
    padding: 3px var(--sp-3); border-radius: var(--radius-pill);
    border: 1px solid currentColor; cursor: default; white-space: nowrap;
    flex: none;
  }
  .seller-type-badge[data-type="private_party"] { color: var(--tone-favorable-text); }
  .seller-type-badge[data-type="dealer"] { color: var(--tone-caution-text); }

  .vehicle {
    font-size: var(--fs-sm); color: var(--text-dim);
    letter-spacing: .05em; text-transform: uppercase; font-weight: 600;
    min-width: 0; flex: 1 1 auto;
    /* Long year/make/model/trim combinations wrap onto a second line rather
       than truncating -- this is the one place in the panel that states what
       the car actually is, so losing the end of it silently is worse than a
       taller header. */
    overflow-wrap: break-word;
    padding-top: 2px;
  }

  /* confident --------------------------------------------------------- */
  .score-row {
    display: flex; align-items: center; flex-wrap: wrap;
    gap: var(--sp-4); margin-top: var(--sp-4);
  }
  .score-wrap { position: relative; display: grid; place-items: center; flex: none; }
  .score-ring {
    grid-area: 1 / 1; width: 88px; height: 88px; border-radius: 50%;
    background: conic-gradient(from -90deg, var(--dial) var(--dr-dial), var(--track) 0);
    /* Masked to a ring rather than filled and covered, so the header's grade
       tint shows through the middle instead of a disc of flat --sheet. */
    -webkit-mask: radial-gradient(farthest-side, #0000 calc(100% - 5px), #000 calc(100% - 4px));
            mask: radial-gradient(farthest-side, #0000 calc(100% - 5px), #000 calc(100% - 4px));
    transition: --dr-dial var(--dur-slow) var(--ease-out);
  }
  .score-ring[data-grade="poor"]      { --dial: var(--grade-poor-text); }
  .score-ring[data-grade="weak"]      { --dial: var(--grade-weak-text); }
  .score-ring[data-grade="fair"]      { --dial: var(--grade-fair-text); }
  .score-ring[data-grade="good"]      { --dial: var(--grade-good-text); }
  .score-ring[data-grade="excellent"] { --dial: var(--grade-excellent-text); }

  .score {
    grid-area: 1 / 1;
    font-family: var(--font-num); font-variant-numeric: tabular-nums;
    font-size: var(--fs-d3); font-weight: 700; line-height: 1; letter-spacing: -.03em;
    color: var(--text);
  }
  /* Grade is a five-way read of the same 0-100 the rest of the panel keeps to
     three tones (Tone) -- justified here because this is the one number
     shown once, in isolation, at the size that draws the eye first. */
  .score[data-grade="poor"]      { color: var(--grade-poor-text);      font-size: var(--grade-poor-size); }
  .score[data-grade="weak"]      { color: var(--grade-weak-text);      font-size: var(--grade-weak-size); }
  .score[data-grade="fair"]      { color: var(--grade-fair-text);      font-size: var(--grade-fair-size); }
  .score[data-grade="good"]      { color: var(--grade-good-text);      font-size: var(--grade-good-size); }
  .score[data-grade="excellent"] { color: var(--grade-excellent-text); font-size: var(--grade-excellent-size); }

  .score-side { display: flex; flex-direction: column; align-items: flex-start; gap: var(--sp-2); }
  .score-of {
    font-size: var(--fs-xs); letter-spacing: .06em; text-transform: uppercase;
    color: var(--text-faint);
  }
  .score-withheld {
    font-size: var(--fs-md); font-weight: 650; color: var(--tone-caution-text);
  }
  .headline {
    margin: var(--sp-4) 0 0; font-size: var(--fs-base); line-height: 1.55; color: var(--text-muted);
  }

  /* title status, shared by both header states ------------------------ */
  .title-status { margin-top: var(--sp-4); }
  .title-status-message {
    margin: var(--sp-2) 0 0; font-size: var(--fs-sm); line-height: 1.45; color: var(--text-muted);
  }

  /* unreliable -------------------------------------------------------- */
  .verdict {
    margin: var(--sp-4) 0 0;
    font-size: var(--fs-lg); font-weight: 650; line-height: 1.25; letter-spacing: -.015em;
    color: var(--text); text-wrap: balance;
  }
  .problems { list-style: none; margin: var(--sp-4) 0 0; padding: 0; }
  .problems li {
    display: flex; gap: var(--sp-3); align-items: baseline;
    font-size: var(--fs-base); line-height: 1.45; color: var(--text-muted);
    margin-bottom: var(--sp-1);
  }
  .problem-glyph { color: var(--tone-caution-text); flex: none; }
  .meta-row {
    display: flex; align-items: center; flex-wrap: wrap; gap: var(--sp-3); margin-top: var(--sp-4);
  }

  .score-reveal { margin-top: var(--sp-4); }
  .score-reveal summary {
    font-size: var(--fs-sm); color: var(--text-dim); cursor: pointer;
    padding: 3px 0; border-radius: var(--radius-sm); width: fit-content;
    transition: color var(--dur-fast) var(--ease-out);
  }
  .score-reveal summary:hover { color: var(--text); }
  .score-secondary {
    margin: var(--sp-2) 0 0; font-size: var(--fs-sm); line-height: 1.5; color: var(--text-muted);
  }
  .score-secondary strong { color: var(--text); font-size: var(--fs-md); }

  /* chips and badges -------------------------------------------------- */
  .chip {
    display: inline-flex; align-items: center; gap: var(--sp-1);
    font-size: var(--fs-xs); font-weight: 650;
    padding: 3px var(--sp-3); border-radius: var(--radius-pill);
    border: 1px solid currentColor;
  }
  .chip-glyph { font-size: var(--fs-xs); }
  .chip[data-tone="favorable"] { color: var(--tone-favorable-text); }
  .chip[data-tone="caution"]   { color: var(--tone-caution-text); }
  .chip[data-tone="adverse"]   { color: var(--tone-adverse-text); }
  .chip[data-tone="neutral"]   { color: var(--text-dim); }
  .beta {
    font-size: var(--fs-2xs); font-weight: 700; letter-spacing: .08em;
    background: var(--beta); color: var(--beta-on);
    padding: 3px var(--sp-2); border-radius: var(--radius-sm);
  }
`;var Ta=`
  :host { all: initial; }

  .backdrop {
    position: fixed; inset: 0; z-index: 2147483646;
    background: var(--scrim);
    display: flex; justify-content: flex-end;
    font-family: var(--font-sans);
    -webkit-font-smoothing: antialiased;
    opacity: 0;
    transition: opacity var(--dur-base) var(--ease-out);
  }
  .sheet {
    width: min(444px, 100vw);
    height: 100%;
    overflow-y: auto;
    overscroll-behavior: contain;
    background: var(--sheet);
    color: var(--text);
    box-shadow: var(--elev-3);
    transform: translateX(20px);
    transition: transform var(--dur-slow) var(--ease-out);
  }

  /* Entry and exit are the same two properties in opposite directions. The
     class is added a frame after mount and removed on close (see index.ts),
     which is what lets the panel animate OUT as well -- an overlay that snaps
     out of existence reads as a crash rather than a dismissal. */
  .backdrop[data-open="true"] { opacity: 1; }
  .backdrop[data-open="true"] .sheet { transform: translateX(0); }

  .sheet::-webkit-scrollbar { width: 10px; }
  .sheet::-webkit-scrollbar-track { background: transparent; }
  .sheet::-webkit-scrollbar-thumb {
    background: var(--border); border-radius: var(--radius-pill);
    border: 3px solid var(--sheet);
  }
  .sheet::-webkit-scrollbar-thumb:hover { background: var(--text-faint); }

  /* One visible focus ring for every interactive element in the panel. The
     panel is an overlay on somebody else's page; a keyboard user who cannot
     see where they are has no way back out to the close button. */
  :where(button, summary, a, [tabindex]):focus-visible {
    outline: 2px solid var(--focus);
    outline-offset: 2px;
    border-radius: var(--radius-sm);
  }

  /* Nothing in this panel animates for effect, but the entry transition,
     the growing bars and the disclosure rows are all motion. Honour the system
     preference rather than assuming a 200ms fade is beneath notice. The JS
     animations check the same query and jump to their final value. */
  @media (prefers-reduced-motion: reduce) {
    * {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
      scroll-behavior: auto !important;
    }
  }
`,Sa=`
  .notices {
    padding: var(--sp-5) var(--sp-6) var(--sp-7);
    background: var(--raised);
    border-top: 1px solid var(--border-faint);
  }
  .notices p {
    margin: 0 0 var(--sp-3); font-size: var(--fs-xs); line-height: 1.55;
    color: var(--text-faint);
  }
  .notices p:last-child { margin-bottom: 0; }
  .notices strong { color: var(--text-dim); font-weight: 700; }
`;function Er(e=":host"){return`
${Ce(e)}
${Ta}
${Kn}
${kr}
${yr}
${br}
${Sa}
`}var Ne=["auto","light","dark"];function Tr(e){return typeof e=="string"&&Ne.includes(e)}function Sr(e,t){return e==="auto"?t?"dark":"light":e}function Mr(e){return e==="auto"?null:e}function xt(e){let t=Ne.indexOf(e);return Ne[(t+1)%Ne.length]}function Ar(e,t){let n=e==="auto"?"\u25D0":t==="dark"?"\u263E":"\u2600",r=e==="auto"?`following your system (${t})`:`${e} theme`;return{glyph:n,label:`Theme: ${r}. Switch to ${xt(e)}.`}}function Rr(){return typeof matchMedia=="function"&&matchMedia("(prefers-color-scheme: dark)").matches}var Cr="deal-rater-overlay",Ma="deal-rater-trigger",Aa='button, a[href], summary, input, select, textarea, [tabindex]:not([tabindex="-1"])';function Ra(e){let t=i("div","notices"),n=i("p");n.append(i("strong",void 0,"Beta signal, not a rating. "),i("span",void 0,"The weights and the discount curve are starting hypotheses that have not been checked against hand-evaluated listings yet. This is an informational analysis of one listing, not a purchase recommendation, and never a substitute for a pre-purchase inspection or a vehicle history report.")),t.append(n);let r=/beta signal|informational analysis/i;for(let o of e.notices)r.test(o)||t.append(i("p",void 0,o));return t}function Ca(e){let t=i("button","theme-toggle");t.type="button";let n="auto",r=()=>{let o=Sr(n,Rr()),a=Mr(n);a?e.dataset.theme=a:delete e.dataset.theme;let{glyph:s,label:l}=Ar(n,o);t.textContent=s,t.title=l,t.setAttribute("aria-label",l)};return r(),ee().then(o=>{Tr(o.theme)&&(n=o.theme,r())}).catch(()=>{}),t.addEventListener("click",()=>{n=xt(n),r(),_n({theme:n}).catch(()=>{})}),t}function Oa(e){let t=i("button","toggle-all","Expand all");t.type="button";let n=()=>Array.from(e.querySelectorAll("details")),r=()=>{t.textContent=n().some(o=>o.open)?"Collapse all":"Expand all"};return t.addEventListener("click",()=>{let o=!n().some(a=>a.open);for(let a of n())a.open=o;r()}),e.addEventListener("toggle",r,!0),t}function Or(e){document.getElementById(Cr)?.remove();let t=i("div");t.id=Cr;let n=t.attachShadow({mode:"open"}),r=document.createElement("style");r.textContent=Er();let o=i("div","backdrop"),a=i("div","sheet");a.setAttribute("role","dialog"),a.setAttribute("aria-modal","true"),a.setAttribute("aria-label",`Deal evaluation for ${e.vehicle}`);let s=!1,l=()=>{if(s)return;s=!0,window.removeEventListener("keydown",c,!0),o.dataset.open="false";let u=()=>{t.remove(),document.getElementById(Ma)?.shadowRoot?.querySelector("button")?.focus()},d=setTimeout(u,400);o.addEventListener("transitionend",f=>{f.target!==o||f.propertyName!=="opacity"||(clearTimeout(d),u())})};function c(u){if(u.key==="Escape"){u.preventDefault(),u.stopPropagation(),l();return}if(u.key!=="Tab")return;let d=Array.from(a.querySelectorAll(Aa)).filter(h=>!h.disabled&&h.offsetParent!==null);if(d.length===0)return;let f=d[0],g=d[d.length-1],m=n.activeElement;u.shiftKey&&(m===f||m===null)?(u.preventDefault(),g.focus()):!u.shiftKey&&m===g&&(u.preventDefault(),f.focus())}o.addEventListener("click",u=>{u.target===o&&l()}),window.addEventListener("keydown",c,!0),a.append(wr(e,l,Ca(t))),a.append(qn("Score breakdown",xr(e),void 0,Oa(a))),a.append(U("Negotiation",fr(e),gr(e))),a.append(U("Alternatives",hr(e),vr(e))),a.append(Ra(e)),o.append(a),n.append(r,o),document.body.append(t),typeof requestAnimationFrame=="function"?requestAnimationFrame(()=>{o.dataset.open="true"}):o.dataset.open="true",Un(a),n.querySelector("button.close")?.focus()}var La="chrome-extension",Pa="0.1.0";function Na(e){return{client:{name:La,version:Pa},capture:{client_capture_id:e.captureId,captured_at:e.capturedAt.toISOString(),comp_search_query:e.compSearchQuery},target:e.target,comps:e.comps,extraction_report:ie(e.issues)}}async function Lr(e=()=>{}){let t=new Date;e("Reading listing\u2026","reading");let n=await le(document,location.href,t);if(n.usable&&!n.payloadMatched){e("Loading listing data\u2026","reading");let P=n.observation.listing_url??location.href,oe=await at(P);if(oe){let w=await le(oe,P,t);w.payloadMatched&&(n=w)}if(!n.payloadMatched){e("Reloading listing\u2026","reading");let w=await te({type:"HARVEST_TARGET_VIA_TAB",url:P});w?.ok&&w.payloadMatched&&(n={observation:w.observation,issues:w.issues,pageSignature:w.pageSignature,usable:w.usable,locationId:w.locationId,searchRadiusKm:w.searchRadiusKm,payloadMatched:w.payloadMatched})}}if(!n.usable)return{ok:!1,message:"Could not identify this listing.",compCount:0,extractionOk:!1};let{make:r,model:o,year:a,price_cents:s}=n.observation;if(r===null&&o===null&&s===null)return{ok:!1,message:"This listing is still loading.",compCount:0,extractionOk:!1};if(r===null&&o===null&&a===null)return{ok:!1,message:"This does not look like a vehicle listing. Nothing was saved.",compCount:0,extractionOk:!1};let l=[...n.issues],c=await ee(),u=[],d=[],f=null,g=null,m=0,h=0,S=null,b=null,T=null,I=null,$=0,H=0,O=Ee(n.observation,n.locationId),v=[],k="none",_=O?.query.location_id!==null;if(O===null)l.push({scope:"comp_search",field_name:"comp_search_query",status:"missing",expectation:"expected",strategies_attempted:[],page_signature:n.pageSignature});else{e("Searching comparable listings\u2026","comps");let P=await ce(O.url,t);P.observations.length===0&&O.fallbackUrl&&(P=await ce(O.fallbackUrl,t),_=!1),k=P.source,l.push(...P.issues);let oe=new Set([n.observation.source_listing_id]),w=[],De=M=>{for(let D of M)oe.has(D.source_listing_id)||(oe.add(D.source_listing_id),w.push(D))};De(P.observations),m=P.observations.length,h=Me(n.observation,w),$=Ae(n.observation,w);let Br=w.map(M=>M.location_text);if(!_)I="unscoped_home_search";else if($>=nt)I="trim_target_already_met";else if(!$n(m,h))I="market_exhausted";else{let M=Mn(n.observation,n.locationId);if(M===null)I="no_trim_level";else{e("Searching this trim\u2026","comps");let D=await ce(M.url,t);S=M.query.query,b=D.observations.length;let de=w.length;De(D.observations),T=w.length-de,l.push(...D.issues)}}H=Ae(n.observation,w);let W=Pn(n.observation.latitude,n.observation.longitude);W?g="coordinates":(W=In(n.observation.location_text,Br),W&&(g="location_text")),f=W?.slug??null;let Ur=await ot(),kt=c.extraMetroIds,Et=W?Dn(On(W),Ur):[],Tt=kt.length>0?kt:Et.map(M=>M.slug),Fr=Tt.length;for(let M of Tt){if(!jn(n.observation,w,Fr--))break;if(M===n.locationId)continue;let D=Sn(n.observation,M);if(!D)continue;e("Searching nearby markets\u2026","widening");let de=await ce(D.url,t),St=Et.find(je=>je.slug===M);if(St){let je=de.observations.map(qr=>qr.location_text??"");if(!Ln(St,je)){await zn(M),d.push(M);continue}}De(de.observations),u.push(M)}v=w,P.source==="none"&&l.push({scope:"comp_search",field_name:"comp_results",status:"missing",expectation:"expected",strategies_attempted:["json_payload","aria_dom"],page_signature:n.pageSignature})}let A=Na({capturedAt:t,captureId:crypto.randomUUID(),target:n.observation,comps:v,issues:l,compSearchQuery:O?{...O.query,source:k,location_scoped:_,search_radius_km:n.searchRadiusKm,home_metro:f,home_metro_source:g,home_returned:m,home_usable:h,trim_query:S,trim_query_skipped:I,trim_query_returned:b,trim_query_new:T,trim_matched_before:$,trim_matched_after:H,extra_metros_searched:u,extra_metros_unresolved:d,usable_comp_estimate:Me(n.observation,v)}:null});e("Saving\u2026","saving");let Ie=await te({type:"SUBMIT_CAPTURE",payload:A});if(!Ie?.ok)return{ok:!1,message:Ie?.error??"No response from the extension background worker.",compCount:v.length,extractionOk:!1};let{response:re}=Ie;e("Evaluating\u2026","evaluating");let $e=await te({type:"FETCH_EVALUATION",captureId:re.capture_id}),He=re.duplicate?"Already captured.":`Captured with ${v.length} comparable listing${v.length===1?"":"s"}.`;return $e?.ok?(Or($e.evaluation),{ok:!0,message:re.extraction_ok?He:`${He} Some fields could not be read.`,compCount:v.length,extractionOk:re.extraction_ok}):{ok:!1,message:`${He} Could not load the evaluation (${$e?.error??"no response from the extension background worker"}).`,compCount:v.length,extractionOk:re.extraction_ok}}var Pr=/^send$/i;function Ia(e){if(e.offsetParent===null)return!1;let t=e.getBoundingClientRect();return t.width>0&&t.height>0}function yt(e=document){let t=pe(e),n=Array.from(t.querySelectorAll('[role="button"], button, [aria-label]')).filter(Ia);for(let r of n){let o=r.getAttribute("aria-label");if(o&&Pr.test(y(o)))return r}for(let r of n)if(!r.querySelector('[role="button"], button')&&Pr.test(y(r.textContent??"")))return r;return null}var _t=[{key:"reading",label:"Listing"},{key:"comps",label:"Comps"},{key:"widening",label:"Nearby"},{key:"saving",label:"Saving"},{key:"evaluating",label:"Scoring"}];function Nr(e){return _t.findIndex(t=>t.key===e)}var Ir="deal-rater-trigger",$r="Evaluate Listing",$a="Evaluating\u2026",Ha="Reload the page and try again.";function Da(e){if(/reload/i.test(e))return e;let t=e.trim(),n=t.length>0&&!/[.!?]$/.test(t);return`${t}${n?".":""} ${Ha}`.trim()}var ja=`

  .dock {
    position: fixed;
    /* Defaults for when no Send button was found. mountTriggerButton and
       updateAnchor override right/bottom with inline styles once one is --
       inline styles win over these regardless of specificity, so the
       fallback and the anchored position never fight each other. */
    right: 16px;
    bottom: 16px;
    /* One BELOW the evaluation overlay's backdrop (2147483646), which is the
       whole point. At 2147483647 this panel floated over the open evaluation,
       covering the VIN decode row and the disclaimers at the bottom of the
       sheet -- the two things a reader is most likely to want and least likely
       to think to scroll for. The overlay is modal while it is open; the
       trigger belongs underneath it. */
    z-index: 2147483645;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: var(--sp-3);
    font-family: var(--font-sans);
    -webkit-font-smoothing: antialiased;
    transition: right var(--dur-base) var(--ease-out), bottom var(--dur-base) var(--ease-out);
  }

  button.capture {
    font: 650 14px/1 var(--font-sans);
    padding: var(--sp-4) var(--sp-6);
    border: 0;
    border-radius: var(--radius-pill);
    background: var(--accent);
    color: var(--accent-on);
    cursor: pointer;
    box-shadow: var(--elev-2);
    transition: transform var(--dur-fast) var(--ease-out),
                filter var(--dur-fast) var(--ease-out);
  }
  button.capture:hover:not(:disabled) { filter: brightness(1.12); }
  button.capture:active:not(:disabled) { transform: scale(.97); }
  button.capture:disabled { opacity: .7; cursor: default; }
  :where(button, [tabindex]):focus-visible { outline: 2px solid var(--focus); outline-offset: 3px; }

  /* The fixture control is secondary to the one action this button exists for,
     and is only ever mounted in a dev build. */
  button.extra {
    font: 600 12px/1 var(--font-sans);
    padding: var(--sp-3) var(--sp-4);
    border: 1px solid var(--border); border-radius: var(--radius-pill);
    background: var(--raised); color: var(--text-dim); cursor: pointer;
  }
  button.extra:hover:not(:disabled) { color: var(--text); border-color: var(--text-faint); }

  /* card ------------------------------------------------------------- */
  .card {
    width: 268px;
    padding: var(--sp-4);
    border-radius: var(--radius-lg);
    border: 1px solid var(--border);
    background: var(--sheet);
    color: var(--text);
    box-shadow: var(--elev-2);
    font-size: 12.5px;
    line-height: 1.45;
  }
  .card[hidden] { display: none; }
  .card[data-tone="error"] {
    border-color: var(--tone-adverse-border);
    background: var(--tone-adverse-surface);
    color: var(--tone-adverse-on-surface);
  }

  .card-message { margin: 0; }
  .card[data-tone="error"] .card-title {
    display: flex; align-items: baseline; gap: var(--sp-2);
    margin: 0 0 var(--sp-2); font-weight: 700; color: var(--tone-adverse-text);
  }

  /* progress rail ---------------------------------------------------- */
  .rail { display: flex; gap: 3px; margin-bottom: var(--sp-3); }
  /* display:flex beats the hidden attribute, so a terminal message kept
     showing a rail of five pending steps under it -- a finished run that looks
     like it never started. */
  .rail[hidden] { display: none; }
  .rail-step { flex: 1; min-width: 0; }
  .rail-bar {
    height: 3px; border-radius: var(--radius-pill); background: var(--track);
    overflow: hidden; position: relative;
  }
  .rail-step[data-state="done"] .rail-bar { background: var(--tone-favorable-fill); }
  /* An indeterminate sweep rather than a percentage: the step's duration is
     genuinely unknown -- the widening pass is however many metros it takes --
     and a fake progress bar that stalls at 80% is worse than an honest one
     that only says "still working". */
  .rail-step[data-state="active"] .rail-bar::after {
    content: ""; position: absolute; inset: 0;
    background: linear-gradient(90deg, transparent, var(--accent), transparent);
    animation: sweep 1.15s var(--ease-out) infinite;
  }
  @keyframes sweep {
    from { transform: translateX(-100%); }
    to   { transform: translateX(100%); }
  }
  .rail-label {
    display: block; margin-top: 5px;
    font-size: 9.5px; letter-spacing: .05em; text-transform: uppercase;
    color: var(--text-faint);
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  .rail-step[data-state="active"] .rail-label { color: var(--text); font-weight: 700; }
  .rail-step[data-state="done"] .rail-label { color: var(--text-dim); }

  .progress-line {
    display: flex; align-items: baseline; justify-content: space-between; gap: var(--sp-3);
  }
  .elapsed {
    flex: none; font-variant-numeric: tabular-nums; color: var(--text-faint); font-size: 11px;
  }

  .retry {
    margin-top: var(--sp-3);
    font: 700 11px/1 var(--font-sans); letter-spacing: .05em; text-transform: uppercase;
    padding: var(--sp-2) var(--sp-4); border-radius: var(--radius-pill);
    border: 1px solid var(--tone-adverse-border); background: transparent;
    color: var(--tone-adverse-text); cursor: pointer;
  }
  .retry:hover { background: var(--tone-adverse-border); color: var(--text); }

  @media (prefers-reduced-motion: reduce) {
    * { transition-duration: 0.01ms !important; }
    /* The sweep is the only thing saying the run is still alive, so it is
       slowed rather than removed -- a static card and a hung card would
       otherwise look identical. */
    .rail-step[data-state="active"] .rail-bar::after { animation-duration: 3s !important; }
  }
`;function za(e){let t=o=>e.startsWith(":host")?`${e}([data-theme="${o}"])`:`${e}[data-theme="${o}"]`,n="--accent: #2f6f9f; --accent-on: #ffffff;",r="--accent: #3d86bd; --accent-on: #06101a;";return`
  ${e} { ${n} }
  @media (prefers-color-scheme: dark) { ${e} { ${r} } }
  ${t("light")} { ${n} }
  ${t("dark")} { ${r} }
`}function Ba(e=":host"){return`${e===":host"?":host { all: initial; }":""}
${Ce(e)}
${za(e)}
${ja}`}var Ua=16;function Hr(e,t){if(document.getElementById(Ir))return null;let n=document.createElement("div");n.id=Ir;let r=n.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=Ba();let a=document.createElement("div");a.className="dock";let s=document.createElement("div");s.className="card",s.hidden=!0,s.setAttribute("role","status"),s.setAttribute("aria-live","polite");let l=document.createElement("div");l.className="rail";let c=_t.map(v=>{let k=document.createElement("div");k.className="rail-step";let _=document.createElement("div");_.className="rail-bar";let A=document.createElement("span");return A.className="rail-label",A.textContent=v.label,k.append(_,A),l.append(k),k}),u=document.createElement("div");u.className="progress-line";let d=document.createElement("p");d.className="card-message";let f=document.createElement("span");f.className="elapsed",u.append(d,f),s.append(l,u);let g=document.createElement("button");g.type="button",g.className="capture",g.textContent=$r,g.addEventListener("click",e),a.append(s,g),r.append(o,a),document.body.appendChild(n);let m=t,h=()=>{let v=m?.isConnected?m.getBoundingClientRect():null;if(!v||v.width===0||v.height===0){a.style.removeProperty("right"),a.style.removeProperty("bottom");return}a.style.right=`${Math.max(window.innerWidth-v.right,8)}px`,a.style.bottom=`${Math.max(window.innerHeight-v.top+Ua,8)}px`};h(),window.addEventListener("scroll",h,{passive:!0,capture:!0}),window.addEventListener("resize",h,{passive:!0});let S,b,T=0,I=()=>s.querySelector(".retry")?.remove(),$=()=>s.querySelector(".card-title")?.remove(),H=v=>{let k=v?Nr(v):-1;l.hidden=k<0,c.forEach((_,A)=>{_.dataset.state=k<0?"pending":A<k?"done":A===k?"active":"pending"})},O=()=>{b&&clearInterval(b),b=void 0};return{setProgress(v,k){S&&clearTimeout(S),I(),$(),delete s.dataset.tone,d.textContent=v,H(k),s.hidden=!1,b||(T=Date.now(),f.textContent="",b=window.setInterval(()=>{let _=Math.round((Date.now()-T)/1e3);f.textContent=_>=4?`${_}s`:""},1e3))},setStatus(v,k="info"){if(S&&clearTimeout(S),O(),I(),$(),f.textContent="",H(void 0),d.textContent=k==="error"?Da(v):v,s.hidden=!1,k==="error"){s.dataset.tone="error";let _=document.createElement("div");_.className="card-title",_.append("\u26A0"," That didn't finish"),s.insertBefore(_,d.parentElement);let A=document.createElement("button");A.type="button",A.className="retry",A.textContent="Try again",A.addEventListener("click",e),s.append(A)}else delete s.dataset.tone,S=window.setTimeout(()=>{s.hidden=!0},8e3)},setBusy(v){g.disabled=v,g.textContent=v?$a:$r,v||O()},remove(){S&&clearTimeout(S),O(),window.removeEventListener("scroll",h,!0),window.removeEventListener("resize",h),n.remove()},addExtraAction(v,k){let _=document.createElement("button");_.type="button",_.className="extra",_.textContent=v,_.addEventListener("click",k),a.appendChild(_)},updateAnchor(v){m=v,h()}}}var Fa=300,L=null,Dr=location.href,wt=!1;function jr(){return/\/marketplace\/item\/\d+/.test(location.pathname)}function qa(){return/\/marketplace\/(search|category)/.test(location.pathname)}async function Va(){if(!(wt||!L)){wt=!0,L.setBusy(!0);try{let e=await Lr((t,n)=>L?.setProgress(t,n));L.setStatus(e.message,e.ok?"info":"error")}catch(e){L.setStatus(e instanceof Error?e.message:String(e),"error")}finally{wt=!1,L.setBusy(!1)}}}async function zr(){if(!(await ee()).enabled||!jr()){L?.remove(),L=null;return}if(L){L.updateAnchor(yt());return}L=Hr(()=>void Va(),yt())}function Ga(){let e,t=()=>{location.href!==Dr&&(Dr=location.href,zr())},n=()=>{e&&clearTimeout(e),e=window.setTimeout(t,Fa)};new MutationObserver(n).observe(document.documentElement,{childList:!0,subtree:!0}),window.addEventListener("popstate",t)}chrome.runtime.onMessage.addListener((e,t,n)=>e?.type==="HARVEST_COMPS"?(we(document,location.href).then(r=>n({ok:!0,observations:r.observations,issues:r.issues})).catch(r=>n({ok:!1,error:r instanceof Error?r.message:String(r)})),!0):e?.type==="HARVEST_TARGET"?(le(document,location.href).then(r=>n({ok:!0,observation:r.observation,issues:r.issues,pageSignature:r.pageSignature,usable:r.usable,locationId:r.locationId,searchRadiusKm:r.searchRadiusKm,payloadMatched:r.payloadMatched})).catch(r=>n({ok:!1,error:r instanceof Error?r.message:String(r)})),!0):!1);(qa()||jr())&&chrome.runtime.sendMessage({type:"CONTENT_READY",url:location.href}).catch(()=>{});zr();Ga();})();
